package com.jarvis.assistant.ai

import android.content.Context
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.vault.SecretStore
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Text answers from xAI's Grok, used as a second "brain" for background jobs. */
object GrokClient {
    const val KEY_NAME = "api grok"
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    fun configured(context: Context): Boolean = !SecretStore.get(context, KEY_NAME).isNullOrBlank()

    /** Throws an exception with a readable message when something goes wrong. */
    fun ask(context: Context, system: String, user: String, json: Boolean = false): String {
        val key = SecretStore.get(context, KEY_NAME)
        if (key.isNullOrBlank()) throw RuntimeException("Grok API key set nahi hai")
        val model = JarvisApp.instance.preferences.grokModel.ifBlank { "grok-4" }
        val body = JSONObject()
            .put("model", model)
            .put("temperature", 0.5)
            .put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", system))
                .put(JSONObject().put("role", "user").put("content", user)))
        if (json) body.put("response_format", JSONObject().put("type", "json_object"))
        val req = Request.Builder()
            .url("https://api.x.ai/v1/chat/completions")
            .addHeader("Authorization", "Bearer $key")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        val answer: String = client.newCall(req).execute().use { r ->
            val txt = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw RuntimeException("Grok error ${r.code}: ${txt.take(140)}")
            JSONObject(txt).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content")
        }
        return answer
    }
}
