package com.jarvis.assistant.announce

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.vault.SecretStore
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Speaks text with the user's chosen ElevenLabs voice (for example "Bunty"). */
object ElevenLabsVoice {
    const val KEY_NAME = "api elevenlabs"
    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    fun configured(context: Context): Boolean =
        !SecretStore.get(context, KEY_NAME).isNullOrBlank() &&
            JarvisApp.instance.preferences.elevenVoiceId.isNotBlank()

    /** Returns null when the text was spoken, or a short error message. */
    @Synchronized
    fun speak(context: Context, text: String): String? {
        val key = SecretStore.get(context, KEY_NAME)
        val vid = JarvisApp.instance.preferences.elevenVoiceId.trim()
        if (key.isNullOrBlank() || vid.isBlank()) return "ElevenLabs key ya Voice ID set nahi hai"
        return try {
            val body = JSONObject()
                .put("text", text)
                .put("model_id", "eleven_multilingual_v2")
                .put("voice_settings", JSONObject().put("stability", 0.45).put("similarity_boost", 0.8))
            val req = Request.Builder()
                .url("https://api.elevenlabs.io/v1/text-to-speech/$vid")
                .addHeader("xi-api-key", key)
                .addHeader("Accept", "audio/mpeg")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()
            client.newCall(req).execute().use { r ->
                if (!r.isSuccessful) {
                    return "ElevenLabs error ${r.code}: " + (r.body?.string()?.take(140) ?: "")
                }
                val bytes = r.body?.bytes() ?: return "ElevenLabs ne awaaz nahi bheji"
                val f = File(context.cacheDir, "bunty_" + System.nanoTime() + ".mp3")
                f.writeBytes(bytes)
                play(f)
                f.delete()
            }
            null
        } catch (e: Exception) {
            "ElevenLabs se jud nahi paaya: ${e.message}"
        }
    }

    private fun play(f: File) {
        val mp = MediaPlayer()
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            mp.setDataSource(f.absolutePath)
            mp.prepare()
            val done = CountDownLatch(1)
            mp.setOnCompletionListener { done.countDown() }
            mp.setOnErrorListener { _, _, _ -> done.countDown(); true }
            mp.start()
            done.await(90, TimeUnit.SECONDS)
        } finally {
            try { mp.release() } catch (e: Exception) { }
        }
    }
}
