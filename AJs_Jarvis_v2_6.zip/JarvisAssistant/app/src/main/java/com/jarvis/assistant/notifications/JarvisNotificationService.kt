package com.jarvis.assistant.notifications

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class JarvisNotificationService : NotificationListenerService() {

    override fun onListenerConnected() {
        NotificationHub.listenerConnected = true
        try {
            activeNotifications?.forEach { process(it, allowAuto = false) }
        } catch (e: Exception) {
        }
    }

    override fun onListenerDisconnected() {
        NotificationHub.listenerConnected = false
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        process(sbn, allowAuto = true)
    }

    private fun process(sbn: StatusBarNotification, allowAuto: Boolean) {
        val pkg = sbn.packageName
        if (pkg == packageName || pkg == "android" || pkg == "com.android.systemui") return
        val source = appLabel(pkg)
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        if (n.category in NOISE_CATEGORIES) return
        val extras = n.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString()?.trim().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        if (Regex("^\\d+ new messages?$", RegexOption.IGNORE_CASE).containsMatchIn(text)) return
        if (text.contains("Checking for new messages", ignoreCase = true)) return

        val item = NotificationHub.Item(System.currentTimeMillis(), source, title.ifBlank { "Unknown" }, text)
        if (!NotificationHub.add(item)) return

        val isGroup = extras.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false)
        if (allowAuto && (pkg == "com.whatsapp" || pkg == "com.whatsapp.w4b") && !isGroup) {
            AutoReplyEngine.maybeHandle(applicationContext, n, item)
        }
    }

    private fun appLabel(pkg: String): String = try {
        val pm = packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        KNOWN[pkg] ?: pkg.removePrefix("com.").removePrefix("org.").removeSuffix(".android").substringBefore('.').replaceFirstChar { it.uppercase() }
    }

    companion object {
        private val KNOWN = mapOf(
            "com.instagram.android" to "Instagram",
            "org.telegram.messenger" to "Telegram",
            "com.snapchat.android" to "Snapchat",
            "com.facebook.katana" to "Facebook",
            "com.facebook.orca" to "Messenger",
            "com.twitter.android" to "X",
            "com.linkedin.android" to "LinkedIn",
            "com.discord" to "Discord",
            "com.google.android.gm" to "Gmail",
            "com.whatsapp" to "WhatsApp",
            "com.whatsapp.w4b" to "WhatsApp Business",
            "com.google.android.apps.messaging" to "SMS",
            "com.samsung.android.messaging" to "SMS",
            "com.android.mms" to "SMS"
        )
        private val NOISE_CATEGORIES = setOf(
            Notification.CATEGORY_TRANSPORT, Notification.CATEGORY_PROGRESS, Notification.CATEGORY_SERVICE,
            Notification.CATEGORY_SYSTEM, Notification.CATEGORY_STATUS, Notification.CATEGORY_ALARM,
            Notification.CATEGORY_ERROR, Notification.CATEGORY_NAVIGATION, Notification.CATEGORY_CALL
        )
    }
}
