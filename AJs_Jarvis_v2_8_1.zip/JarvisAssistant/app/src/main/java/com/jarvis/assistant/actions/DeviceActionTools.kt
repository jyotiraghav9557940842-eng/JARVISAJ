package com.jarvis.assistant.actions

import com.jarvis.assistant.data.model.FunctionDeclarationPayload
import com.jarvis.assistant.data.model.ParamPropertyPayload
import com.jarvis.assistant.data.model.ParametersPayload
import com.jarvis.assistant.data.model.ToolPayload

/** Function declarations that Gemini Live can call to control the phone. */
object DeviceActionTools {

    private fun pStr(desc: String) = ParamPropertyPayload("STRING", desc)
    private fun pInt(desc: String) = ParamPropertyPayload("INTEGER", desc)
    private fun pBool(desc: String) = ParamPropertyPayload("BOOLEAN", desc)

    private fun fn(
        name: String,
        description: String,
        props: Map<String, ParamPropertyPayload> = emptyMap(),
        required: List<String> = emptyList()
    ) = FunctionDeclarationPayload(
        name = name,
        description = description,
        parameters = if (props.isEmpty()) null else ParametersPayload(
            properties = props,
            required = if (required.isEmpty()) null else required
        )
    )

    val tool: ToolPayload = ToolPayload(
        functionDeclarations = listOf(
            fn(
                "open_app",
                "Opens an installed app on the phone by its name, e.g. WhatsApp, YouTube, Chrome, Instagram, Camera, Settings.",
                mapOf("app_name" to pStr("Name of the app as the user says it, in English letters.")),
                listOf("app_name")
            ),
            fn(
                "call_contact",
                "Calls a person from the user's contacts, or dials a phone number.",
                mapOf("name_or_number" to pStr("Contact name written in English letters exactly as it would be saved (e.g. Mummy, Rahul), or a phone number.")),
                listOf("name_or_number")
            ),
            fn(
                "send_whatsapp",
                "Opens WhatsApp, types the message and SENDS it automatically (needs Accessibility). Use it only when the user asked to send a message.",
                mapOf(
                    "name_or_number" to pStr("Contact name in English letters, or a phone number."),
                    "message" to pStr("The message text to type.")
                ),
                listOf("name_or_number", "message")
            ),
            fn(
                "send_sms",
                "Opens the SMS app with the message already typed. The user must press send themselves.",
                mapOf(
                    "name_or_number" to pStr("Contact name in English letters, or a phone number."),
                    "message" to pStr("The message text to type.")
                ),
                listOf("name_or_number", "message")
            ),
            fn(
                "change_voice",
                "Changes YOUR OWN speaking voice. Available voices: ${com.jarvis.assistant.data.model.GeminiConstants.SUPPORTED_VOICES.joinToString(", ")}. Call it whenever the user asks you to change, switch or use another voice (for example Leda). You CAN do this, never say you cannot.",
                mapOf("voice_name" to pStr("One of the available voice names.")),
                listOf("voice_name")
            ),
            fn(
                "tap_screen",
                "Taps the screen at a position given as percentages (0-100) of the screen width and height. Use it for items without a text label, such as gallery thumbnails. Take the positions from the [tap-area] lines of read_screen. Needs Accessibility access.",
                mapOf(
                    "x_percent" to pInt("Horizontal position, 0 (left) to 100 (right)."),
                    "y_percent" to pInt("Vertical position, 0 (top) to 100 (bottom).")
                ),
                listOf("x_percent", "y_percent")
            ),
            fn(
                "read_messages",
                "Reads the user's recent incoming messages, mails and alerts of ANY app (WhatsApp, Instagram, Telegram, Gmail, SMS and so on), taken from notifications, so it needs Notification access. Call it when the user asks what came, passing the app name they asked about. It also tells which ones Jarvis already auto-handled.",
                mapOf("source" to pStr("The app name the user asked about, for example instagram, whatsapp, gmail, telegram, sms, or all.")),
                listOf("source")
            ),
            fn(
                "who_is_speaking",
                "Tells whose voice was just heard: OWNER, a saved person's name, or UNKNOWN. Only used when Speaker ID is on."
            ),
            fn(
                "save_speaker",
                "Saves the voice of the person who was UNKNOWN under the given name so Jarvis recognises them from now on. Ask them to speak a few sentences first.",
                mapOf("name" to pStr("The person's name, as they told you.")),
                listOf("name")
            ),
            fn(
                "bluetooth_connect",
                "Connects the phone to an already paired Bluetooth device (earbuds, headphones, speaker) by its name, using the Bluetooth settings screen. Needs Accessibility access.",
                mapOf("device_name" to pStr("The name of the Bluetooth device, for example 'Decibel 24'.")),
                listOf("device_name")
            ),
            fn(
                "recall_activity",
                "Looks up what Jarvis did earlier on this phone (videos played, apps opened, calls, searches) by keyword, for requests like 'wahi video phir se chalao'. An empty keyword returns the latest items.",
                mapOf("keyword" to pStr("A word to search for, or empty.")),
                listOf("keyword")
            ),
            fn(
                "set_reminder",
                "Sets a reminder that shows a notification with the text. Give minutes from now, or a clock time (hour 0-23 and minute).",
                mapOf(
                    "text" to pStr("What to remind the user about."),
                    "minutes" to pInt("Minutes from now. Use 0 if a clock time is given."),
                    "hour" to pInt("Hour 0-23, or -1 if minutes is used."),
                    "minute" to pInt("Minute 0-59.")
                ),
                listOf("text")
            ),
            fn(
                "add_task",
                "Adds a homework item or to-do to the user's task list.",
                mapOf(
                    "title" to pStr("The task, for example 'Maths chapter 5 exercise'."),
                    "due" to pStr("When it is due, in the user's words, or empty.")
                ),
                listOf("title")
            ),
            fn("list_tasks", "Lists the user's pending homework and to-dos."),
            fn(
                "complete_task",
                "Marks pending tasks as done when their title contains the keyword.",
                mapOf("keyword" to pStr("A word from the task title.")),
                listOf("keyword")
            ),
            fn(
                "set_kids_mode",
                "Turns child-safe mode on or off. Use it when the user says a child is listening or near, or says it is fine again.",
                mapOf("enabled" to pBool("true for child-safe mode, false for normal.")),
                listOf("enabled")
            ),
            fn(
                "set_mood",
                "Remembers the voice mood the user prefers for next time. One of: auto, normal, calm, energetic.",
                mapOf("mood" to pStr("auto, normal, calm or energetic.")),
                listOf("mood")
            ),
            fn(
                "whatsapp_call",
                "Starts a WhatsApp voice call or video call to a contact. Use it whenever the user asks for a WhatsApp call, voice call or video call. You CAN do this.",
                mapOf(
                    "name_or_number" to pStr("Contact name written in English letters as saved, or a phone number."),
                    "video" to pBool("true for a video call, false for a voice call.")
                ),
                listOf("name_or_number")
            ),
            fn(
                "power_off_phone",
                "Switches the phone off by opening the power menu and tapping Power off (Android 12+, needs Accessibility). Always ask the user to confirm out loud first, because the phone will turn off."
            ),
            fn(
                "set_alarm",
                "Sets an alarm at a specific time of day using the 24-hour clock.",
                mapOf(
                    "hour" to pInt("Hour in 24-hour format, 0 to 23."),
                    "minute" to pInt("Minute, 0 to 59."),
                    "label" to pStr("Optional label for the alarm.")
                ),
                listOf("hour", "minute")
            ),
            fn(
                "set_timer",
                "Starts a countdown timer.",
                mapOf(
                    "seconds" to pInt("Total timer length in seconds."),
                    "label" to pStr("Optional label for the timer.")
                ),
                listOf("seconds")
            ),
            fn(
                "flashlight",
                "Turns the phone flashlight (torch) on or off.",
                mapOf("on" to pBool("true to turn on, false to turn off.")),
                listOf("on")
            ),
            fn(
                "set_volume",
                "Changes the media volume.",
                mapOf(
                    "action" to pStr("One of: up, down, mute, max, set."),
                    "percent" to pInt("Volume percent 0-100. Only used when action is set.")
                ),
                listOf("action")
            ),
            fn(
                "play_youtube",
                "Searches YouTube for a video or song and automatically plays the top result (needs Accessibility).",
                mapOf("query" to pStr("What to search for on YouTube.")),
                listOf("query")
            ),
            fn(
                "web_search",
                "Searches Google in the browser.",
                mapOf("query" to pStr("What to search for.")),
                listOf("query")
            ),
            fn(
                "navigate_maps",
                "Shows a place in Google Maps, or starts navigation to it.",
                mapOf(
                    "place" to pStr("Place name or address."),
                    "start_navigation" to pBool("true to start turn-by-turn navigation, false to only show on the map.")
                ),
                listOf("place")
            ),
            fn(
                "open_settings",
                "Opens a phone settings screen. It cannot flip switches by itself, only opens the screen.",
                mapOf("screen" to pStr("One of: wifi, bluetooth, display, sound, battery, location, airplane, developer, apps, storage, accessibility, main.")),
                listOf("screen")
            ),
            fn("open_camera", "Opens the camera app."),
            fn("battery_status", "Tells the current battery percentage and whether the phone is charging."),
            fn("go_home", "Goes to the phone's home screen."),
            fn(
                "remember_fact",
                "Saves something permanently in long-term memory so it is remembered in every future conversation. Call it whenever the user shares a lasting fact (name, family, preferences, plans, birthdays, habits) or says 'yaad rakhna' / remember this.",
                mapOf("fact" to pStr("One short, clear sentence about the user or what they asked to remember, in the user's language.")),
                listOf("fact")
            ),
            fn(
                "forget_fact",
                "Deletes saved memories that contain a keyword, when the user asks to forget something.",
                mapOf("keyword" to pStr("A word or phrase that identifies the memory to delete.")),
                listOf("keyword")
            ),
            fn(
                "read_screen",
                "Reads the text, buttons and input fields currently visible on the phone screen. Call it after opening an app and after each action to see what is on screen. Needs Accessibility access."
            ),
            fn(
                "click_on",
                "Taps a button, link, tab or item on the current screen whose visible text or label matches the given text. Always call read_screen first so you know the exact label. Needs Accessibility access.",
                mapOf("text" to pStr("Visible text or label of the item to tap.")),
                listOf("text")
            ),
            fn(
                "type_text",
                "Types text into the currently focused input field, or the first input field on the screen. Needs Accessibility access.",
                mapOf("text" to pStr("Text to type.")),
                listOf("text")
            ),
            fn(
                "scroll_screen",
                "Scrolls the current screen. Needs Accessibility access.",
                mapOf("direction" to pStr("down (see more below) or up.")),
                listOf("direction")
            ),
            fn(
                "press_key",
                "Presses a system key. Needs Accessibility access (except home).",
                mapOf("key" to pStr("One of: back, home, recents, notifications, quick_settings, enter, lock_screen (turns the screen off and locks the phone; Android 9 or newer).")),
                listOf("key")
            ),
            fn(
                "open_accessibility_settings",
                "Opens the Accessibility settings screen so the user can turn on AJ'S JARVIS control. Use when screen-control tools say Accessibility is off."
            )
        )
    )
}
