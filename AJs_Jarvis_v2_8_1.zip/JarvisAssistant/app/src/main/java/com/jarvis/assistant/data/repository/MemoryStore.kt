package com.jarvis.assistant.data.repository

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.jarvis.assistant.data.model.ChatTurn

/** Long-term memory: facts Jarvis keeps forever + recent chat, injected into every new session. */
class MemoryStore(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("jarvis_memory", Context.MODE_PRIVATE)
    private val gson = Gson()

    @Synchronized
    fun facts(): List<String> {
        val raw = prefs.getString(KEY, null) ?: return emptyList()
        return try {
            gson.fromJson<List<String>>(raw, object : TypeToken<List<String>>() {}.type) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    @Synchronized
    fun add(fact: String): Boolean {
        val clean = fact.trim().take(300)
        if (clean.isEmpty()) return false
        val list = facts().toMutableList()
        if (list.any { it.equals(clean, ignoreCase = true) }) return true
        list.add(clean)
        while (list.size > MAX_FACTS) list.removeAt(0)
        prefs.edit().putString(KEY, gson.toJson(list)).apply()
        return true
    }

    @Synchronized
    fun forget(keyword: String): Int {
        val k = keyword.trim()
        if (k.isEmpty()) return 0
        val list = facts().toMutableList()
        val before = list.size
        list.removeAll { it.contains(k, ignoreCase = true) }
        prefs.edit().putString(KEY, gson.toJson(list)).apply()
        return before - list.size
    }

    @Synchronized
    fun clear() {
        prefs.edit().remove(KEY).apply()
    }

    fun promptBlock(recent: List<ChatTurn>): String {
        val sb = StringBuilder()
        val f = facts()
        if (f.isNotEmpty()) {
            sb.append("[LONG-TERM MEMORY - things you already know about the user. Use naturally, never read the list out.]\n")
            f.takeLast(80).forEach { sb.append("- ").append(it).append('\n') }
            sb.append('\n')
        }
        val turns = recent.takeLast(RECENT_TURNS)
        if (turns.isNotEmpty()) {
            sb.append("[RECENT CONVERSATION - from earlier sessions, for continuity. Do not repeat it unless asked.]\n")
            turns.forEach {
                sb.append("User: ").append(it.userTranscript.take(150)).append('\n')
                sb.append("Jarvis: ").append(it.jarvisResponse.take(150)).append('\n')
            }
        }
        return sb.toString().take(7000)
    }

    companion object {
        private const val KEY = "facts_json"
        private const val MAX_FACTS = 150
        private const val RECENT_TURNS = 6
    }
}
