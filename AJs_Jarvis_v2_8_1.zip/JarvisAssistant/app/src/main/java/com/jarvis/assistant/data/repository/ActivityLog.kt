package com.jarvis.assistant.data.repository

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** What Jarvis did on the phone, so "wahi video phir se chalao" can be understood later. */
object ActivityLog {
    private const val PREFS = "jarvis_activity"
    private const val KEY = "log"
    private const val MAX = 120

    class Entry(val time: Long, val text: String)

    @Synchronized
    fun add(context: Context, text: String) {
        if (text.isBlank()) return
        val sp = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = try { JSONArray(sp.getString(KEY, "[]")) } catch (e: Exception) { JSONArray() }
        arr.put(JSONObject().put("t", System.currentTimeMillis()).put("d", text.take(200)))
        val out = JSONArray()
        val start = maxOf(0, arr.length() - MAX)
        for (i in start until arr.length()) out.put(arr.get(i))
        sp.edit().putString(KEY, out.toString()).apply()
    }

    @Synchronized
    fun all(context: Context): List<Entry> {
        val sp = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = try { JSONArray(sp.getString(KEY, "[]")) } catch (e: Exception) { return emptyList() }
        val list = ArrayList<Entry>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(Entry(o.getLong("t"), o.getString("d")))
        }
        return list
    }

    fun search(context: Context, keyword: String, max: Int = 12): List<Entry> {
        val k = keyword.trim().lowercase()
        val all = all(context)
        val hits = if (k.isEmpty()) all else all.filter { it.text.lowercase().contains(k) }
        return hits.takeLast(max)
    }

    fun whenText(t: Long): String {
        val now = Calendar.getInstance()
        val then = Calendar.getInstance().apply { timeInMillis = t }
        val d0 = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val days = ((d0.timeInMillis - then.timeInMillis + 86_399_999L) / 86_400_000L).toInt().coerceAtLeast(0)
        val day = when {
            then.timeInMillis >= d0.timeInMillis -> "aaj"
            days <= 1 -> "kal"
            else -> "$days din pehle"
        }
        return day + " " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(t))
    }
}
