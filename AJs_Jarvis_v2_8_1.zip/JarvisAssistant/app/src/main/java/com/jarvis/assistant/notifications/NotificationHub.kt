package com.jarvis.assistant.notifications

/** Keeps the latest incoming messages (WhatsApp, Gmail, SMS) seen by the notification listener. */
object NotificationHub {
    class Item(val time: Long, val source: String, val sender: String, val text: String) {
        @Volatile var handled: String = ""
    }

    @Volatile var listenerConnected = false
    private val items = ArrayList<Item>()
    private val lastReplyAt = HashMap<String, Long>()
    private val dayReplies = ArrayList<Long>()

    @Synchronized
    fun add(item: Item): Boolean {
        val dup = items.takeLast(25).any {
            it.source == item.source && it.sender == item.sender && it.text == item.text
        }
        if (dup) return false
        items.add(item)
        while (items.size > 150) items.removeAt(0)
        return true
    }

    @Synchronized
    fun recent(source: String, max: Int): List<Item> {
        val key = source.lowercase()
        return items.filter {
            key.isBlank() || key == "all" || it.source.lowercase().contains(key)
        }.takeLast(max)
    }

    /** At most one auto-reply per sender every 10 minutes and 20 per day. */
    @Synchronized
    fun canAutoReply(sender: String): Boolean {
        val now = System.currentTimeMillis()
        dayReplies.removeAll { now - it > 24L * 3600_000 }
        if (dayReplies.size >= 20) return false
        val last = lastReplyAt[sender] ?: 0L
        return now - last > 10 * 60_000
    }

    @Synchronized
    fun noteReplied(sender: String) {
        val now = System.currentTimeMillis()
        lastReplyAt[sender] = now
        dayReplies.add(now)
    }
}
