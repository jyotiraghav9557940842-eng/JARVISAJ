package com.jarvis.assistant.announce

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager

/** Announces plugging in the charger (with the battery percentage), a full battery and a low battery. */
object PowerAnnouncer {
    private var started = false
    private var fullSaid = false

    @Synchronized
    fun start(context: Context) {
        if (started) return
        started = true
        val app = context.applicationContext
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_BATTERY_LOW)
            addAction(Intent.ACTION_BATTERY_CHANGED)
        }
        app.registerReceiver(object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                when (intent.action) {
                    Intent.ACTION_POWER_CONNECTED -> {
                        fullSaid = false
                        Announcer.charging(app, level(app))
                    }
                    Intent.ACTION_POWER_DISCONNECTED -> fullSaid = false
                    Intent.ACTION_BATTERY_LOW -> Announcer.low(app, level(app))
                    Intent.ACTION_BATTERY_CHANGED -> {
                        val lvl = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                        val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
                        if (plugged && lvl >= 100 && !fullSaid) {
                            fullSaid = true
                            Announcer.full(app)
                        }
                    }
                }
            }
        }, filter)
    }

    private fun level(context: Context): Int {
        val i = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val l = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        return if (l >= 0 && sc > 0) l * 100 / sc else 0
    }
}
