package com.jarvis.assistant.audio

import android.content.Context
import org.json.JSONObject

/** Saved voices of other people (family, friends) and the latest "who is speaking" result. */
object SpeakerBook {
    private const val PREFS = "jarvis_speakers"
    private const val KEY = "profiles"

    @Volatile var lastLabel: String = ""          // "OWNER", a person's name, or "UNKNOWN"
    @Volatile var lastLabelTime: Long = 0L
    @Volatile var active: Boolean = false
    private val unknownPcm = ArrayList<ShortArray>()

    @Synchronized
    fun addUnknown(pcm: ShortArray) {
        unknownPcm.add(pcm)
        var total = unknownPcm.sumOf { it.size }
        while (total > 16000 * 20 && unknownPcm.size > 1) {
            total -= unknownPcm.removeAt(0).size
        }
    }

    @Synchronized
    fun clearUnknown() = unknownPcm.clear()

    @Synchronized
    fun unknownSegments(): List<ShortArray> = ArrayList(unknownPcm)

    fun load(context: Context): Map<String, VoiceProfile> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return emptyMap()
        val out = LinkedHashMap<String, VoiceProfile>()
        try {
            val o = JSONObject(raw)
            for (k in o.keys()) VoiceProfile.parse(o.getString(k))?.let { out[k] = it }
        } catch (e: Exception) {
        }
        return out
    }

    fun save(context: Context, name: String, profile: VoiceProfile) {
        val map = load(context).toMutableMap()
        map[name] = profile
        val o = JSONObject()
        for ((k, v) in map) o.put(k, v.serialize())
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, o.toString()).apply()
    }

    fun names(context: Context): List<String> = load(context).keys.toList()

    fun clearAll(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }
}

/** Listens to the microphone stream (never blocks it) and works out whose voice each sentence is. */
class SpeakerTracker(
    private val owner: VoiceProfile,
    private val others: Map<String, VoiceProfile>,
    private val factor: Float
) {
    private val buf = ArrayList<ByteArray>()
    private var collecting = false
    private var quiet = 0

    fun process(chunk: ByteArray, amplitude: Float) {
        if (chunk.isEmpty()) return
        val loud = amplitude > 0.08f
        if (!collecting) {
            if (loud) {
                collecting = true
                buf.clear()
                quiet = 0
                buf.add(chunk)
            }
            return
        }
        buf.add(chunk)
        if (loud) quiet = 0 else quiet++
        if (quiet >= 10 || buf.size >= 60) {
            analyze()
            collecting = false
            buf.clear()
        }
    }

    private fun analyze() {
        val pcm = Dsp.toShorts(buf)
        val fs = Dsp.voiced(Dsp.analyze(pcm))
        if (fs.size < 25) return
        val emb = Dsp.embedding(fs.take(100))
        val short = if (fs.size < 60) 1.15f else 1f
        var best = "UNKNOWN"
        var bestRatio = Float.MAX_VALUE
        val ro = owner.distance(emb) / (owner.thr * factor * short)
        if (ro <= 1f) { best = "OWNER"; bestRatio = ro }
        for ((name, p) in others) {
            val r = p.distance(emb) / (p.thr * factor * short)
            if (r <= 1f && r < bestRatio) { best = name; bestRatio = r }
        }
        SpeakerBook.lastLabel = best
        SpeakerBook.lastLabelTime = System.currentTimeMillis()
        if (best == "UNKNOWN") SpeakerBook.addUnknown(pcm) else SpeakerBook.clearUnknown()
    }
}
