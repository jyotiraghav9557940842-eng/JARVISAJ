package com.jarvis.assistant.util

/** Home-screen UI styles. mode: reactor | sphere | plexus | image. */
object UiStyles {
    class S(
        val name: String,
        val hint: String,
        val mode: String,
        val img: String,          // centrepiece image in assets/orb/ui (image mode)
        val backdrop: String,     // full-screen wallpaper in assets/ui
        val backdropAlpha: Float,
        val spin: Float,
        val palette: String       // palette applied when the style is chosen
    )

    val all: List<S> = listOf(
        S("Arc Reactor Live", "Chalta hua arc reactor, aawaz par hilta hai", "reactor", "", "", 0f, 0f, "Arc Reactor"),
        S("Reactor Wall", "Neela arc reactor wallpaper", "image", "", "arc_wall.jpg", 0.95f, 0f, "Arc Reactor"),
        S("Iron Gold Core", "Sunehra Iron Man reactor, ghoomta hua", "image", "iron_gold.png", "", 0f, 1f, "Stark Gold"),
        S("War Machine Red", "Laal war-machine HUD", "reactor", "", "war_red.jpg", 0.9f, 0f, "Iron Man"),
        S("Fusion Ring", "Neela-narangi ghoomta HUD", "image", "fusion.png", "", 0f, 1f, "Fire & Ice"),
        S("JARVIS Compass", "Teal compass HUD", "image", "compass.png", "", 0f, -1f, "Midnight Teal"),
        S("Neural Network", "Neela network gola", "plexus", "", "", 0f, 0f, "Arc Reactor"),
        S("Particle Mind", "JARVIS soch raha hai: kano ka gola", "sphere", "", "", 0f, 0f, "Classic JARVIS"),
        S("Iron Diagnostics", "Iron Man system diagnostics", "image", "diag.png", "", 0f, 0f, "Iron Man"),
        S("Stark Desktop", "Stark Industries poora HUD", "image", "stark.png", "", 0f, 0f, "Arc Reactor"),
        S("Stealth Frame", "Kaala carbon frame", "reactor", "", "frame.jpg", 1f, 0f, "Titanium"),
        S("Hex Blueprint", "Neela blueprint keyboard", "reactor", "", "blueprint.jpg", 0.55f, 0f, "Arc Reactor")
    )

    fun paletteIndexFor(s: S): Int =
        Palettes.all.indexOfFirst { it.name == s.palette }.let { if (it >= 0) it else Palettes.DEFAULT_INDEX }
}
