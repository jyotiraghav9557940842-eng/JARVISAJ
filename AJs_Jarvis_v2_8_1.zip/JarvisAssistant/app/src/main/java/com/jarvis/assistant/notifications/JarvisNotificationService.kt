package com.jarvis.assistant.notifications

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class JarvisNotificationService : NotificationListenerService() {

    override fun onListenerConnected() {
        NotificationHub.listenerConnected = true
        try { com.jarvis.assistant.announce.PowerAnnouncer.start(applicationContext) } catch (e: Exception) { }
        try {
            activeNotifications?.forEach { process(it, allowAuto = false) }
        } catch (e: Exception) {
        }
    }

    override fun onListenerDisconnected() {
        NotificationHub.listenerConnected = false
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        process(sbn, allowAuto = true)
    }

    private fun process(sbn: StatusBarNotification, allowAuto: Boolean) {
        val pkg = sbn.packageName
        if (pkg == packageName || pkg == "android" || pkg == "com.android.systemui") return
        val source = appLabel(pkg)
        val n = sbn.notification ?: return
        val extras = n.extras ?: return

        // Incoming call: announce who is calling, without being asked.
        if (n.category == Notification.CATEGORY_CALL) {
            if (allowAuto) {
                val incoming = n.fullScreenIntent != null || (n.actions?.size ?: 0) >= 2
                val who = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
                if (incoming && who.isNotBlank()) {
                    com.jarvis.assistant.announce.Announcer.incomingCall(applicationContext, who)
                }
            }
            return
        }

        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        if (n.category in NOISE_CATEGORIES) return

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val bigText = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString()?.trim().orEmpty()
        val isGroup = extras.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false)

        // Chat apps put the whole conversation in EXTRA_MESSAGES; read every line from there.
        val lines = ArrayList<Pair<String, String>>()   // sender to text
        try {
            @Suppress("DEPRECATION")
            val msgs = extras.getParcelableArray(Notification.EXTRA_MESSAGES)
            msgs?.takeLast(6)?.forEach { m ->
                val b = m as? android.os.Bundle ?: return@forEach
                val t = b.getCharSequence("text")?.toString()?.trim().orEmpty()
                if (t.isNotBlank()) {
                    val who = b.getCharSequence("sender")?.toString()?.trim().orEmpty()
                    lines.add((if (who.isNotBlank()) who else title.ifBlank { "Unknown" }) to t)
                }
            }
        } catch (e: Exception) {
        }
        if (lines.isEmpty()) {
            if (title.isBlank() && bigText.isBlank()) return
            if (Regex("^\\d+ (new )?messages?$", RegexOption.IGNORE_CASE).containsMatchIn(bigText)) return
            if (bigText.contains("Checking for new messages", ignoreCase = true)) return
            lines.add(title.ifBlank { "Unknown" } to bigText)
        }

        var lastNew: NotificationHub.Item? = null
        for ((who, text) in lines) {
            val label = if (isGroup && title.isNotBlank() && who != title) "$who in $title" else who
            val item = NotificationHub.Item(System.currentTimeMillis(), source, label, text)
            if (NotificationHub.add(item)) lastNew = item
        }
        val item = lastNew ?: return

        val prefs = com.jarvis.assistant.JarvisApp.instance.preferences
        val chatLike = n.category in CHAT_CATEGORIES || KNOWN.containsKey(pkg)
        if (allowAuto && chatLike) {
            val senderOnly = lines.last().first
            com.jarvis.assistant.announce.Announcer.newMessage(
                applicationContext, senderOnly, source,
                if (isGroup && title.isNotBlank()) title else null, lines.last().second
            )
        }

        if (allowAuto && (pkg == "com.whatsapp" || pkg == "com.whatsapp.w4b") && !isGroup) {
            AutoReplyEngine.maybeHandle(applicationContext, n, item)
        }
    }

    private fun appLabel(pkg: String): String = try {
        val pm = packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        KNOWN[pkg] ?: pkg.removePrefix("com.").removePrefix("org.").removeSuffix(".android").substringBefore('.').replaceFirstChar { it.uppercase() }
    }

    companion object {
        private val KNOWN = mapOf(
            "com.instagram.android" to "Instagram",
            "org.telegram.messenger" to "Telegram",
            "com.snapchat.android" to "Snapchat",
            "com.facebook.katana" to "Facebook",
            "com.facebook.orca" to "Messenger",
            "com.twitter.android" to "X",
            "com.linkedin.android" to "LinkedIn",
            "com.discord" to "Discord",
            "com.google.android.gm" to "Gmail",
            "com.whatsapp" to "WhatsApp",
            "com.whatsapp.w4b" to "WhatsApp Business",
            "com.google.android.apps.messaging" to "SMS",
            "com.samsung.android.messaging" to "SMS",
            "com.android.mms" to "SMS"
        )
        private val CHAT_CATEGORIES = setOf(
            Notification.CATEGORY_MESSAGE, Notification.CATEGORY_EMAIL, Notification.CATEGORY_SOCIAL
        )
        private val NOISE_CATEGORIES = setOf(
            Notification.CATEGORY_TRANSPORT, Notification.CATEGORY_PROGRESS, Notification.CATEGORY_SERVICE,
            Notification.CATEGORY_SYSTEM, Notification.CATEGORY_STATUS, Notification.CATEGORY_ALARM,
            Notification.CATEGORY_ERROR, Notification.CATEGORY_NAVIGATION
        )
    }
}
