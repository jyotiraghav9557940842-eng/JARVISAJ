package com.jarvis.assistant.ui.settings

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.audio.Dsp
import com.jarvis.assistant.audio.VoiceProfile
import com.jarvis.assistant.audio.WakeTemplates
import com.jarvis.assistant.util.JarvisRuntime

/**
 * Guided setup: 3 sentences in the owner's voice, "Jarvis" x3, "Wake up Jarvis" x3, then a test sentence.
 */
class VoiceEnrollDialog(
    private val activity: AppCompatActivity,
    private val onDone: () -> Unit
) {
    private class Step(val kind: Int, val prompt: String, val seconds: Int)

    private val steps = listOf(
        Step(0, "\u0928\u092E\u0938\u094D\u0924\u0947 \u091C\u093E\u0930\u094D\u0935\u093F\u0938, \u092E\u0948\u0902 \u0924\u0941\u092E\u094D\u0939\u093E\u0930\u093E \u092E\u093E\u0932\u093F\u0915 \u092C\u094B\u0932 \u0930\u0939\u093E \u0939\u0942\u0901 \u0914\u0930 \u0906\u091C \u092E\u094C\u0938\u092E \u092C\u0939\u0941\u0924 \u0905\u091A\u094D\u091B\u093E \u0939\u0948\u0964", 7),
        Step(0, "\u092E\u0941\u091D\u0947 \u0905\u092A\u0928\u0947 \u092B\u093C\u094B\u0928 \u0915\u0947 \u0938\u093E\u0930\u0947 \u0915\u093E\u092E \u0938\u093F\u0930\u094D\u092B\u093C \u0906\u0935\u093E\u091C\u093C \u0938\u0947 \u0915\u0930\u0935\u093E\u0928\u0947 \u0939\u0948\u0902, \u0907\u0938\u0932\u093F\u090F \u0927\u094D\u092F\u093E\u0928 \u0938\u0947 \u0938\u0941\u0928\u0928\u093E\u0964", 7),
        Step(0, "\u0938\u0941\u092C\u0939 \u091B\u0939 \u092C\u091C\u0947 \u0915\u093E \u0905\u0932\u093E\u0930\u094D\u092E \u0932\u0917\u093E\u0913 \u0914\u0930 \u092F\u0942\u091F\u094D\u092F\u0942\u092C \u092A\u0930 \u0928\u092F\u093E \u0917\u093E\u0928\u093E \u091A\u0932\u093E\u0913\u0964", 7),
        Step(1, "Sirf ye bolo:  JARVIS", 3),
        Step(1, "Dobara bolo:  JARVIS", 3),
        Step(1, "Ek aur baar:  JARVIS", 3),
        Step(2, "Ab bolo:  WAKE UP JARVIS", 4),
        Step(2, "Dobara bolo:  WAKE UP JARVIS", 4),
        Step(2, "Ek aur baar:  WAKE UP JARVIS", 4),
        Step(3, "\u0906\u091C \u092E\u0947\u0930\u0940 \u0906\u0935\u093E\u091C\u093C \u092A\u0939\u091A\u093E\u0928\u0928\u0947 \u0915\u093E \u091F\u0947\u0938\u094D\u091F \u0939\u0948, \u092C\u0938 \u092E\u0947\u0930\u0940 \u092C\u093E\u0924 \u0938\u0941\u0928\u0928\u093E, \u0915\u093F\u0938\u0940 \u0914\u0930 \u0915\u0940 \u0928\u0939\u0940\u0902\u0964", 7)
    )

    private val ui = Handler(Looper.getMainLooper())
    private val ownerSegs = ArrayList<ShortArray>()
    private val wakeA = ArrayList<Array<FloatArray>>()
    private val wakeB = ArrayList<Array<FloatArray>>()
    private var testPcm: ShortArray? = null
    private var index = 0
    private var recording = false

    private lateinit var dialog: AlertDialog
    private lateinit var tvTitle: TextView
    private lateinit var tvPrompt: TextView
    private lateinit var tvStatus: TextView
    private lateinit var btn: Button

    private var pendingProfile: VoiceProfile? = null
    private var pendingWake: WakeTemplates? = null

    fun show() {
        if (JarvisRuntime.sessionOn) {
            Toast.makeText(activity, "Pehle main screen par Jarvis ko Power se OFF karo, phir Voice Setup karo", Toast.LENGTH_LONG).show()
            return
        }
        if (ContextCompat.checkSelfPermission(activity, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(activity, "Pehle microphone permission do (main screen par Power dabao)", Toast.LENGTH_LONG).show()
            return
        }

        val pad = (20 * activity.resources.displayMetrics.density).toInt()
        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(Color.parseColor("#06121F"))
        }
        tvTitle = TextView(activity).apply {
            setTextColor(Color.parseColor("#1EC8FF"))
            textSize = 13f
            letterSpacing = 0.1f
        }
        tvPrompt = TextView(activity).apply {
            setTextColor(Color.WHITE)
            textSize = 19f
            setPadding(0, pad / 2, 0, pad / 2)
        }
        tvStatus = TextView(activity).apply {
            setTextColor(Color.parseColor("#8FB4CF"))
            textSize = 13f
        }
        btn = Button(activity).apply {
            setBackgroundColor(Color.parseColor("#0B5A99"))
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        root.addView(tvTitle)
        root.addView(tvPrompt)
        root.addView(tvStatus)
        root.addView(btn, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (52 * activity.resources.displayMetrics.density).toInt()).apply { topMargin = pad })

        dialog = AlertDialog.Builder(activity)
            .setView(root)
            .setCancelable(false)
            .setNegativeButton("Band karo") { _, _ -> recording = false }
            .create()
        dialog.show()
        showStep()
    }

    private fun showStep() {
        val st = steps[index]
        tvTitle.text = "STEP ${index + 1} / ${steps.size}"
        tvPrompt.text = st.prompt
        tvStatus.text = if (index == 0) "Shaant jagah par, phone ko muh ke saamne rakho. Button dabao aur upar likha bolo." else "Button dabao aur bolo."
        btn.isEnabled = true
        btn.text = "SHURU KARO"
        btn.setOnClickListener { record(st) }
    }

    @SuppressLint("MissingPermission")
    private fun record(st: Step) {
        if (recording) return
        recording = true
        btn.isEnabled = false
        btn.text = "..."
        Thread {
            val total = Dsp.SR * st.seconds
            val out = ShortArray(total)
            var n = 0
            var ok = true
            try {
                val minBuf = AudioRecord.getMinBufferSize(Dsp.SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val rec = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                    Dsp.SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(minBuf, 8000)
                )
                if (rec.state != AudioRecord.STATE_INITIALIZED) {
                    ok = false
                } else {
                    rec.startRecording()
                    var lastSec = -1
                    while (n < total && recording) {
                        val r = rec.read(out, n, minOf(1600, total - n))
                        if (r <= 0) break
                        n += r
                        val left = st.seconds - n / Dsp.SR
                        if (left != lastSec) {
                            lastSec = left
                            ui.post { tvStatus.text = "Bolo... $left" }
                        }
                    }
                    rec.stop()
                    rec.release()
                }
            } catch (e: Exception) {
                ok = false
            }
            val data = out.copyOf(n)
            ui.post {
                if (!recording) return@post
                recording = false
                if (!ok || n < Dsp.SR) {
                    tvStatus.text = "Mic nahi khula. Jarvis Power OFF hai na? Dobara try karo."
                    btn.isEnabled = true
                    btn.text = "DOBARA"
                } else {
                    afterRecording(st, data)
                }
            }
        }.start()
    }

    private fun afterRecording(st: Step, pcm: ShortArray) {
        val voicedFrames = Dsp.voiced(Dsp.analyze(pcm)).size
        val enough = if (st.kind == 1 || st.kind == 2) voicedFrames >= 25 else voicedFrames >= 150
        if (!enough) {
            tvStatus.text = "Awaaz kam aayi. Thoda zor se aur saaf bolo."
            btn.isEnabled = true
            btn.text = "DOBARA"
            return
        }
        when (st.kind) {
            0 -> ownerSegs.add(pcm)
            1 -> {
                val t = WakeTemplates.extract(pcm)
                if (t == null) {
                    tvStatus.text = "Theek se nahi suna. Dobara bolo."
                    btn.isEnabled = true
                    btn.text = "DOBARA"
                    return
                }
                wakeA.add(t)
            }
            2 -> {
                val t = WakeTemplates.extract(pcm)
                if (t == null) {
                    tvStatus.text = "Theek se nahi suna. Dobara bolo."
                    btn.isEnabled = true
                    btn.text = "DOBARA"
                    return
                }
                wakeB.add(t)
            }
            else -> testPcm = pcm
        }
        index++
        if (index < steps.size) showStep() else finish()
    }

    private fun finish() {
        val base = VoiceProfile.build(ownerSegs)
        val test = testPcm
        val cal = if (base != null && test != null) base.calibrated(test) else null
        val wake = WakeTemplates.build(wakeA, wakeB)
        if (base == null || cal == null || wake == null) {
            fail("Setup poora nahi ho paya (awaaz kam thi). Shaant jagah par dobara karo.")
            return
        }
        pendingProfile = cal.first
        pendingWake = wake
        val score = cal.second
        tvTitle.text = "TEST RESULT"
        if (score <= 2.8f) {
            tvPrompt.text = "Aapki awaaz pehchaan li gayi"
            tvStatus.text = "Match score: ${"%.2f".format(score)} (kam = behtar). Save karoge to Jarvis sirf tumhari awaaz aur 'Jarvis' pe jaagega."
        } else {
            tvPrompt.text = "Awaaz thodi alag lagi"
            tvStatus.text = "Match score: ${"%.2f".format(score)}. Shayad shor tha. Save kar sakte ho, par behtar hai shaant jagah par dobara setup karo."
        }
        btn.isEnabled = true
        btn.text = "SAVE KARO"
        btn.setOnClickListener {
            val prefs = JarvisApp.instance.preferences
            prefs.ownerVoiceProfile = pendingProfile!!.serialize()
            prefs.wakeTemplates = pendingWake!!.serialize()
            prefs.ownerVoiceLock = true
            dialog.dismiss()
            Toast.makeText(activity, "Voice setup save ho gaya", Toast.LENGTH_SHORT).show()
            onDone()
        }
    }

    private fun fail(msg: String) {
        tvTitle.text = "SETUP"
        tvPrompt.text = msg
        tvStatus.text = ""
        ownerSegs.clear(); wakeA.clear(); wakeB.clear(); testPcm = null; index = 0
        btn.isEnabled = true
        btn.text = "DOBARA SHURU KARO"
        btn.setOnClickListener { showStep() }
    }
}
