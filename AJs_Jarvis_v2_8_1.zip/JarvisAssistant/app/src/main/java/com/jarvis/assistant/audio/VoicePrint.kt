package com.jarvis.assistant.audio

import java.util.ArrayDeque
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** Small on-device speech features (MFCC + pitch). No external libraries. */
object Dsp {
    const val SR = 16000
    const val FRAME = 400
    const val HOP = 160
    private const val NFFT = 512
    private const val NMEL = 26
    const val DIM = 25

    class Frame(val c: FloatArray, val f0: Float, val rms: Float)

    private val hamming = FloatArray(FRAME) { (0.54 - 0.46 * cos(2.0 * PI * it / (FRAME - 1))).toFloat() }

    private val melBank: Array<FloatArray> by lazy {
        fun hz2mel(h: Double) = 2595.0 * log10(1.0 + h / 700.0)
        fun mel2hz(m: Double) = 700.0 * (10.0.pow(m / 2595.0) - 1.0)
        val lo = hz2mel(100.0)
        val hi = hz2mel(SR / 2.0 - 200.0)
        val pts = DoubleArray(NMEL + 2) { mel2hz(lo + (hi - lo) * it / (NMEL + 1)) }
        val bins = IntArray(NMEL + 2) { floor((NFFT + 1) * pts[it] / SR).toInt() }
        Array(NMEL) { m ->
            val f = FloatArray(NFFT / 2 + 1)
            if (bins[m + 1] > bins[m]) {
                for (k in bins[m] until bins[m + 1]) f[k] = (k - bins[m]).toFloat() / (bins[m + 1] - bins[m])
            }
            if (bins[m + 2] > bins[m + 1]) {
                for (k in bins[m + 1] until bins[m + 2]) f[k] = (bins[m + 2] - k).toFloat() / (bins[m + 2] - bins[m + 1])
            }
            f
        }
    }

    private val dct = Array(13) { n -> DoubleArray(NMEL) { m -> cos(PI * n * (m + 0.5) / NMEL) } }

    private fun fft(re: DoubleArray, im: DoubleArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) {
                j = j xor bit
                bit = bit shr 1
            }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val ang = -2.0 * PI / len
            val wr = cos(ang)
            val wi = sin(ang)
            val half = len / 2
            var i = 0
            while (i < n) {
                var cr = 1.0
                var ci = 0.0
                for (k in 0 until half) {
                    val a = i + k
                    val b = a + half
                    val vr = re[b] * cr - im[b] * ci
                    val vi = re[b] * ci + im[b] * cr
                    re[b] = re[a] - vr
                    im[b] = im[a] - vi
                    re[a] = re[a] + vr
                    im[a] = im[a] + vi
                    val ncr = cr * wr - ci * wi
                    ci = cr * wi + ci * wr
                    cr = ncr
                }
                i += len
            }
            len = len shl 1
        }
    }

    private fun pitch(x: FloatArray, rms: Float): Float {
        if (rms < 150f) return 0f
        var r0 = 0.0
        for (i in 0 until FRAME) r0 += (x[i] * x[i]).toDouble()
        if (r0 <= 0.0) return 0f
        var best = 0.0
        var bestLag = 0
        for (lag in 40..228) {
            var s = 0.0
            for (i in 0 until FRAME - lag) s += (x[i] * x[i + lag]).toDouble()
            if (s > best) {
                best = s
                bestLag = lag
            }
        }
        return if (bestLag > 0 && best / r0 > 0.35) ln(SR.toDouble() / bestLag).toFloat() else 0f
    }

    fun toShorts(chunks: List<ByteArray>): ShortArray {
        var total = 0
        for (c in chunks) total += c.size / 2
        val out = ShortArray(total)
        var p = 0
        for (c in chunks) {
            var i = 0
            while (i + 1 < c.size) {
                out[p++] = ((c[i].toInt() and 0xFF) or (c[i + 1].toInt() shl 8)).toShort()
                i += 2
            }
        }
        return out
    }

    fun analyze(pcm: ShortArray): List<Frame> {
        val out = ArrayList<Frame>()
        if (pcm.size < FRAME) return out
        val re = DoubleArray(NFFT)
        val im = DoubleArray(NFFT)
        val x = FloatArray(FRAME)
        var start = 0
        while (start + FRAME <= pcm.size) {
            var sum = 0.0
            for (i in 0 until FRAME) {
                x[i] = pcm[start + i].toFloat()
                sum += (x[i] * x[i]).toDouble()
            }
            val rms = sqrt(sum / FRAME).toFloat()
            java.util.Arrays.fill(re, 0.0)
            java.util.Arrays.fill(im, 0.0)
            re[0] = (x[0] * hamming[0]).toDouble()
            for (i in 1 until FRAME) re[i] = ((x[i] - 0.97f * x[i - 1]) * hamming[i]).toDouble()
            fft(re, im)
            val mel = DoubleArray(NMEL)
            for (m in 0 until NMEL) {
                var e = 0.0
                val fb = melBank[m]
                for (k in 0..NFFT / 2) {
                    if (fb[k] != 0f) e += fb[k] * (re[k] * re[k] + im[k] * im[k])
                }
                mel[m] = ln(e + 1e-3)
            }
            val c = FloatArray(12)
            for (n in 1..12) {
                var s = 0.0
                for (m in 0 until NMEL) s += dct[n][m] * mel[m]
                c[n - 1] = s.toFloat()
            }
            out.add(Frame(c, pitch(x, rms), rms))
            start += HOP
        }
        return out
    }

    fun voiceThreshold(fr: List<Frame>): Float {
        if (fr.isEmpty()) return 150f
        val sorted = fr.map { it.rms }.sorted()
        val p90 = sorted[min((sorted.size * 0.9f).toInt(), sorted.size - 1)]
        return max(150f, 0.3f * p90)
    }

    fun voiced(fr: List<Frame>): List<Frame> {
        val thr = voiceThreshold(fr)
        return fr.filter { it.rms >= thr }
    }

    fun embedding(fs: List<Frame>): FloatArray {
        val e = FloatArray(DIM)
        val n = fs.size.toFloat()
        for (d in 0 until 12) {
            var m = 0f
            for (f in fs) m += f.c[d]
            m /= n
            var v = 0f
            for (f in fs) {
                val t = f.c[d] - m
                v += t * t
            }
            e[d] = m
            e[12 + d] = sqrt(v / n)
        }
        var s = 0f
        var k = 0
        for (f in fs) {
            if (f.f0 > 0f) {
                s += f.f0
                k++
            }
        }
        e[24] = if (k >= 10) s / k else 0f
        return e
    }

    fun windows(fs: List<Frame>, size: Int = 100, hop: Int = 25): List<FloatArray> {
        val out = ArrayList<FloatArray>()
        var i = 0
        while (i + size <= fs.size) {
            out.add(embedding(fs.subList(i, i + size)))
            i += hop
        }
        return out
    }
}

/** The owner's voice "fingerprint" (average sound + how much it normally varies). */
class VoiceProfile(val mean: FloatArray, val std: FloatArray, val thr: Float) {

    fun distance(x: FloatArray): Float {
        var s = 0f
        var n = 0
        for (i in 0 until Dsp.DIM) {
            if (i == 24 && (x[i] == 0f || mean[i] == 0f)) continue
            val z = (x[i] - mean[i]) / std[i]
            s += z * z
            n++
        }
        return sqrt(s / max(n, 1))
    }

    fun serialize(): String = (mean.toList() + std.toList() + listOf(thr)).joinToString(",")

    /** Uses the owner's test sentence to set how strict the match should be. Returns profile + average test score. */
    fun calibrated(testPcm: ShortArray): Pair<VoiceProfile, Float>? {
        val fs = Dsp.voiced(Dsp.analyze(testPcm))
        if (fs.size < 60) return null
        val wins = if (fs.size >= 100) Dsp.windows(fs) else listOf(Dsp.embedding(fs))
        val d = wins.map { distance(it) }
        val avg = d.average().toFloat()
        val t = (avg * 1.3f + 0.3f).coerceIn(1.8f, 3.2f)
        return Pair(VoiceProfile(mean, std, t), avg)
    }

    companion object {
        fun parse(s: String): VoiceProfile? = try {
            val p = s.split(",")
            if (p.size != Dsp.DIM * 2 + 1) {
                null
            } else {
                val f = p.map { it.toFloat() }
                VoiceProfile(
                    f.subList(0, Dsp.DIM).toFloatArray(),
                    f.subList(Dsp.DIM, Dsp.DIM * 2).toFloatArray(),
                    f[Dsp.DIM * 2]
                )
            }
        } catch (e: Exception) {
            null
        }

        fun build(segments: List<ShortArray>): VoiceProfile? {
            val all = ArrayList<Dsp.Frame>()
            for (s in segments) all.addAll(Dsp.voiced(Dsp.analyze(s)))
            val wins = Dsp.windows(all)
            if (wins.size < 8) return null
            val mean = FloatArray(Dsp.DIM)
            val std = FloatArray(Dsp.DIM)
            for (i in 0 until Dsp.DIM) {
                val vals = wins.map { it[i] }.filter { i != 24 || it != 0f }
                if (vals.isEmpty()) {
                    mean[i] = 0f
                    std[i] = 1f
                    continue
                }
                val m = vals.average().toFloat()
                var v = 0f
                for (x in vals) v += (x - m) * (x - m)
                val sd = sqrt(v / vals.size)
                val floor = when {
                    i < 12 -> 0.6f
                    i < 24 -> 0.35f
                    else -> 0.05f
                }
                mean[i] = m
                std[i] = max(sd, floor)
            }
            return VoiceProfile(mean, std, 2.2f)
        }
    }
}

/**
 * Lets only the owner's speech through. Waits ~1 second of a new utterance, checks whose voice it is,
 * then either forwards the whole utterance (owner) or drops it (anyone else).
 */
class OwnerVoiceGate(private val profile: VoiceProfile, private val factor: Float) {
    private var state = 0 // 0 idle, 1 undecided, 2 pass, 3 reject
    private var quiet = 0
    private val pre = ArrayDeque<ByteArray>()
    private val buf = ArrayList<ByteArray>()

    fun process(chunk: ByteArray, amplitude: Float, send: (ByteArray) -> Unit): Boolean {
        if (chunk.isEmpty()) return false
        val loud = amplitude > 0.08f
        when (state) {
            0 -> {
                pre.addLast(chunk)
                while (pre.size > 8) pre.removeFirst()
                if (loud) {
                    state = 1
                    buf.clear()
                    buf.addAll(pre)
                    pre.clear()
                    quiet = 0
                }
                return false
            }
            1 -> {
                buf.add(chunk)
                if (loud) quiet = 0 else quiet++
                if (buf.size >= 30 || quiet >= 20) decide(send)
                return state == 2
            }
            2 -> {
                send(chunk)
                if (loud) quiet = 0 else quiet++
                if (quiet >= 25) state = 0
                return true
            }
            else -> {
                if (loud) quiet = 0 else quiet++
                if (quiet >= 20) state = 0
                return false
            }
        }
    }

    private fun decide(send: (ByteArray) -> Unit) {
        val fs = Dsp.voiced(Dsp.analyze(Dsp.toShorts(buf)))
        var ok = false
        if (fs.size >= 25) {
            val d = profile.distance(Dsp.embedding(fs.take(100)))
            val limit = profile.thr * factor * (if (fs.size < 60) 1.15f else 1f)
            ok = d <= limit
        }
        if (ok) {
            state = 2
            for (c in buf) send(c)
        } else {
            state = 3
        }
        buf.clear()
    }
}

/** Personal "Jarvis" / "Wake up Jarvis" templates recorded by the owner. */
class WakeTemplates(val templates: List<Array<FloatArray>>, val thr: Float) {

    fun serialize(): String {
        val sb = StringBuilder()
        sb.append(thr)
        for (t in templates) {
            sb.append('|')
            sb.append(t.joinToString(";") { fr -> fr.joinToString(",") { v -> "%.2f".format(java.util.Locale.US, v) } })
        }
        return sb.toString()
    }

    companion object {
        fun parse(s: String): WakeTemplates? = try {
            val parts = s.split("|")
            val thr = parts[0].toFloat()
            val list = parts.drop(1).filter { it.isNotEmpty() }.map { t ->
                t.split(";").map { fr -> fr.split(",").map { it.toFloat() }.toFloatArray() }.toTypedArray()
            }
            if (list.isEmpty()) null else WakeTemplates(list, thr)
        } catch (e: Exception) {
            null
        }

        /** Cuts silence and turns one spoken word/phrase into a compact sequence of sound frames. */
        fun extract(pcm: ShortArray): Array<FloatArray>? {
            val fr = Dsp.analyze(pcm)
            if (fr.size < 30) return null
            val thr = Dsp.voiceThreshold(fr)
            val first = fr.indexOfFirst { it.rms >= thr }
            val last = fr.indexOfLast { it.rms >= thr }
            if (first < 0 || last - first < 25) return null
            val seg = fr.subList(first, last + 1)
            val out = ArrayList<FloatArray>()
            var i = 0
            while (i < seg.size) {
                out.add(seg[i].c)
                i += 2
            }
            return out.toTypedArray()
        }

        private fun dist(a: FloatArray, b: FloatArray): Float {
            var s = 0f
            for (i in a.indices) {
                val d = a[i] - b[i]
                s += d * d
            }
            return sqrt(s)
        }

        /** How well template t matches the START of utterance u (lower = better). */
        fun dtwPrefix(t: Array<FloatArray>, u: Array<FloatArray>): Float {
            val n = t.size
            val m = min(u.size, n * 2 + 10)
            if (m < n / 2 || n == 0) return Float.MAX_VALUE
            val inf = 1e9f
            var prev = FloatArray(m) { inf }
            var cur = FloatArray(m) { inf }
            for (i in 0 until n) {
                for (j in 0 until m) {
                    val cost = dist(t[i], u[j])
                    var b = inf
                    if (i == 0 && j == 0) {
                        b = 0f
                    } else {
                        if (j > 0) b = min(b, cur[j - 1])
                        if (i > 0) b = min(b, prev[j])
                        if (i > 0 && j > 0) b = min(b, prev[j - 1])
                    }
                    cur[j] = if (b >= inf) inf else b + cost
                }
                val tmp = prev
                prev = cur
                cur = tmp
            }
            var res = Float.MAX_VALUE
            for (j in max(0, n / 2) until m) {
                val v = prev[j] / (n + j + 1)
                if (v < res) res = v
            }
            return res
        }

        fun build(a: List<Array<FloatArray>>, b: List<Array<FloatArray>>): WakeTemplates? {
            if (a.size < 2 || b.size < 2) return null
            val scores = ArrayList<Float>()
            for (group in listOf(a, b)) {
                for (i in group.indices) {
                    for (j in group.indices) {
                        if (i != j) scores.add(dtwPrefix(group[i], group[j]))
                    }
                }
            }
            val inAvg = scores.average().toFloat()
            return WakeTemplates(a + b, (inAvg * 1.6f).coerceAtLeast(inAvg + 0.5f))
        }
    }
}

/**
 * Standby listener: says "wake" only when it hears the owner's recorded "Jarvis" / "Wake up Jarvis"
 * at the start of an utterance. Returns the audio of that utterance so it isn't lost.
 */
class WakeWordDetector(
    private val wake: WakeTemplates,
    private val owner: VoiceProfile?,
    private val factor: Float
) {
    private var state = 0 // 0 idle, 1 collecting, 2 skipping until silence
    private var quiet = 0
    private val pre = ArrayDeque<ByteArray>()
    private val buf = ArrayList<ByteArray>()

    fun process(chunk: ByteArray, amplitude: Float): List<ByteArray>? {
        if (chunk.isEmpty()) return null
        val loud = amplitude > 0.08f
        when (state) {
            0 -> {
                pre.addLast(chunk)
                while (pre.size > 8) pre.removeFirst()
                if (loud) {
                    state = 1
                    buf.clear()
                    buf.addAll(pre)
                    pre.clear()
                    quiet = 0
                }
                return null
            }
            1 -> {
                buf.add(chunk)
                if (loud) quiet = 0 else quiet++
                if (quiet >= 12 || buf.size >= 45) {
                    val hit = evaluate()
                    val out: List<ByteArray>? = if (hit) ArrayList(buf) else null
                    buf.clear()
                    state = if (hit) 0 else if (quiet >= 12) 0 else 2
                    return out
                }
                return null
            }
            else -> {
                if (loud) quiet = 0 else quiet++
                if (quiet >= 12) state = 0
                return null
            }
        }
    }

    private fun evaluate(): Boolean {
        val pcm = Dsp.toShorts(buf)
        val u = WakeTemplates.extract(pcm) ?: return false
        var best = Float.MAX_VALUE
        for (t in wake.templates) {
            val d = WakeTemplates.dtwPrefix(t, u)
            if (d < best) best = d
        }
        if (best > wake.thr * factor) return false
        if (owner != null) {
            val fs = Dsp.voiced(Dsp.analyze(pcm))
            if (fs.size < 20) return false
            val d = owner.distance(Dsp.embedding(fs.take(100)))
            if (d > owner.thr * factor * 1.3f) return false
        }
        return true
    }
}
