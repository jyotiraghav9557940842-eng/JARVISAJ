package com.jarvis.assistant.data.repository

import android.content.Context
import com.jarvis.assistant.JarvisApp

/** Profile, safety level, voice mood, recent activity and pending tasks that go into every new session. */
object PersonalContext {

    fun isRestricted(): Boolean {
        val p = JarvisApp.instance.preferences
        return p.kidsMode || (p.userAge in 1..17)
    }

    fun build(context: Context): String {
        val p = JarvisApp.instance.preferences
        val sb = StringBuilder()

        val prof = StringBuilder()
        if (p.userAge > 0) prof.append("Age: ${p.userAge}. ")
        if (p.likes.isNotBlank()) prof.append("Likes: ${p.likes.trim()}. ")
        if (p.dislikes.isNotBlank()) prof.append("Dislikes: ${p.dislikes.trim()}. ")
        if (prof.isNotEmpty()) {
            sb.append("[ABOUT THE USER - use to personalise, never recite]\n").append(prof).append("\n\n")
        }

        sb.append("[SAFETY]\n")
        when {
            p.kidsMode || (p.userAge in 1..12) ->
                sb.append("CHILD-SAFE MODE ON. Use simple, gentle words. No violence, scary, adult, romantic or abusive content, no bad words, no risky challenges. Search and play only child-suitable things. If asked for something unsuitable, kindly say it is not for now and suggest something fun and suitable. Do not reveal personal details.\n\n")
            p.userAge in 13..17 ->
                sb.append("TEEN-SAFE MODE. Keep content suitable for a teenager: no adult, graphic, violent, drug or self-harm content, and treat risky topics with care and honesty. Search and play only teen-suitable things.\n\n")
            else ->
                sb.append("Normal safety. If the user says a child is listening, call set_kids_mode on.\n\n")
        }

        sb.append("[VOICE MOOD]\n")
        sb.append(when (p.voiceMood) {
            1 -> "Normal, natural and friendly."
            2 -> "Calm: soft, slow, soothing."
            3 -> "Energetic: upbeat and lively, but still natural."
            else -> "Auto: calm and soft late at night or when the user is tired or sad, lively when they are excited or playing, otherwise normal."
        }).append(" Never over the top: no shouting, no fake excitement, no long dramatic sounds.\n\n")

        val recent = ActivityLog.all(context).takeLast(15)
        if (recent.isNotEmpty()) {
            sb.append("[RECENT ACTIVITY on this phone - use to understand 'wahi', 'phir se', 'jo kal dekha tha']\n")
            recent.forEach { sb.append("- ").append(ActivityLog.whenText(it.time)).append(": ").append(it.text).append('\n') }
            sb.append('\n')
        }

        val tasks = TaskStore.pending(context).take(8)
        if (tasks.isNotEmpty()) {
            sb.append("[PENDING TASKS / HOMEWORK]\n")
            tasks.forEach {
                sb.append("- ").append(it.title)
                if (it.due.isNotBlank()) sb.append(" (due ").append(it.due).append(')')
                sb.append('\n')
            }
        }
        return sb.toString()
    }
}
