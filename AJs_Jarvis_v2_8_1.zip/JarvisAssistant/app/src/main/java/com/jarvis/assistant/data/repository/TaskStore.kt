package com.jarvis.assistant.data.repository

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Homework / to-do list. */
object TaskStore {
    private const val PREFS = "jarvis_tasks"
    private const val KEY = "tasks"

    class Task(val title: String, val due: String, val done: Boolean)

    private fun read(context: Context): JSONArray {
        val sp = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return try { JSONArray(sp.getString(KEY, "[]")) } catch (e: Exception) { JSONArray() }
    }

    private fun write(context: Context, arr: JSONArray) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).apply()
    }

    @Synchronized
    fun add(context: Context, title: String, due: String) {
        val arr = read(context)
        arr.put(JSONObject().put("title", title.take(120)).put("due", due.take(40)).put("done", false))
        write(context, arr)
    }

    @Synchronized
    fun all(context: Context): List<Task> {
        val arr = read(context)
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Task(o.getString("title"), o.optString("due"), o.optBoolean("done"))
        }
    }

    fun pending(context: Context): List<Task> = all(context).filter { !it.done }

    @Synchronized
    fun complete(context: Context, keyword: String): Int {
        val k = keyword.trim().lowercase()
        if (k.isEmpty()) return 0
        val arr = read(context)
        var n = 0
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (!o.optBoolean("done") && o.getString("title").lowercase().contains(k)) {
                o.put("done", true)
                n++
            }
        }
        write(context, arr)
        return n
    }
}
