package com.jarvis.assistant.camera

import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.YuvImage
import android.os.SystemClock
import android.util.Log
import android.util.Size
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

/** Shows a live camera preview and hands ~1 JPEG frame per second to [onFrame] for Jarvis to see. */
class CameraStreamer(
    private val activity: AppCompatActivity,
    private val previewView: PreviewView,
    private val onFrame: (ByteArray) -> Unit
) {
    private var provider: ProcessCameraProvider? = null
    private var useFront = true
    var isRunning = false
        private set
    private val executor = Executors.newSingleThreadExecutor()
    private var lastSent = 0L

    fun start() {
        val future = ProcessCameraProvider.getInstance(activity)
        future.addListener({
            try {
                provider = future.get()
                isRunning = true
                bind()
            } catch (e: Exception) {
                Log.e(TAG, "Camera start failed: ${e.message}")
                isRunning = false
            }
        }, ContextCompat.getMainExecutor(activity))
    }

    fun flip(): Boolean {
        useFront = !useFront
        if (isRunning) bind()
        return useFront
    }

    fun stop() {
        isRunning = false
        try { provider?.unbindAll() } catch (_: Exception) {}
    }

    private fun bind() {
        val p = provider ?: return
        val preview = Preview.Builder().build().also {
            it.setSurfaceProvider(previewView.surfaceProvider)
        }
        val analysis = ImageAnalysis.Builder()
            .setTargetResolution(Size(480, 640))
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .build()
        analysis.setAnalyzer(executor) { image -> handle(image) }
        val selector = if (useFront) CameraSelector.DEFAULT_FRONT_CAMERA
        else CameraSelector.DEFAULT_BACK_CAMERA
        try {
            p.unbindAll()
            p.bindToLifecycle(activity, selector, preview, analysis)
        } catch (e: Exception) {
            Log.e(TAG, "Camera bind failed: ${e.message}")
        }
    }

    private fun handle(image: ImageProxy) {
        try {
            val now = SystemClock.elapsedRealtime()
            if (now - lastSent < FRAME_GAP_MS) return
            lastSent = now
            val jpeg = toJpeg(image) ?: return
            onFrame(jpeg)
        } catch (e: Exception) {
            Log.e(TAG, "Frame error: ${e.message}")
        } finally {
            image.close()
        }
    }

    private fun toJpeg(image: ImageProxy): ByteArray? {
        val w = image.width
        val h = image.height
        val yP = image.planes[0]
        val uP = image.planes[1]
        val vP = image.planes[2]
        val nv21 = ByteArray(w * h * 3 / 2)
        val yBuf = yP.buffer
        var pos = 0
        for (row in 0 until h) {
            yBuf.position(row * yP.rowStride)
            yBuf.get(nv21, pos, w)
            pos += w
        }
        val uBuf = uP.buffer
        val vBuf = vP.buffer
        for (row in 0 until h / 2) {
            for (col in 0 until w / 2) {
                val vi = row * vP.rowStride + col * vP.pixelStride
                val ui = row * uP.rowStride + col * uP.pixelStride
                nv21[pos++] = vBuf.get(vi)
                nv21[pos++] = uBuf.get(ui)
            }
        }
        val out = ByteArrayOutputStream()
        YuvImage(nv21, ImageFormat.NV21, w, h, null)
            .compressToJpeg(Rect(0, 0, w, h), 70, out)
        var jpeg = out.toByteArray()

        val rot = image.imageInfo.rotationDegrees
        if (rot != 0) {
            val bmp = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size) ?: return jpeg
            val m = Matrix().apply { postRotate(rot.toFloat()) }
            val rotated = android.graphics.Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            val o2 = ByteArrayOutputStream()
            rotated.compress(android.graphics.Bitmap.CompressFormat.JPEG, 70, o2)
            jpeg = o2.toByteArray()
            bmp.recycle()
            rotated.recycle()
        }
        return jpeg
    }

    companion object {
        private const val TAG = "CameraStreamer"
        private const val FRAME_GAP_MS = 900L
    }
}
