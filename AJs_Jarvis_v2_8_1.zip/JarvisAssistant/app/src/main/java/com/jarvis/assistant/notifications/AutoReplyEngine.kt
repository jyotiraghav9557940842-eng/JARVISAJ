package com.jarvis.assistant.notifications

import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.data.repository.MemoryStore
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Replies to simple, safe WhatsApp chat messages on the owner's behalf.
 * Off by default; only for names the owner listed in Settings (or "all"). Never for groups.
 */
object AutoReplyEngine {
    private const val TAG = "AutoReply"
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    fun maybeHandle(context: Context, n: Notification, item: NotificationHub.Item) {
        val prefs = JarvisApp.instance.preferences
        if (!prefs.autoHandle || prefs.apiKey.isBlank()) return
        if (!allowed(prefs.autoHandleContacts, item.sender)) return
        val action = n.actions?.firstOrNull { a ->
            a.remoteInputs?.isNotEmpty() == true &&
                (a.title?.toString()?.contains("reply", ignoreCase = true) == true ||
                    (android.os.Build.VERSION.SDK_INT >= 28 && a.semanticAction == Notification.Action.SEMANTIC_ACTION_REPLY))
        } ?: return
        if (!NotificationHub.canAutoReply(item.sender)) return

        Thread {
            try {
                val decision = askGemini(context, prefs.apiKey.trim(), prefs.userName, item)
                val act = decision.optString("action")
                val reply = decision.optString("reply").trim()
                if (act == "reply" && reply.isNotEmpty() && reply.length < 300) {
                    val ri = action.remoteInputs[0]
                    val intent = Intent()
                    val bundle = Bundle()
                    bundle.putCharSequence(ri.resultKey, reply)
                    RemoteInput.addResultsToIntent(action.remoteInputs, intent, bundle)
                    action.actionIntent.send(context, 0, intent)
                    NotificationHub.noteReplied(item.sender)
                    item.handled = "auto-replied: \"$reply\""
                } else {
                    item.handled = "needs the owner (left for you)"
                }
            } catch (e: Exception) {
                Log.e(TAG, "auto reply failed: ${e.message}")
            }
        }.start()
    }

    private fun allowed(list: String, sender: String): Boolean {
        val names = list.split(',', '\n', ';').map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        if (names.isEmpty()) return false
        if (names.any { it == "all" || it == "sab" }) return true
        val s = sender.lowercase()
        return names.any { s.contains(it) || it.contains(s) }
    }

    private fun askGemini(context: Context, key: String, owner: String, item: NotificationHub.Item): JSONObject {
        val facts = MemoryStore(context).facts().takeLast(20).joinToString("; ")
        val system = "You are the personal message assistant of $owner. Decide whether you can safely answer " +
            "this incoming WhatsApp chat message on their behalf. REPLY only to simple, casual messages " +
            "(greetings, how are you, where are you, are you free, thanks) with one very short, polite, " +
            "NON-COMMITTAL reply in the same language and tone as the message (Hinglish is fine). Never promise " +
            "anything, never agree to plans, meetings or money, never share location, numbers or personal details. " +
            "SKIP (leave it for the owner) if the message involves money, payment, UPI, bank, OTP, passwords, " +
            "links, work decisions, emergencies, health, legal matters, romance or strong emotions, secrets, " +
            "anything needing the owner's real decision, or if the sender asks whether they are talking to a bot or AI. " +
            "Known facts about the owner: $facts. " +
            "Output ONLY JSON: {\"action\":\"reply\" or \"skip\",\"reply\":\"text\",\"reason\":\"short\"}"
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", JSONArray().put(JSONObject()
                .put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", "Sender: ${item.sender}\nMessage: ${item.text}")))))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("temperature", 0.4))
        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$key")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(req).execute().use { resp ->
            val txt = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) throw RuntimeException("HTTP ${resp.code}")
            val out = JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            return JSONObject(out.replace("```json", "").replace("```", "").trim())
        }
    }
}
