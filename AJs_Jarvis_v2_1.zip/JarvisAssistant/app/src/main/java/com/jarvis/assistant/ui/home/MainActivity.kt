package com.jarvis.assistant.ui.home

import android.Manifest
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.LinearGradient
import android.graphics.Shader
import android.app.ActivityManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableString
import android.text.style.RelativeSizeSpan
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.snackbar.Snackbar
import com.jarvis.assistant.R
import com.jarvis.assistant.util.ThemeManager
import com.jarvis.assistant.data.model.ConversationState
import com.jarvis.assistant.databinding.ActivityMainBinding
import com.jarvis.assistant.ui.chat.ChatHistoryBottomSheet
import com.jarvis.assistant.ui.orb.OrbHelper
import com.jarvis.assistant.ui.settings.SettingsActivity
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import com.jarvis.assistant.JarvisApp
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    // Stored on the Application so the voice session survives when the screen is closed (Always-on mode).
    private val viewModel: MainViewModel by lazy {
        androidx.lifecycle.ViewModelProvider(
            JarvisApp.instance,
            androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.getInstance(application)
        )[MainViewModel::class.java]
    }
    private lateinit var orbHelper: OrbHelper

    private val requestAudioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        val micGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (micGranted) {
            viewModel.toggleSession()
        } else {
            Toast.makeText(
                this,
                "Microphone permission is required for voice conversation.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.apply(this)
        appliedThemeKey = ThemeManager.key()
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        viewModel.startIfAlwaysOn()

        setupOrb()
        setupListeners()
        observeViewModel()
        styleTexts()
        playEntranceAnimation()
    }

    private var appliedThemeKey = ""

    private var cameraStreamer: com.jarvis.assistant.camera.CameraStreamer? = null

    private val requestCameraPermissionLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            startCamera()
        } else {
            android.widget.Toast.makeText(this, "Camera permission chahiye", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    private fun startCamera() {
        if (cameraStreamer == null) {
            cameraStreamer = com.jarvis.assistant.camera.CameraStreamer(
                this, binding.previewCamera
            ) { jpeg -> viewModel.sendVideoFrame(jpeg) }
        }
        binding.cardCamera.visibility = android.view.View.VISIBLE
        cameraStreamer?.start()
        val msg = if (viewModel.isSessionOn.value) "Camera ON - Jarvis ab dekh sakta hai"
        else "Camera ON - Jarvis ko power ON karo, tab wo dekhega"
        android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_SHORT).show()
    }

    private fun stopCamera() {
        cameraStreamer?.stop()
        binding.cardCamera.visibility = android.view.View.GONE
    }

    private fun applyOrbAccent() {
        val c = ThemeManager.color(this, R.attr.primary_cyan)
        val c2 = ThemeManager.color(this, R.attr.purple_glow)
        orbHelper.setAccent(
            android.graphics.Color.red(c), android.graphics.Color.green(c), android.graphics.Color.blue(c),
            android.graphics.Color.red(c2), android.graphics.Color.green(c2), android.graphics.Color.blue(c2),
            ThemeManager.isLight()
        )
    }

    override fun onResume() {
        super.onResume()
        if (appliedThemeKey != ThemeManager.key()) {
            recreate()
            return
        }
        viewModel.refreshSettings()
    }

    // Gradient text for the "MADE BY AJ SIR" credit and the app title.
    private fun styleTexts() {
        applyGradientText(
            binding.tvMadeBy,
            ContextCompat.getColor(this, R.color.aj_gold_soft),
            ContextCompat.getColor(this, R.color.aj_gold)
        )
        applyGradientText(
            binding.tvJarvisTitle,
            ThemeManager.color(this, R.attr.primary_cyan),
            ThemeManager.color(this, R.attr.purple_glow)
        )
    }

    private fun applyGradientText(tv: TextView, startColor: Int, endColor: Int) {
        tv.post {
            val textWidth = tv.paint.measureText(tv.text.toString())
            tv.paint.shader = LinearGradient(
                0f, 0f, textWidth, 0f,
                intArrayOf(startColor, endColor),
                null,
                Shader.TileMode.CLAMP
            )
            tv.invalidate()
        }
    }

    // "07:32 PM" with a smaller AM/PM, like the HUD reference.
    private fun showClock(time: String) {
        val sp = SpannableString(time)
        val idx = time.indexOf(' ')
        if (idx > 0) {
            sp.setSpan(RelativeSizeSpan(0.7f), idx, time.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        binding.tvLiveTime.text = sp
    }

    private fun updateStats() {
        try {
            val country = java.util.Locale.getDefault().displayCountry.uppercase()
            binding.tvStatLoc.text = if (country.isBlank()) "INDIA" else country
        } catch (e: Exception) { }
        try {
            val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            binding.tvStatBattery.text = if (level >= 0 && scale > 0) "${level * 100 / scale}%" else "--"

            val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            val used = 100 - (mi.availMem * 100 / mi.totalMem).toInt()
            binding.tvStatRam.text = "$used%"

            val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            binding.tvStatNet.text = when {
                caps == null -> "OFFLINE"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WI-FI"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "MOBILE"
                else -> "ONLINE"
            }
        } catch (e: Exception) {
            // Stats are only decoration; ignore any failure.
        }
    }

    private fun updateDateUi() {
        val now = Date()
        binding.tvDateNum.text = SimpleDateFormat("dd", Locale.ENGLISH).format(now)
        binding.tvDateMonth.text = SimpleDateFormat("MMM", Locale.ENGLISH).format(now).uppercase()
        binding.tvDateDay.text = SimpleDateFormat("EEEE", Locale.ENGLISH).format(now).uppercase()
    }

    private fun playEntranceAnimation() {
        val views: List<View> = listOf(
            binding.boxMadeBy,
            binding.topBar,
            binding.subInfoBar,
            binding.hudClockRow,
            binding.orbContainer,
            binding.boxState,
            binding.controlsLayout
        )
        views.forEachIndexed { index, view ->
            view.alpha = 0f
            view.translationY = 24f
            view.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(index * 90L)
                .setDuration(550)
                .start()
        }
    }

    private fun setupOrb() {
        orbHelper = OrbHelper(binding.webViewOrb)
        orbHelper.setup()
    }

    private fun setupListeners() {
        binding.btnSettings.setOnClickListener {
            val intent = Intent(this, SettingsActivity::class.java)
            startActivity(intent)
        }

        binding.btnPowerSession.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            val wanted = mutableListOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE
            )
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                wanted.add(Manifest.permission.POST_NOTIFICATIONS)
            }
            val missing = wanted.filter {
                ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
            }
            if (missing.isEmpty() || viewModel.isSessionOn.value) {
                viewModel.toggleSession()
            } else {
                requestAudioPermissionLauncher.launch(missing.toTypedArray())
            }
        }

        binding.btnCamera.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            if (cameraStreamer?.isRunning == true) {
                stopCamera()
            } else if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
                startCamera()
            } else {
                requestCameraPermissionLauncher.launch(Manifest.permission.CAMERA)
            }
        }

        binding.btnFlipCamera.setOnClickListener {
            val front = cameraStreamer?.flip() ?: true
            android.widget.Toast.makeText(
                this, if (front) "Front camera" else "Back camera", android.widget.Toast.LENGTH_SHORT
            ).show()
        }

        binding.btnSleep.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            if (viewModel.isSessionOn.value) {
                viewModel.toggleSession()
            } else {
                android.widget.Toast.makeText(this, "Jarvis pehle se sleep mode me hai", android.widget.Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnHistory.setOnClickListener { showChatHistory() }

        val openSettings = View.OnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        binding.menuSettings.setOnClickListener(openSettings)
        binding.menuMore.setOnClickListener(openSettings)
        binding.menuVoice.setOnClickListener(openSettings)
        binding.menuApps.setOnClickListener {
            android.widget.Toast.makeText(this, "Bolo: 'WhatsApp kholo' ya 'YouTube chalao'", android.widget.Toast.LENGTH_LONG).show()
        }
        binding.menuInternet.setOnClickListener {
            android.widget.Toast.makeText(this, "Bolo: 'Google par search karo ...'", android.widget.Toast.LENGTH_LONG).show()
        }
        binding.menuKnowledge.setOnClickListener {
            android.widget.Toast.makeText(this, "Kuch bhi poochho, Jarvis jawab dega", android.widget.Toast.LENGTH_LONG).show()
        }

        binding.btnMicMute.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            viewModel.toggleMicMute()
        }

        binding.tvViewHistory.setOnClickListener {
            showChatHistory()
        }

        binding.boxJarvisTitle.setOnClickListener {
            showChatHistory()
        }
    }

    private fun showChatHistory() {
        ChatHistoryBottomSheet.newInstance().show(
            supportFragmentManager,
            ChatHistoryBottomSheet.TAG
        )
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.liveTime.collect { time ->
                        showClock(time)
                        updateDateUi()
                        updateStats()
                    }
                }

                launch {
                    viewModel.greeting.collect { greeting ->
                        binding.tvGreeting.text = greeting
                    }
                }

                launch {
                    viewModel.orbTheme.collect { theme ->
                        orbHelper.setTheme(theme)
                        applyOrbAccent()
                    }
                }

                launch {
                    viewModel.sessionSeconds.collect {
                        updateTimerUi()
                    }
                }

                launch {
                    viewModel.personalityName.collect { personality ->
                        binding.tvPersonalityMode.text = personality
                    }
                }

                launch {
                    viewModel.isSessionOn.collect { isOn ->
                        updatePowerButtonUi(isOn)
                    }
                }

                launch {
                    viewModel.isMicMuted.collect { isMuted ->
                        updateMicMuteUi(isMuted)
                    }
                }

                launch {
                    viewModel.conversationState.collect { state ->
                        updateConversationStateUi(state)
                    }
                }

                launch {
                    viewModel.audioLevel.collect { level ->
                        orbHelper.updateAudioLevel(level)
                        binding.ivWave.scaleY = 0.5f + level.coerceIn(0f, 1f) * 1.6f
                    }
                }

                launch {
                    viewModel.connectionStatus.collect { status ->
                        updateConnectionStatusUi(status)
                    }
                }

                launch {
                    viewModel.eventFlow.collect { message ->
                        Snackbar.make(binding.root, message, Snackbar.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    private fun updateTimerUi() {
        if (viewModel.isSessionOn.value) {
            val total = viewModel.sessionSeconds.value
            binding.tvSessionTimer.text = String.format("%02d:%02d", total / 60, total % 60)
            binding.tvSessionTimer.setTextColor(ThemeManager.color(this, R.attr.text_secondary))
        } else {
            binding.tvSessionTimer.text = getString(R.string.hint_idle)
            binding.tvSessionTimer.setTextColor(ThemeManager.color(this, R.attr.text_muted))
        }
    }

    private fun updatePowerButtonUi(isOn: Boolean) {
        // Keep the screen awake while a voice session is running.
        if (isOn) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        updateTimerUi()

        if (isOn) {
            binding.btnPowerSession.setBackgroundResource(R.drawable.bg_power_button)
            binding.ivPowerIcon.imageTintList = ColorStateList.valueOf(
                ThemeManager.color(this, R.attr.primary_cyan)
            )
            binding.tvPowerText.text = getString(R.string.btn_on)
            binding.tvPowerText.setTextColor(
                ThemeManager.color(this, R.attr.primary_cyan)
            )
        } else {
            binding.btnPowerSession.setBackgroundResource(R.drawable.bg_power_button_off)
            binding.ivPowerIcon.imageTintList = ColorStateList.valueOf(
                ThemeManager.color(this, R.attr.text_muted)
            )
            binding.tvPowerText.text = getString(R.string.btn_off)
            binding.tvPowerText.setTextColor(
                ThemeManager.color(this, R.attr.text_muted)
            )
        }
    }

    private fun updateMicMuteUi(isMuted: Boolean) {
        if (isMuted) {
            binding.btnMicMute.setImageResource(R.drawable.ic_mic_off)
            binding.btnMicMute.imageTintList = ColorStateList.valueOf(
                ContextCompat.getColor(this, R.color.status_red)
            )
        } else {
            binding.btnMicMute.setImageResource(R.drawable.ic_mic)
            binding.btnMicMute.imageTintList = ColorStateList.valueOf(
                ThemeManager.color(this, R.attr.primary_cyan)
            )
        }
    }

    private fun updateConversationStateUi(state: ConversationState) {
        binding.tvConversationState.text = state.displayName
        val colorRes = when (state) {
            ConversationState.IDLE -> R.attr.text_secondary
            ConversationState.LISTENING -> R.attr.primary_cyan
            ConversationState.THINKING -> R.attr.purple_glow
            ConversationState.SPEAKING -> R.attr.neon_blue
        }
        binding.tvConversationState.setTextColor(ThemeManager.color(this, colorRes))
        orbHelper.updateState(state)
    }

    private fun updateConnectionStatusUi(status: String) {
        // Short labels so the pill never collides with the power button.
        binding.tvConnectionStatus.text = when (status) {
            "CONNECTING..." -> "CONNECTING"
            "RECONNECTING..." -> "RETRYING"
            else -> status
        }
        val dotColor = when (status) {
            "LIVE" -> ContextCompat.getColor(this, R.color.status_green)
            "CONNECTING...", "RECONNECTING..." -> ContextCompat.getColor(this, R.color.status_amber)
            else -> ThemeManager.color(this, R.attr.text_muted)
        }
        binding.viewStatusDot.backgroundTintList = ColorStateList.valueOf(dotColor)
    }

    override fun onDestroy() {
        cameraStreamer?.stop()
        super.onDestroy()
        if (isFinishing && !JarvisApp.instance.preferences.alwaysOn) {
            viewModel.shutdownSession()
        }
    }
}
