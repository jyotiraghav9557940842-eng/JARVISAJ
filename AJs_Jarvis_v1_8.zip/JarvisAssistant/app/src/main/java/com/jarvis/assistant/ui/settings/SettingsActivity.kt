package com.jarvis.assistant.ui.settings

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.data.model.GeminiConstants
import com.jarvis.assistant.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private val preferences by lazy { JarvisApp.instance.preferences }

    override fun onCreate(savedInstanceState: Bundle?) {
        com.jarvis.assistant.util.ThemeManager.apply(this)
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        populateDropdowns()
        loadCurrentSettings()
        setupListeners()
        setupVoiceControls()
        setupThemeControls()
    }

    private fun setupThemeControls() {
        val d = resources.displayMetrics.density
        val themeIdx = preferences.themeIndex
        val accentIdx = preferences.accentIndex
        val tm = com.jarvis.assistant.util.ThemeManager

        binding.themeRow.removeAllViews()
        tm.baseNames.forEachIndexed { i, name ->
            val chip = android.widget.TextView(this).apply {
                text = name
                textSize = 13f
                val selected = i == themeIdx
                setTextColor(
                    tm.color(
                        this@SettingsActivity,
                        if (selected) com.jarvis.assistant.R.attr.primary_cyan else com.jarvis.assistant.R.attr.text_secondary
                    )
                )
                setPadding((16 * d).toInt(), (9 * d).toInt(), (16 * d).toInt(), (9 * d).toInt())
                setBackgroundResource(
                    if (selected) com.jarvis.assistant.R.drawable.bg_hud_panel else com.jarvis.assistant.R.drawable.bg_input_field
                )
                val lp = android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.marginEnd = (8 * d).toInt()
                layoutParams = lp
                setOnClickListener {
                    if (preferences.themeIndex != i) {
                        preferences.themeIndex = i
                        recreate()
                    }
                }
            }
            binding.themeRow.addView(chip)
        }

        binding.accentRow.removeAllViews()
        tm.accentNames.forEachIndexed { i, name ->
            val dot = View(this).apply {
                val shape = android.graphics.drawable.GradientDrawable()
                shape.shape = android.graphics.drawable.GradientDrawable.OVAL
                shape.setColor(tm.previewAccent(i, themeIdx))
                if (i == accentIdx) {
                    shape.setStroke(
                        (3 * d).toInt(),
                        tm.color(this@SettingsActivity, com.jarvis.assistant.R.attr.text_primary)
                    )
                }
                background = shape
                contentDescription = name
                val lp = android.widget.LinearLayout.LayoutParams((38 * d).toInt(), (38 * d).toInt())
                lp.marginEnd = (12 * d).toInt()
                layoutParams = lp
                setOnClickListener {
                    if (preferences.accentIndex != i) {
                        preferences.accentIndex = i
                        recreate()
                    }
                }
            }
            binding.accentRow.addView(dot)
        }
    }

    private fun voiceReady(): Boolean =
        com.jarvis.assistant.audio.VoiceProfile.parse(preferences.ownerVoiceProfile) != null &&
            com.jarvis.assistant.audio.WakeTemplates.parse(preferences.wakeTemplates) != null

    private fun refreshVoiceUi() {
        val ready = voiceReady()
        binding.tvVoiceStatus.text = if (ready) {
            "Awaaz aur 'Jarvis' wake word save hai"
        } else {
            "Abhi set nahi hai. Neeche VOICE SETUP dabao"
        }
        binding.switchOwnerLock.setOnCheckedChangeListener(null)
        binding.switchOwnerLock.isChecked = preferences.ownerVoiceLock && ready
        binding.switchAlwaysOn.setOnCheckedChangeListener(null)
        binding.switchAlwaysOn.isChecked = preferences.alwaysOn
        attachVoiceSwitchListeners()
    }

    private fun attachVoiceSwitchListeners() {
        binding.switchOwnerLock.setOnCheckedChangeListener { btn, checked ->
            if (checked && !voiceReady()) {
                btn.isChecked = false
                Toast.makeText(this, "Pehle Voice Setup karo", Toast.LENGTH_SHORT).show()
                openVoiceSetup()
            } else {
                preferences.ownerVoiceLock = checked
            }
        }
        binding.switchAlwaysOn.setOnCheckedChangeListener { btn, checked ->
            if (checked && !voiceReady()) {
                btn.isChecked = false
                Toast.makeText(this, "Wake word ke liye pehle Voice Setup karo", Toast.LENGTH_SHORT).show()
                openVoiceSetup()
            } else {
                preferences.alwaysOn = checked
                if (checked) {
                    Toast.makeText(
                        this,
                        "Battery settings me AJ'S JARVIS ko 'Unrestricted' kar do",
                        Toast.LENGTH_LONG
                    ).show()
                    try {
                        startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    } catch (e: Exception) {
                    }
                }
            }
        }
    }

    private fun openVoiceSetup() {
        VoiceEnrollDialog(this) { refreshVoiceUi() }.show()
    }

    private fun setupVoiceControls() {
        refreshVoiceUi()
        binding.btnVoiceSetup.setOnClickListener { openVoiceSetup() }
        when (preferences.ownerVoiceSensitivity) {
            0 -> binding.rbSensRelaxed.isChecked = true
            2 -> binding.rbSensStrict.isChecked = true
            else -> binding.rbSensNormal.isChecked = true
        }
        binding.rgVoiceSens.setOnCheckedChangeListener { _, id ->
            preferences.ownerVoiceSensitivity = when (id) {
                binding.rbSensRelaxed.id -> 0
                binding.rbSensStrict.id -> 2
                else -> 1
            }
        }
    }

    private fun setupToolbar() {
        binding.btnBack.setOnClickListener {
            finish()
        }

        binding.btnSave.setOnClickListener {
            saveSettings()
        }
    }

    private fun populateDropdowns() {
        // 1. AI Models
        val modelAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            GeminiConstants.SUPPORTED_MODELS
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        binding.spinnerModel.adapter = modelAdapter

        // 2. Voices
        val voiceAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            GeminiConstants.SUPPORTED_VOICES
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        binding.spinnerVoice.adapter = voiceAdapter

        // 3. Personalities
        val personalityAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            GeminiConstants.SUPPORTED_PERSONALITIES
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        binding.spinnerPersonality.adapter = personalityAdapter

        // 4. Orb themes
        val themeAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            GeminiConstants.SUPPORTED_ORB_THEMES
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        binding.spinnerTheme.adapter = themeAdapter

        binding.spinnerPersonality.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selected = GeminiConstants.SUPPORTED_PERSONALITIES[position]
                binding.tvPersonalityDesc.text = when (selected) {
                    GeminiConstants.PERSONALITY_GIRLFRIEND ->
                        "Warm Hinglish • Emotional but natural • Short spoken replies"
                    GeminiConstants.PERSONALITY_PROFESSIONAL ->
                        "Formal English • Precise • No emojis"
                    GeminiConstants.PERSONALITY_TEACHER ->
                        "Patient • Step by step • Simple examples"
                    GeminiConstants.PERSONALITY_CODER ->
                        "Tech buddy • Debugging help • Plain spoken"
                    GeminiConstants.PERSONALITY_MOTIVATOR ->
                        "Positive coach • Focus & confidence • Action steps"
                    else ->
                        "Friendly • Helpful • Hinglish or English"
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun loadCurrentSettings() {
        binding.etApiKey.setText(preferences.apiKey)
        binding.etUserName.setText(preferences.userName)

        val currentModel = preferences.aiModel
        val modelIndex = GeminiConstants.SUPPORTED_MODELS.indexOf(currentModel)
        if (modelIndex >= 0) {
            binding.spinnerModel.setSelection(modelIndex)
        }

        val currentVoice = preferences.voice
        val voiceIndex = GeminiConstants.SUPPORTED_VOICES.indexOf(currentVoice)
        if (voiceIndex >= 0) {
            binding.spinnerVoice.setSelection(voiceIndex)
        }

        val themeIndex = GeminiConstants.SUPPORTED_ORB_THEMES.indexOf(preferences.orbTheme)
        if (themeIndex >= 0) {
            binding.spinnerTheme.setSelection(themeIndex)
        }

        val currentPersonality = preferences.personality
        val personalityIndex = GeminiConstants.SUPPORTED_PERSONALITIES.indexOf(currentPersonality)
        if (personalityIndex >= 0) {
            binding.spinnerPersonality.setSelection(personalityIndex)
        }
    }

    private fun setupListeners() {
        binding.btnPasteApiKey.setOnClickListener {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = clipboard.primaryClip
            if (clip != null && clip.itemCount > 0) {
                val pasteData = clip.getItemAt(0).text?.toString()?.trim() ?: ""
                if (pasteData.isNotEmpty()) {
                    binding.etApiKey.setText(pasteData)
                    Toast.makeText(this, "API Key pasted from clipboard", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Clipboard is empty", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun saveSettings() {
        val apiKey = binding.etApiKey.text?.toString()?.trim() ?: ""
        val userName = binding.etUserName.text?.toString()?.trim() ?: ""

        val selectedModel = binding.spinnerModel.selectedItem as? String
            ?: GeminiConstants.DEFAULT_MODEL
        val selectedVoice = binding.spinnerVoice.selectedItem as? String
            ?: "Aoede"
        val selectedPersonality = binding.spinnerPersonality.selectedItem as? String
            ?: GeminiConstants.PERSONALITY_ASSISTANT

        val selectedTheme = binding.spinnerTheme.selectedItem as? String
            ?: GeminiConstants.DEFAULT_ORB_THEME

        preferences.orbTheme = selectedTheme
        preferences.apiKey = apiKey
        preferences.userName = userName
        preferences.aiModel = selectedModel
        preferences.voice = selectedVoice
        preferences.personality = selectedPersonality

        Toast.makeText(this, "Settings saved successfully", Toast.LENGTH_SHORT).show()
        finish()
    }
}
