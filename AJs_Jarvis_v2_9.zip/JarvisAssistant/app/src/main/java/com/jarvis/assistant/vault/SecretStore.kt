package com.jarvis.assistant.vault

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Encrypted on-device vault for the screen-lock PIN and app passwords. Values never leave the phone. */
object SecretStore {
    private const val PREFS = "jarvis_vault"
    private const val ALIAS = "jarvis_vault_key"
    const val SCREEN_LOCK = "screen lock"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return kg.generateKey()
    }

    private fun norm(name: String) = name.trim().lowercase().take(40)

    @Synchronized
    fun put(context: Context, name: String, value: String): Boolean {
        val n = norm(name)
        if (n.isEmpty() || value.isEmpty()) return false
        return try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, key())
            val enc = c.doFinal(value.toByteArray(Charsets.UTF_8))
            val packed = Base64.encodeToString(c.iv + enc, Base64.NO_WRAP)
            context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString("s_$n", packed).apply()
            true
        } catch (e: Exception) {
            false
        }
    }

    @Synchronized
    fun get(context: Context, name: String): String? {
        val n = norm(name)
        val packed = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString("s_$n", null) ?: return null
        return try {
            val all = Base64.decode(packed, Base64.NO_WRAP)
            val iv = all.copyOfRange(0, 12)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            String(c.doFinal(all.copyOfRange(12, all.size)), Charsets.UTF_8)
        } catch (e: Exception) {
            null
        }
    }

    fun names(context: Context): List<String> =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .all.keys.filter { it.startsWith("s_") }.map { it.removePrefix("s_") }.sorted()

    @Synchronized
    fun clear(context: Context) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }
}
