package com.jarvis.assistant.automation.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Lets AJ'S JARVIS read what is on screen and tap / type / scroll by label.
 * It never uses fixed X/Y coordinates; every click is matched by visible text.
 * The user must switch it on once in Settings > Accessibility.
 */
class JarvisAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Not needed: the app only acts when Gemini asks for it.
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    // ---------- reading ----------

    fun readScreen(): String {
        val root = rootInActiveWindow ?: return "The screen could not be read right now. Try again in a moment."
        val lines = ArrayList<String>()
        collect(root, lines, 0)
        if (lines.isEmpty()) return "Nothing readable on screen."
        val pkg = root.packageName?.toString() ?: "unknown"
        return "App: $pkg\n" + lines.take(90).joinToString("\n")
    }

    private fun collect(node: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (node == null || depth > 25 || out.size >= 90) return
        if (node.isVisibleToUser) {
            val label = labelOf(node)
            val kind = when {
                node.isEditable -> "input"
                node.isCheckable -> if (node.isChecked) "switch ON" else "switch OFF"
                node.isClickable -> "button"
                else -> "text"
            }
            if (label.isNotBlank() || node.isEditable) {
                var pos = ""
                if (node.isClickable) {
                    val rb = android.graphics.Rect()
                    node.getBoundsInScreen(rb)
                    val dmm = resources.displayMetrics
                    pos = " @x=${(rb.centerX() * 100f / dmm.widthPixels).toInt()}%,y=${(rb.centerY() * 100f / dmm.heightPixels).toInt()}%"
                }
                out.add("[$kind] ${label.ifBlank { "(empty field)" }}$pos")
            } else if (node.isClickable) {
                val r = android.graphics.Rect()
                node.getBoundsInScreen(r)
                val dm = resources.displayMetrics
                if (r.width() > 40 * dm.density && r.height() > 40 * dm.density) {
                    val px = (r.centerX() * 100f / dm.widthPixels).toInt()
                    val py = (r.centerY() * 100f / dm.heightPixels).toInt()
                    out.add("[tap-area] unlabeled item at x=$px%, y=$py%")
                }
            }
        }
        for (i in 0 until node.childCount) {
            collect(node.getChild(i), out, depth + 1)
        }
    }

    private fun labelOf(node: AccessibilityNodeInfo): String {
        val t = node.text?.toString()?.trim().orEmpty()
        if (t.isNotEmpty()) return t.take(80)
        val d = node.contentDescription?.toString()?.trim().orEmpty()
        if (d.isNotEmpty()) return d.take(80)
        return node.hintText?.toString()?.trim().orEmpty().take(80)
    }

    // ---------- acting ----------

    fun clickByText(text: String): String {
        val root = rootInActiveWindow ?: return "The screen could not be read right now."
        val matches = root.findAccessibilityNodeInfosByText(text)
        if (matches.isNullOrEmpty()) return "Nothing on screen matches '$text'. Call read_screen to see the exact labels."

        val exact = matches.filter { labelOf(it).equals(text, ignoreCase = true) }
        val candidates = if (exact.isNotEmpty()) exact else matches
        for (n in candidates) {
            var cur: AccessibilityNodeInfo? = n
            var hops = 0
            while (cur != null && hops < 6) {
                if (cur.isClickable && cur.isEnabled) {
                    if (cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        return "Tapped '${labelOf(n).ifBlank { text }}'" +
                            if (candidates.size > 1) " (${candidates.size} similar items; picked the first)." else "."
                    }
                }
                cur = cur.parent
                hops++
            }
        }
        return "Found '$text' but it could not be tapped."
    }

    fun typeText(text: String): String {
        val root = rootInActiveWindow ?: return "The screen could not be read right now."
        var target: AccessibilityNodeInfo? = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (target == null || !target.isEditable) target = findEditable(root, 0)
        if (target == null) return "No input field found on this screen."
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val ok = target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        return if (ok) "Typed the text." else "Could not type into the field."
    }

    private fun findEditable(node: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
        if (node == null || depth > 25) return null
        if (node.isEditable && node.isVisibleToUser) return node
        for (i in 0 until node.childCount) {
            val found = findEditable(node.getChild(i), depth + 1)
            if (found != null) return found
        }
        return null
    }

    fun scroll(forward: Boolean): String {
        val root = rootInActiveWindow ?: return "The screen could not be read right now."
        val node = findScrollable(root, 0) ?: return "Nothing scrollable on this screen."
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return if (node.performAction(action)) {
            if (forward) "Scrolled down." else "Scrolled up."
        } else {
            "Cannot scroll further."
        }
    }

    private fun findScrollable(node: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
        if (node == null || depth > 25) return null
        if (node.isScrollable && node.isVisibleToUser) return node
        for (i in 0 until node.childCount) {
            val found = findScrollable(node.getChild(i), depth + 1)
            if (found != null) return found
        }
        return null
    }


    // ---------- one-shot helpers used by WhatsApp send and YouTube play ----------

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = node
        var hops = 0
        while (cur != null && hops < 7) {
            if (cur.isClickable && cur.isEnabled && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent
            hops++
        }
        return false
    }

    private fun findNode(node: AccessibilityNodeInfo?, depth: Int, match: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (node == null || depth > 30) return null
        if (match(node)) return node
        for (i in 0 until node.childCount) {
            val r = findNode(node.getChild(i), depth + 1, match)
            if (r != null) return r
        }
        return null
    }

    /** Waits for the WhatsApp chat to show its Send button, then taps it. */
    fun clickWhatsAppSend(): Boolean {
        repeat(12) {
            val root = rootInActiveWindow
            if (root != null) {
                val btn = findNode(root, 0) { n ->
                    val id = n.viewIdResourceName ?: ""
                    val d = n.contentDescription?.toString()?.trim()?.lowercase() ?: ""
                    id.endsWith(":id/send") || d == "send" || d == "send message" || d == "\u092d\u0947\u091c\u0947\u0902"
                }
                if (btn != null && clickNodeOrParent(btn)) return true
            }
            Thread.sleep(500)
        }
        return false
    }

    /** Waits for YouTube search results, then plays the first real video (skips ads and Shorts). */
    @Volatile var lastPlayedTitle: String = ""

    fun playFirstYouTubeResult(): Boolean {
        repeat(14) {
            val root = rootInActiveWindow
            if (root != null && root.packageName?.toString() == "com.google.android.youtube") {
                val vid = findNode(root, 0) { n ->
                    val d = n.contentDescription?.toString()?.lowercase() ?: ""
                    (d.contains("play video") || d.contains("\u0935\u0940\u0921\u093f\u092f\u094b \u091a\u0932\u093e\u090f\u0902")) &&
                        !d.contains("sponsor") && !d.contains("shorts") && !d.startsWith("ad ")
                }
                if (vid != null) {
                    lastPlayedTitle = (vid.contentDescription?.toString() ?: "").split(" - ").firstOrNull()?.take(100).orEmpty()
                    if (clickNodeOrParent(vid)) return true
                }
            }
            Thread.sleep(500)
        }
        lastPlayedTitle = ""
        return tapScreenFraction(0.5f, 0.34f)
    }

    fun openPowerMenu(): Boolean =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)

    fun tapPercent(fx: Float, fy: Float): Boolean = tapScreenFraction(fx, fy)

    private fun tapScreenFraction(fx: Float, fy: Float): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
        val dm = resources.displayMetrics
        val path = Path().apply { moveTo(dm.widthPixels * fx, dm.heightPixels * fy) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    // ---------- screen vision, swipes, fast taps, ad closer ----------

    private val shotExecutor = java.util.concurrent.Executors.newSingleThreadExecutor()
    private var lastShotAt = 0L
    @Volatile private var autoRunning = false
    @Volatile var adsClosed = 0

    /** Takes a screenshot (Android 11+) and returns it as a small JPEG. Secure screens come out black. */
    fun captureScreenJpeg(): ByteArray? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
        val wait = 1200L - (System.currentTimeMillis() - lastShotAt)
        if (wait > 0) Thread.sleep(wait)
        lastShotAt = System.currentTimeMillis()
        val latch = java.util.concurrent.CountDownLatch(1)
        var out: ByteArray? = null
        takeScreenshot(android.view.Display.DEFAULT_DISPLAY, shotExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                try {
                    val hb = result.hardwareBuffer
                    val hw = android.graphics.Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                    val soft = hw?.copy(android.graphics.Bitmap.Config.ARGB_8888, false)
                    hb.close()
                    if (soft != null) {
                        val w = 720
                        val h = (soft.height * (w.toFloat() / soft.width)).toInt()
                        val scaled = android.graphics.Bitmap.createScaledBitmap(soft, w, h, true)
                        val bos = java.io.ByteArrayOutputStream()
                        scaled.compress(android.graphics.Bitmap.CompressFormat.JPEG, 72, bos)
                        out = bos.toByteArray()
                    }
                } catch (e: Exception) {
                } finally {
                    latch.countDown()
                }
            }
            override fun onFailure(errorCode: Int) {
                latch.countDown()
            }
        })
        latch.await(4, java.util.concurrent.TimeUnit.SECONDS)
        return out
    }

    fun swipePercent(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
        val dm = resources.displayMetrics
        val path = Path().apply {
            moveTo(dm.widthPixels * x1, dm.heightPixels * y1)
            lineTo(dm.widthPixels * x2, dm.heightPixels * y2)
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, ms.coerceIn(50, 1500)))
            .build()
        val latch = java.util.concurrent.CountDownLatch(1)
        var ok = false
        val sent = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { ok = true; latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }, null)
        if (!sent) return false
        latch.await(3, java.util.concurrent.TimeUnit.SECONDS)
        return ok
    }

    /** Taps one point many times as fast as the phone allows (up to 20 taps per gesture). Returns the taps done. */
    fun rapidTap(fx: Float, fy: Float, count: Int, maxSeconds: Int): Int {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return 0
        val dm = resources.displayMetrics
        val x = dm.widthPixels * fx
        val y = dm.heightPixels * fy
        val deadline = System.currentTimeMillis() + maxSeconds * 1000L
        val perGesture = GestureDescription.getMaxStrokeCount().coerceAtMost(20)
        var done = 0
        var failures = 0
        autoRunning = true
        while (autoRunning && done < count && System.currentTimeMillis() < deadline && failures < 4) {
            val n = minOf(perGesture, count - done)
            val b = GestureDescription.Builder()
            for (i in 0 until n) {
                val path = Path().apply { moveTo(x, y) }
                b.addStroke(GestureDescription.StrokeDescription(path, i * 14L, 8L))
            }
            val latch = java.util.concurrent.CountDownLatch(1)
            var ok = false
            val sent = dispatchGesture(b.build(), object : GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { ok = true; latch.countDown() }
                override fun onCancelled(d: GestureDescription?) { latch.countDown() }
            }, null)
            if (!sent) { failures++; continue }
            latch.await(2, java.util.concurrent.TimeUnit.SECONDS)
            if (ok) done += n else failures++
        }
        autoRunning = false
        return done
    }

    private val closeWords = setOf(
        "close", "close ad", "skip", "skip ad", "skip ads", "dismiss", "x", "\u2715", "\u2716", "\u00d7",
        "no thanks", "not now", "close ads"
    )

    private fun isCloseControl(n: AccessibilityNodeInfo): Boolean {
        val t = (n.text?.toString() ?: "").trim().lowercase()
        val d = (n.contentDescription?.toString() ?: "").trim().lowercase()
        val hit = { s: String -> s.isNotEmpty() && (s in closeWords || s.startsWith("skip")) }
        return hit(t) || hit(d)
    }

    private fun findCloseButton(node: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
        if (node == null || depth > 30) return null
        if (node.isVisibleToUser && isCloseControl(node)) return node
        for (i in 0 until node.childCount) {
            val r = findCloseButton(node.getChild(i), depth + 1)
            if (r != null) return r
        }
        return null
    }

    /** Background loop that taps only Close / Skip / X controls. It never taps an ad itself. */
    fun startAdCloser(seconds: Int): String {
        if (autoRunning) return "An automation is already running. Stop it first."
        autoRunning = true
        adsClosed = 0
        val deadline = System.currentTimeMillis() + seconds.coerceIn(5, 600) * 1000L
        Thread {
            while (autoRunning && System.currentTimeMillis() < deadline) {
                try {
                    val btn = findCloseButton(rootInActiveWindow, 0)
                    if (btn != null && clickNodeOrParent(btn)) {
                        adsClosed++
                        Thread.sleep(900)
                    }
                } catch (e: Exception) {
                }
                Thread.sleep(600)
            }
            autoRunning = false
        }.start()
        return "Ad closer started for $seconds seconds. It only taps Close, Skip and X buttons."
    }

    fun stopAutomation(): String {
        val was = autoRunning
        autoRunning = false
        return if (was) "Stopped. Ads closed so far: $adsClosed." else "Nothing was running."
    }

    fun pressKey(key: String): String {
        val ok = when (key) {
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            "quick_settings" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            "enter" -> pressEnter()
            "lock_screen", "lock" -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
                performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) else false
            else -> return "Unknown key '$key'."
        }
        return if (ok) "Pressed $key." else "Could not press $key."
    }

    private fun pressEnter(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return false
        val root = rootInActiveWindow ?: return false
        val field = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        return field.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
    }

    companion object {
        @Volatile
        var instance: JarvisAccessibilityService? = null
    }
}
