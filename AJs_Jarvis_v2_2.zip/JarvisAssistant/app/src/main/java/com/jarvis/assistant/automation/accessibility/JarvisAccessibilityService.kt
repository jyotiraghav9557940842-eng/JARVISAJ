package com.jarvis.assistant.automation.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Lets AJ'S JARVIS read what is on screen and tap / type / scroll by label.
 * It never uses fixed X/Y coordinates; every click is matched by visible text.
 * The user must switch it on once in Settings > Accessibility.
 */
class JarvisAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Not needed: the app only acts when Gemini asks for it.
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    // ---------- reading ----------

    fun readScreen(): String {
        val root = rootInActiveWindow ?: return "The screen could not be read right now. Try again in a moment."
        val lines = ArrayList<String>()
        collect(root, lines, 0)
        if (lines.isEmpty()) return "Nothing readable on screen."
        val pkg = root.packageName?.toString() ?: "unknown"
        return "App: $pkg\n" + lines.take(70).joinToString("\n")
    }

    private fun collect(node: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (node == null || depth > 25 || out.size >= 70) return
        if (node.isVisibleToUser) {
            val label = labelOf(node)
            val kind = when {
                node.isEditable -> "input"
                node.isCheckable -> if (node.isChecked) "switch ON" else "switch OFF"
                node.isClickable -> "button"
                else -> "text"
            }
            if (label.isNotBlank() || node.isEditable) {
                out.add("[$kind] ${label.ifBlank { "(empty field)" }}")
            }
        }
        for (i in 0 until node.childCount) {
            collect(node.getChild(i), out, depth + 1)
        }
    }

    private fun labelOf(node: AccessibilityNodeInfo): String {
        val t = node.text?.toString()?.trim().orEmpty()
        if (t.isNotEmpty()) return t.take(80)
        val d = node.contentDescription?.toString()?.trim().orEmpty()
        if (d.isNotEmpty()) return d.take(80)
        return node.hintText?.toString()?.trim().orEmpty().take(80)
    }

    // ---------- acting ----------

    fun clickByText(text: String): String {
        val root = rootInActiveWindow ?: return "The screen could not be read right now."
        val matches = root.findAccessibilityNodeInfosByText(text)
        if (matches.isNullOrEmpty()) return "Nothing on screen matches '$text'. Call read_screen to see the exact labels."

        val exact = matches.filter { labelOf(it).equals(text, ignoreCase = true) }
        val candidates = if (exact.isNotEmpty()) exact else matches
        for (n in candidates) {
            var cur: AccessibilityNodeInfo? = n
            var hops = 0
            while (cur != null && hops < 6) {
                if (cur.isClickable && cur.isEnabled) {
                    if (cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        return "Tapped '${labelOf(n).ifBlank { text }}'" +
                            if (candidates.size > 1) " (${candidates.size} similar items; picked the first)." else "."
                    }
                }
                cur = cur.parent
                hops++
            }
        }
        return "Found '$text' but it could not be tapped."
    }

    fun typeText(text: String): String {
        val root = rootInActiveWindow ?: return "The screen could not be read right now."
        var target: AccessibilityNodeInfo? = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (target == null || !target.isEditable) target = findEditable(root, 0)
        if (target == null) return "No input field found on this screen."
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val ok = target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        return if (ok) "Typed the text." else "Could not type into the field."
    }

    private fun findEditable(node: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
        if (node == null || depth > 25) return null
        if (node.isEditable && node.isVisibleToUser) return node
        for (i in 0 until node.childCount) {
            val found = findEditable(node.getChild(i), depth + 1)
            if (found != null) return found
        }
        return null
    }

    fun scroll(forward: Boolean): String {
        val root = rootInActiveWindow ?: return "The screen could not be read right now."
        val node = findScrollable(root, 0) ?: return "Nothing scrollable on this screen."
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return if (node.performAction(action)) {
            if (forward) "Scrolled down." else "Scrolled up."
        } else {
            "Cannot scroll further."
        }
    }

    private fun findScrollable(node: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
        if (node == null || depth > 25) return null
        if (node.isScrollable && node.isVisibleToUser) return node
        for (i in 0 until node.childCount) {
            val found = findScrollable(node.getChild(i), depth + 1)
            if (found != null) return found
        }
        return null
    }


    // ---------- one-shot helpers used by WhatsApp send and YouTube play ----------

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = node
        var hops = 0
        while (cur != null && hops < 7) {
            if (cur.isClickable && cur.isEnabled && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent
            hops++
        }
        return false
    }

    private fun findNode(node: AccessibilityNodeInfo?, depth: Int, match: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (node == null || depth > 30) return null
        if (match(node)) return node
        for (i in 0 until node.childCount) {
            val r = findNode(node.getChild(i), depth + 1, match)
            if (r != null) return r
        }
        return null
    }

    /** Waits for the WhatsApp chat to show its Send button, then taps it. */
    fun clickWhatsAppSend(): Boolean {
        repeat(12) {
            val root = rootInActiveWindow
            if (root != null) {
                val btn = findNode(root, 0) { n ->
                    val id = n.viewIdResourceName ?: ""
                    val d = n.contentDescription?.toString()?.trim()?.lowercase() ?: ""
                    id.endsWith(":id/send") || d == "send" || d == "send message" || d == "\u092d\u0947\u091c\u0947\u0902"
                }
                if (btn != null && clickNodeOrParent(btn)) return true
            }
            Thread.sleep(500)
        }
        return false
    }

    /** Waits for YouTube search results, then plays the first real video (skips ads and Shorts). */
    fun playFirstYouTubeResult(): Boolean {
        repeat(14) {
            val root = rootInActiveWindow
            if (root != null && root.packageName?.toString() == "com.google.android.youtube") {
                val vid = findNode(root, 0) { n ->
                    val d = n.contentDescription?.toString()?.lowercase() ?: ""
                    (d.contains("play video") || d.contains("\u0935\u0940\u0921\u093f\u092f\u094b \u091a\u0932\u093e\u090f\u0902")) &&
                        !d.contains("sponsor") && !d.contains("shorts") && !d.startsWith("ad ")
                }
                if (vid != null && clickNodeOrParent(vid)) return true
            }
            Thread.sleep(500)
        }
        return tapScreenFraction(0.5f, 0.34f)
    }

    private fun tapScreenFraction(fx: Float, fy: Float): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
        val dm = resources.displayMetrics
        val path = Path().apply { moveTo(dm.widthPixels * fx, dm.heightPixels * fy) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    fun pressKey(key: String): String {
        val ok = when (key) {
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            "quick_settings" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            "enter" -> pressEnter()
            else -> return "Unknown key '$key'."
        }
        return if (ok) "Pressed $key." else "Could not press $key."
    }

    private fun pressEnter(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return false
        val root = rootInActiveWindow ?: return false
        val field = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        return field.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
    }

    companion object {
        @Volatile
        var instance: JarvisAccessibilityService? = null
    }
}
