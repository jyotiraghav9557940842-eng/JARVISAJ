package com.jarvis.assistant.data.preferences

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.jarvis.assistant.data.model.ChatTurn
import com.jarvis.assistant.data.model.GeminiConstants

class AppPreferences(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    private val gson = Gson()

    companion object {
        private const val PREF_NAME = "jarvis_prefs"
        private const val KEY_API_KEY = "key_api_key"
        private const val KEY_MODEL = "key_model"
        private const val KEY_VOICE = "key_voice"
        private const val KEY_PERSONALITY = "key_personality"
        private const val KEY_USER_NAME = "key_user_name"
        private const val KEY_MIC_MUTED = "key_mic_muted"
        private const val KEY_CHAT_HISTORY = "key_chat_history"
        private const val KEY_ORB_THEME = "key_orb_theme_v3"
        private const val KEY_OWNER_LOCK = "key_owner_lock"
        private const val KEY_THEME_INDEX = "key_theme_index"
        private const val KEY_ACCENT_INDEX = "key_accent_index"
        private const val KEY_OWNER_PROFILE = "key_owner_profile"
        private const val KEY_OWNER_SENS = "key_owner_sens"
        private const val KEY_ALWAYS_ON = "key_always_on"
        private const val KEY_WAKE_TEMPLATES = "key_wake_templates"
    }

    var apiKey: String
        get() = prefs.getString(KEY_API_KEY, "") ?: ""
        set(value) = prefs.edit().putString(KEY_API_KEY, value.trim()).apply()

    var aiModel: String
        get() {
            val stored = prefs.getString(KEY_MODEL, GeminiConstants.DEFAULT_MODEL) ?: GeminiConstants.DEFAULT_MODEL
            return if (GeminiConstants.SUPPORTED_MODELS.contains(stored)) {
                stored
            } else {
                GeminiConstants.DEFAULT_MODEL
            }
        }
        set(value) = prefs.edit().putString(KEY_MODEL, value).apply()

    var paletteIndex: Int
        get() = prefs.getInt("key_palette_index", com.jarvis.assistant.util.Palettes.DEFAULT_INDEX)
        set(value) = prefs.edit().putInt("key_palette_index", value).apply()

    var autoHandle: Boolean
        get() = prefs.getBoolean("key_auto_handle", false)
        set(value) = prefs.edit().putBoolean("key_auto_handle", value).apply()

    var autoHandleContacts: String
        get() = prefs.getString("key_auto_handle_contacts", "") ?: ""
        set(value) = prefs.edit().putString("key_auto_handle_contacts", value).apply()

    var voice: String
        get() = prefs.getString(KEY_VOICE, "Aoede") ?: "Aoede"
        set(value) = prefs.edit().putString(KEY_VOICE, value).apply()

    var personality: String
        get() = prefs.getString(KEY_PERSONALITY, GeminiConstants.PERSONALITY_ASSISTANT) ?: GeminiConstants.PERSONALITY_ASSISTANT
        set(value) = prefs.edit().putString(KEY_PERSONALITY, value).apply()

    var userName: String
        get() = prefs.getString(KEY_USER_NAME, "AJ SARKAR XYASH") ?: "AJ SARKAR XYASH"
        set(value) = prefs.edit().putString(KEY_USER_NAME, value.trim()).apply()

    var orbTheme: String
        get() {
            val stored = prefs.getString(KEY_ORB_THEME, GeminiConstants.DEFAULT_ORB_THEME) ?: GeminiConstants.DEFAULT_ORB_THEME
            return if (GeminiConstants.SUPPORTED_ORB_THEMES.contains(stored)) stored else GeminiConstants.DEFAULT_ORB_THEME
        }
        set(value) = prefs.edit().putString(KEY_ORB_THEME, value).apply()

    var themeIndex: Int
        get() = prefs.getInt(KEY_THEME_INDEX, 0)
        set(value) = prefs.edit().putInt(KEY_THEME_INDEX, value).apply()

    var accentIndex: Int
        get() = prefs.getInt(KEY_ACCENT_INDEX, 0)
        set(value) = prefs.edit().putInt(KEY_ACCENT_INDEX, value).apply()

    var ownerVoiceLock: Boolean
        get() = prefs.getBoolean(KEY_OWNER_LOCK, false)
        set(value) = prefs.edit().putBoolean(KEY_OWNER_LOCK, value).apply()

    var ownerVoiceProfile: String
        get() = prefs.getString(KEY_OWNER_PROFILE, "") ?: ""
        set(value) = prefs.edit().putString(KEY_OWNER_PROFILE, value).apply()

    /** 0 = relaxed, 1 = normal, 2 = strict */
    var ownerVoiceSensitivity: Int
        get() = prefs.getInt(KEY_OWNER_SENS, 1)
        set(value) = prefs.edit().putInt(KEY_OWNER_SENS, value).apply()

    var alwaysOn: Boolean
        get() = prefs.getBoolean(KEY_ALWAYS_ON, false)
        set(value) = prefs.edit().putBoolean(KEY_ALWAYS_ON, value).apply()

    var wakeTemplates: String
        get() = prefs.getString(KEY_WAKE_TEMPLATES, "") ?: ""
        set(value) = prefs.edit().putString(KEY_WAKE_TEMPLATES, value).apply()

    var isMicMuted: Boolean
        get() = prefs.getBoolean(KEY_MIC_MUTED, false)
        set(value) = prefs.edit().putBoolean(KEY_MIC_MUTED, value).apply()

    fun loadChatHistory(): List<ChatTurn> {
        val json = prefs.getString(KEY_CHAT_HISTORY, null) ?: return emptyList()
        return try {
            val type = object : TypeToken<List<ChatTurn>>() {}.type
            gson.fromJson(json, type) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveChatHistory(history: List<ChatTurn>) {
        val json = gson.toJson(history)
        prefs.edit().putString(KEY_CHAT_HISTORY, json).apply()
    }

    fun clearChatHistory() {
        prefs.edit().remove(KEY_CHAT_HISTORY).apply()
    }
}
