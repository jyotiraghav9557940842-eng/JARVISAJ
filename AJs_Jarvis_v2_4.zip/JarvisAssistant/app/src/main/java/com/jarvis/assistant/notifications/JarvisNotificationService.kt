package com.jarvis.assistant.notifications

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class JarvisNotificationService : NotificationListenerService() {

    override fun onListenerConnected() {
        NotificationHub.listenerConnected = true
        try {
            activeNotifications?.forEach { process(it, allowAuto = false) }
        } catch (e: Exception) {
        }
    }

    override fun onListenerDisconnected() {
        NotificationHub.listenerConnected = false
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        process(sbn, allowAuto = true)
    }

    private fun process(sbn: StatusBarNotification, allowAuto: Boolean) {
        val source = when (sbn.packageName) {
            "com.whatsapp" -> "WhatsApp"
            "com.whatsapp.w4b" -> "WhatsApp Business"
            "com.google.android.gm" -> "Gmail"
            "com.google.android.apps.messaging", "com.samsung.android.messaging", "com.android.mms" -> "SMS"
            else -> return
        }
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val extras = n.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString()?.trim().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        if (Regex("^\\d+ new messages?$", RegexOption.IGNORE_CASE).containsMatchIn(text)) return
        if (text.contains("Checking for new messages", ignoreCase = true)) return

        val item = NotificationHub.Item(System.currentTimeMillis(), source, title.ifBlank { "Unknown" }, text)
        if (!NotificationHub.add(item)) return

        val isGroup = extras.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false)
        if (allowAuto && source.startsWith("WhatsApp") && !isGroup) {
            AutoReplyEngine.maybeHandle(applicationContext, n, item)
        }
    }
}
