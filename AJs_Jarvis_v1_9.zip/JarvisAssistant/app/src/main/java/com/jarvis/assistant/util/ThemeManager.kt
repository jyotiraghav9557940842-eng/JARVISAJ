package com.jarvis.assistant.util

import android.app.Activity
import android.content.Context
import android.util.TypedValue
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.R

/** 5 looks (base) x 9 accent colours. Chosen in Settings, applied to every screen. */
object ThemeManager {
    val baseNames = listOf("Blue", "Black", "White", "Blue + White", "Sunset")
    val accentNames = listOf("Default", "Blue", "Cyan", "Purple", "Pink", "Red", "Orange", "Green", "Gold")

    private val defaultAccent = intArrayOf(0xFF2E7DFF.toInt(), 0xFF1EC8FF.toInt(), 0xFF2E7DFF.toInt(), 0xFF2E7DFF.toInt(), 0xFFFF6B3D.toInt())
    val accentColors = intArrayOf(
        0, 0xFF2E7DFF.toInt(), 0xFF1EC8FF.toInt(), 0xFF8B5CF6.toInt(), 0xFFFF4D8D.toInt(),
        0xFFFF3B30.toInt(), 0xFFFF6B3D.toInt(), 0xFF19C37D.toInt(), 0xFFFFC857.toInt()
    )

    fun previewAccent(index: Int, baseIndex: Int): Int =
        if (index == 0) defaultAccent[baseIndex.coerceIn(0, 4)] else accentColors[index]

    fun isLight(): Boolean = JarvisApp.instance.preferences.themeIndex >= 2

    fun key(): String {
        val p = JarvisApp.instance.preferences
        return "${p.themeIndex}_${p.accentIndex}"
    }

    fun apply(activity: Activity) {
        val p = JarvisApp.instance.preferences
        val base = when (p.themeIndex) {
            1 -> R.style.Theme_Jarvis_Black
            2 -> R.style.Theme_Jarvis_White
            3 -> R.style.Theme_Jarvis_BlueWhite
            4 -> R.style.Theme_Jarvis_Sunset
            else -> R.style.Theme_JarvisAssistant
        }
        activity.setTheme(base)
        val accent = when (p.accentIndex) {
            1 -> R.style.Accent_Blue
            2 -> R.style.Accent_Cyan
            3 -> R.style.Accent_Purple
            4 -> R.style.Accent_Pink
            5 -> R.style.Accent_Red
            6 -> R.style.Accent_Orange
            7 -> R.style.Accent_Green
            8 -> R.style.Accent_Gold
            else -> 0
        }
        if (accent != 0) activity.theme.applyStyle(accent, true)
    }

    fun color(context: Context, attr: Int): Int {
        val tv = TypedValue()
        context.theme.resolveAttribute(attr, tv, true)
        return tv.data
    }
}
