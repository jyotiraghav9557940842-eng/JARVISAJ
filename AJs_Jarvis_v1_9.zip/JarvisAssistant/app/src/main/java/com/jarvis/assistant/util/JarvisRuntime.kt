package com.jarvis.assistant.util

/** Tiny process-wide flags shared between screens. */
object JarvisRuntime {
    @Volatile
    var sessionOn: Boolean = false
}
