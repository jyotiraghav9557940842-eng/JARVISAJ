package com.jarvis.assistant.ui.look

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.ViewGroup
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import com.jarvis.assistant.R
import com.jarvis.assistant.data.repository.StatsStore
import com.jarvis.assistant.util.ThemeManager

/** Settings pop-ups: button style, custom texts, feature list and command stats. */
object LookDialogs {

    private fun accent(a: Activity) = ThemeManager.color(a, R.attr.primary_cyan)
    private fun textColor(a: Activity) = ThemeManager.color(a, R.attr.text_primary)
    private fun dp(a: Activity, v: Int) = (v * a.resources.displayMetrics.density).toInt()

    private fun styled(a: Activity, dialog: AlertDialog) {
        dialog.window?.setBackgroundDrawable(ColorDrawable(ThemeManager.color(a, R.attr.bg_card)))
    }

    private fun heading(a: Activity, text: String): TextView = TextView(a).apply {
        this.text = text
        textSize = 13f
        setTextColor(accent(a))
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(a, 14), 0, dp(a, 4))
    }

    private fun chip(a: Activity, label: String, selected: Boolean, onClick: () -> Unit): TextView = TextView(a).apply {
        text = label
        textSize = 12f
        setPadding(dp(a, 12), dp(a, 7), dp(a, 12), dp(a, 7))
        val bg = GradientDrawable()
        bg.cornerRadius = dp(a, 18).toFloat()
        if (selected) {
            bg.setColor(accent(a))
            setTextColor(Color.BLACK)
        } else {
            bg.setColor(Color.TRANSPARENT)
            bg.setStroke(dp(a, 1), accent(a))
            setTextColor(textColor(a))
        }
        background = bg
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.marginEnd = dp(a, 6)
        layoutParams = lp
        setOnClickListener { onClick() }
    }

    private fun chipRow(a: Activity, chips: List<TextView>): HorizontalScrollView {
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        chips.forEach { row.addView(it) }
        val hs = HorizontalScrollView(a)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(row)
        return hs
    }

    fun buttons(a: Activity) {
        val root = LinearLayout(a)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(a, 16), dp(a, 8), dp(a, 16), dp(a, 16))
        val scroll = ScrollView(a)
        scroll.addView(root)

        fun render() {
            val y = scroll.scrollY
            root.removeAllViews()
            root.addView(heading(a, "Taiyaar styles (ek tap me)"))
            root.addView(chipRow(a, ButtonOptions.presets.mapIndexed { i, p ->
                chip(a, p.name, false) { ButtonOptions.applyPreset(a, i); render() }
            }))
            var last = ""
            for (o in ButtonOptions.all) {
                if (o.group != last) {
                    root.addView(heading(a, o.group.uppercase()))
                    last = o.group
                }
                val t = TextView(a)
                t.text = o.title
                t.textSize = 13f
                t.setTextColor(textColor(a))
                t.setPadding(0, dp(a, 6), 0, dp(a, 4))
                root.addView(t)
                val cur = ButtonOptions.get(a, o.key)
                root.addView(chipRow(a, o.choices.mapIndexed { i, c ->
                    chip(a, c, i == cur) { LookPrefs.setInt(a, o.key, i); render() }
                }))
            }
            scroll.post { scroll.scrollTo(0, y) }
        }
        render()
        val dialog = AlertDialog.Builder(a)
            .setTitle("Button ka style (${ButtonOptions.all.size} options)")
            .setView(scroll)
            .setPositiveButton("Ho gaya", null)
            .create()
        dialog.show()
        styled(a, dialog)
    }

    fun texts(a: Activity) {
        val root = LinearLayout(a)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(a, 16), dp(a, 8), dp(a, 16), dp(a, 16))
        val fields = ArrayList<Pair<String, EditText>>()
        for (t in UiTexts.all) {
            val l = TextView(a)
            l.text = t.label
            l.textSize = 12f
            l.setTextColor(accent(a))
            l.setPadding(0, dp(a, 10), 0, dp(a, 2))
            root.addView(l)
            val e = EditText(a)
            e.hint = t.def.replace("\n", " / ")
            e.setText(LookPrefs.str(a, t.key))
            e.textSize = 14f
            e.setTextColor(textColor(a))
            e.setHintTextColor(ThemeManager.color(a, R.attr.text_muted))
            root.addView(e)
            fields.add(t.key to e)
        }
        val note = TextView(a)
        note.text = "Khaali chhodo to purana naam rahega. Nayi line ke liye \\n likho."
        note.textSize = 11f
        note.setTextColor(ThemeManager.color(a, R.attr.text_muted))
        note.setPadding(0, dp(a, 12), 0, 0)
        root.addView(note)
        val scroll = ScrollView(a)
        scroll.addView(root)
        val dialog = AlertDialog.Builder(a)
            .setTitle("Text badlo (${UiTexts.all.size} jagah)")
            .setView(scroll)
            .setPositiveButton("Save") { _, _ ->
                fields.forEach { (k, e) -> LookPrefs.setStr(a, k, e.text.toString()) }
                LookPrefs.bump(a)
            }
            .setNeutralButton("Sab purana karo") { _, _ -> LookPrefs.clearTexts(a) }
            .setNegativeButton("Band karo", null)
            .create()
        dialog.show()
        styled(a, dialog)
    }

    fun stats(a: Activity) {
        val dialog = AlertDialog.Builder(a)
            .setTitle("Command analytics")
            .setMessage(StatsStore.summary(a))
            .setPositiveButton("OK", null)
            .setNeutralButton("Reset") { _, _ -> StatsStore.reset(a) }
            .create()
        dialog.show()
        styled(a, dialog)
    }

    private val featureText = """
BAATCHEET AUR YAADDASHT
- Notes: "note likho: kal doodh lana", "mere notes sunao", "doodh wala note hata do"
- Lists: "shopping list me aata, chawal jodo", "shopping list dikhao"
- Diary: "aaj ka diary likho", "pichhle hafte ka diary padho"
- Memory: "ye yaad rakhna ..." (sirf kaam ki baatein)

PAISA, ADAT, TAARIKH
- Kharcha: "200 rupaye khane par kharch", "is mahine ka kharcha batao"
- Adat (habit): "aaj padhai ho gayi", "meri adaton ka status"
- Janamdin: "Rohit ka janamdin 12 march", "agle janamdin kaun se hain"
- Din ginti: "Diwali me kitne din bache", "world clock: London me kya time hai"

REMINDER AUR FOCUS
- Roz ka reminder: "roz raat 9 baje dawai yaad dilana", "reminders dikhao", "dawai wala reminder hata do"
- Ek baar ka reminder aur timer, alarm
- Pomodoro: "25 minute padhai aur 5 minute break, 4 round"
- Paani: "har ghante paani peene ko yaad dilao"
- Homework planner: "homework jodo", "kya kya baki hai"

PHONE KE KAAM
- Hisab: "(250*12)/5 kitna hota hai", system status: "phone me kitni jagah bachi hai"
- Clipboard, share, ringer (vibrate/silent), SOS (112)
- Flashlight, volume, WiFi/Bluetooth, apps kholna, call, WhatsApp message aur call
- YouTube gaana chalana, Maps, web search, screen lock, phone band karna
- Screen dekhkar madad (game, app), tez tap, ads band, tijori se unlock

AAWAZ AUR AANKHEN
- Camera Vision: dikhao aur poochho; haath se HUD zoom/ghumao
- Aawaz badlo (16 awaazen), mood: shaant/josh, kids mode
- Owner voice lock, alag-alag logon ko pehchanna
- Message/call/charging bolkar batana, auto-reply

JARVIS KE APNE KAAM
- Daily briefing: "good morning Jarvis, aaj ka briefing do"
- Random: sikka uchhalo, dice, number, "in me se ek chuno"
- Command analytics: "tumhare kaunse kaam fail hue?"
- Kisi bhi app ka kaam: "samajh nahi aa raha, tum karo"
""".trimIndent()

    fun features(a: Activity) {
        val dialog = AlertDialog.Builder(a)
            .setTitle("Jarvis ke features")
            .setMessage(featureText)
            .setPositiveButton("OK", null)
            .create()
        dialog.show()
        styled(a, dialog)
        dialog.findViewById<TextView>(android.R.id.message)?.setTextColor(textColor(a))
    }
}
