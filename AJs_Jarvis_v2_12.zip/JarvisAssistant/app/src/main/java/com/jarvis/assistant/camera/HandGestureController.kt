package com.jarvis.assistant.camera

import android.content.Context
import android.graphics.Bitmap
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.atan2
import kotlin.math.hypot

/**
 * Reads the user's hand from the camera and turns it into zoom / rotation for the HUD.
 * Fingers apart = zoom in, fingers together = zoom out, turning the hand = rotate.
 */
class HandGestureController(
    private val context: Context,
    private val onHand: (active: Boolean, zoom: Float, angle: Float, x: Float, y: Float) -> Unit
) {
    private var landmarker: HandLandmarker? = null
    @Volatile private var loading = false
    private var misses = 0

    fun prepare(onStatus: (String) -> Unit) {
        if (landmarker != null || loading) return
        loading = true
        Thread {
            try {
                val f = File(context.filesDir, "hand_landmarker.task")
                if (!f.exists() || f.length() < 1_000_000) {
                    onStatus("Haath pehchaan model download ho raha hai (sirf pehli baar, kuch MB)...")
                    val req = Request.Builder().url(MODEL_URL).build()
                    OkHttpClient().newCall(req).execute().use { r ->
                        if (!r.isSuccessful) throw RuntimeException("HTTP ${r.code}")
                        val body = r.body ?: throw RuntimeException("empty")
                        f.outputStream().use { o -> body.byteStream().copyTo(o) }
                    }
                }
                val bytes = f.readBytes()
                val buf = ByteBuffer.allocateDirect(bytes.size)
                buf.put(bytes)
                buf.rewind()
                val base = BaseOptions.builder().setModelAssetBuffer(buf).build()
                val opts = HandLandmarker.HandLandmarkerOptions.builder()
                    .setBaseOptions(base)
                    .setNumHands(1)
                    .setRunningMode(RunningMode.IMAGE)
                    .build()
                landmarker = HandLandmarker.createFromOptions(context, opts)
                onStatus("Haath control tayyar: ungliyon ko door-paas karo = zoom, haath ghumao = ghumao")
            } catch (e: Exception) {
                try { File(context.filesDir, "hand_landmarker.task").delete() } catch (x: Exception) { }
                onStatus("Haath control shuru nahi hua: ${e.message}")
            } finally {
                loading = false
            }
        }.start()
    }

    fun process(bmp: Bitmap, mirror: Boolean) {
        val lm = landmarker ?: return
        try {
            val result = lm.detect(BitmapImageBuilder(bmp).build())
            val hands = result.landmarks()
            if (hands.isEmpty()) {
                misses++
                if (misses == 3) onHand(false, 1f, 0f, 0.5f, 0.5f)
                return
            }
            misses = 0
            val h = hands[0]
            val wrist = h[0]
            val mid = h[9]
            val thumb = h[4]
            val index = h[8]
            val size = hypot(
                (mid.x() - wrist.x()).toDouble(), (mid.y() - wrist.y()).toDouble()
            ).toFloat().coerceAtLeast(0.02f)
            val pinch = hypot(
                (thumb.x() - index.x()).toDouble(), (thumb.y() - index.y()).toDouble()
            ).toFloat() / size
            val zoom = 0.55f + pinch.coerceIn(0.12f, 1.3f) * 1.7f
            var ang = atan2(
                (mid.x() - wrist.x()).toDouble(), -(mid.y() - wrist.y()).toDouble()
            ).toFloat()
            if (mirror) ang = -ang
            val cx = (wrist.x() + mid.x()) / 2f
            val cy = (wrist.y() + mid.y()) / 2f
            onHand(true, zoom, ang, if (mirror) 1f - cx else cx, cy)
        } catch (e: Exception) {
        }
    }

    fun close() {
        try { landmarker?.close() } catch (e: Exception) { }
        landmarker = null
    }

    companion object {
        private const val MODEL_URL =
            "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"
    }
}
