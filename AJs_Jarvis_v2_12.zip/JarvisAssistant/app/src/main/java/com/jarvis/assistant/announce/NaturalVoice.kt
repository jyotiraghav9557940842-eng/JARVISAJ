package com.jarvis.assistant.announce

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Base64
import com.jarvis.assistant.JarvisApp
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Human-sounding announcements: Gemini text-to-speech in the same voice the user chose for Jarvis. */
object NaturalVoice {
    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()
    private val models = listOf("gemini-2.5-flash-preview-tts", "gemini-2.5-flash-tts")
    @Volatile private var goodModel: String? = null

    @Synchronized
    fun speak(context: Context, text: String): Boolean {
        val prefs = JarvisApp.instance.preferences
        val key = prefs.apiKey.trim()
        if (key.isBlank()) return false
        val voice = prefs.voice.ifBlank { "Aoede" }
        val prompt = "Say this warmly and naturally, like a friendly person talking on the phone, " +
            "in a relaxed everyday Hindi-English (Hinglish) tone, not like a robot: $text"
        val tryModels = goodModel?.let { listOf(it) } ?: models
        for (m in tryModels) {
            try {
                val body = JSONObject()
                    .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                    .put("generationConfig", JSONObject()
                        .put("responseModalities", JSONArray().put("AUDIO"))
                        .put("speechConfig", JSONObject().put("voiceConfig", JSONObject()
                            .put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
                val req = Request.Builder()
                    .url("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent?key=$key")
                    .post(body.toString().toRequestBody("application/json".toMediaType()))
                    .build()
                client.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val txt = resp.body?.string().orEmpty()
                        val data = JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
                            .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
                            .getJSONObject("inlineData").getString("data")
                        val pcm = Base64.decode(data, Base64.DEFAULT)
                        if (pcm.size > 2000) {
                            play(pcm)
                            goodModel = m
                            return true
                        }
                    }
                }
            } catch (e: Exception) {
            }
        }
        return false
    }

    private fun play(pcm: ByteArray) {
        val sr = 24000
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sr)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(pcm.size)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track.write(pcm, 0, pcm.size)
        track.play()
        Thread.sleep(pcm.size / 2 * 1000L / sr + 350)
        track.release()
    }
}
