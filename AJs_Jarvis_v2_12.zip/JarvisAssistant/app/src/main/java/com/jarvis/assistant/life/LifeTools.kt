package com.jarvis.assistant.life

import android.app.ActivityManager
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import com.google.gson.JsonObject
import com.jarvis.assistant.data.repository.ActivityLog
import com.jarvis.assistant.data.repository.StatsStore
import com.jarvis.assistant.data.repository.TaskStore
import com.jarvis.assistant.notifications.NotificationHub
import com.jarvis.assistant.reminders.ReminderReceiver
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Calendar
import java.util.Locale

/** Everyday helper tools: notes, lists, expenses, habits, birthdays, diary, reminders, calculator and more. */
object LifeTools {

    private fun JsonObject.s(k: String): String =
        try { if (has(k) && !get(k).isJsonNull) get(k).asString.trim() else "" } catch (e: Exception) { "" }

    private fun JsonObject.i(k: String, d: Int): Int =
        try { if (has(k) && !get(k).isJsonNull) get(k).asDouble.toInt() else d } catch (e: Exception) { d }

    /** A small list of JSON records kept in the phone's private storage. */
    class JList(private val ctx: Context, private val name: String) {
        private fun sp() = ctx.applicationContext.getSharedPreferences("jarvis_life", Context.MODE_PRIVATE)

        @Synchronized
        fun all(): List<JSONObject> {
            val a = try { JSONArray(sp().getString(name, "[]")) } catch (e: Exception) { JSONArray() }
            return (0 until a.length()).map { a.getJSONObject(it) }
        }

        @Synchronized
        fun write(items: List<JSONObject>) {
            val a = JSONArray()
            items.forEach { a.put(it) }
            sp().edit().putString(name, a.toString()).apply()
        }

        @Synchronized
        fun add(o: JSONObject, max: Int = 400) {
            val l = all().toMutableList()
            l.add(o)
            while (l.size > max) l.removeAt(0)
            write(l)
        }

        @Synchronized
        fun removeIf(pred: (JSONObject) -> Boolean): Int {
            val l = all()
            val keep = l.filterNot(pred)
            write(keep)
            return l.size - keep.size
        }
    }

    fun handle(ctx: Context, name: String, a: JsonObject): String? = try {
        dispatch(ctx, name, a)
    } catch (e: Exception) {
        "That did not work: ${e.message}"
    }

    private fun dispatch(ctx: Context, name: String, a: JsonObject): String? = when (name) {
        "note_add" -> noteAdd(ctx, a.s("text"))
        "note_list" -> noteList(ctx, a.s("keyword"))
        "note_delete" -> noteDelete(ctx, a.s("keyword"))
        "list_add" -> listAdd(ctx, a.s("list"), a.s("item"))
        "list_show" -> listShow(ctx, a.s("list"))
        "list_remove" -> listRemove(ctx, a.s("list"), a.s("item"))
        "expense_add" -> expenseAdd(ctx, a.s("amount"), a.s("category"), a.s("note"))
        "expense_summary" -> expenseSummary(ctx, a.s("period"))
        "habit_done" -> habitDone(ctx, a.s("name"))
        "habit_status" -> habitStatus(ctx, a.s("name"))
        "birthday_add" -> birthdayAdd(ctx, a.s("name"), a.i("day", 0), a.i("month", 0))
        "birthdays_upcoming" -> birthdaysUpcoming(ctx, a.i("days", 30))
        "journal_add" -> journalAdd(ctx, a.s("text"), a.s("mood"))
        "journal_read" -> journalRead(ctx, a.i("days", 7))
        "daily_reminder" -> dailyReminder(ctx, a.s("text"), a.i("hour", -1), a.i("minute", 0))
        "reminders_list" -> remindersList(ctx)
        "reminder_cancel" -> reminderCancel(ctx, a.s("keyword"))
        "calculate" -> calculate(a.s("expression"))
        "clipboard_set" -> clipboardSet(ctx, a.s("text"))
        "clipboard_get" -> clipboardGet(ctx)
        "share_text" -> shareText(ctx, a.s("text"))
        "system_status" -> systemStatus(ctx)
        "random_pick" -> randomPick(a.s("kind"), a.s("options"), a.i("max", 100))
        "world_clock" -> worldClock(a.s("place"))
        "days_until" -> daysUntil(a.s("date"))
        "ringer_mode" -> ringerMode(ctx, a.s("mode"))
        "sos_dial" -> sosDial(ctx, a.s("number"))
        "pomodoro" -> pomodoro(ctx, a.i("work_minutes", 25), a.i("break_minutes", 5), a.i("rounds", 4))
        "water_reminders" -> waterReminders(ctx, a.i("every_minutes", 60), a.i("count", 6))
        "command_stats" -> StatsStore.summary(ctx)
        "daily_briefing" -> dailyBriefing(ctx)
        else -> null
    }

    private fun when_(t: Long) = ActivityLog.whenText(t)

    // ---------------- notes ----------------
    private fun noteAdd(ctx: Context, text: String): String {
        if (text.isBlank()) return "No note text was given."
        JList(ctx, "notes").add(JSONObject().put("t", System.currentTimeMillis()).put("x", text.take(500)))
        return "Note saved."
    }

    private fun noteList(ctx: Context, kw: String): String {
        val k = kw.lowercase()
        val l = JList(ctx, "notes").all().filter { k.isEmpty() || it.getString("x").lowercase().contains(k) }.takeLast(10)
        if (l.isEmpty()) return "No notes found."
        return l.joinToString("\n") { "- ${when_(it.getLong("t"))}: ${it.getString("x")}" }
    }

    private fun noteDelete(ctx: Context, kw: String): String {
        if (kw.isBlank()) return "Say which note to delete (a word from it)."
        val n = JList(ctx, "notes").removeIf { it.getString("x").lowercase().contains(kw.lowercase()) }
        return if (n > 0) "Deleted $n note(s)." else "No note matched."
    }

    // ---------------- named lists ----------------
    private fun listAdd(ctx: Context, list: String, item: String): String {
        if (list.isBlank() || item.isBlank()) return "Need a list name and an item."
        val l = JList(ctx, "lists")
        val items = item.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        items.forEach { l.add(JSONObject().put("l", list.lowercase()).put("i", it.take(120))) }
        return "Added ${items.size} item(s) to the ${list.lowercase()} list."
    }

    private fun listShow(ctx: Context, list: String): String {
        val all = JList(ctx, "lists").all()
        if (list.isBlank()) {
            if (all.isEmpty()) return "There are no lists yet."
            return all.groupBy { it.getString("l") }.entries.joinToString("\n") { "- ${it.key}: ${it.value.size} item(s)" }
        }
        val items = all.filter { it.getString("l") == list.lowercase() }
        if (items.isEmpty()) return "The ${list.lowercase()} list is empty."
        return items.joinToString("\n") { "- ${it.getString("i")}" }
    }

    private fun listRemove(ctx: Context, list: String, item: String): String {
        if (list.isBlank()) return "Need a list name."
        val n = JList(ctx, "lists").removeIf {
            it.getString("l") == list.lowercase() && (item.isBlank() || it.getString("i").lowercase().contains(item.lowercase()))
        }
        return if (n > 0) "Removed $n item(s)." else "Nothing matched."
    }

    // ---------------- expenses ----------------
    private fun expenseAdd(ctx: Context, amount: String, category: String, note: String): String {
        val v = amount.replace(Regex("[^0-9.]"), "").toDoubleOrNull() ?: return "I could not read the amount."
        val cat = category.ifBlank { "general" }.lowercase()
        val l = JList(ctx, "expenses")
        l.add(JSONObject().put("t", System.currentTimeMillis()).put("a", v).put("c", cat).put("n", note.take(80)))
        val start = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
        }.timeInMillis
        val today = l.all().filter { it.getLong("t") >= start }.sumOf { it.getDouble("a") }
        return "Saved Rs ${fmt(v)} for $cat. Today's total is Rs ${fmt(today)}."
    }

    private fun expenseSummary(ctx: Context, period: String): String {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
        }
        val p = period.lowercase()
        val from = when {
            p.contains("week") || p.contains("hafta") -> { cal.add(Calendar.DAY_OF_YEAR, -6); cal.timeInMillis }
            p.contains("month") || p.contains("mahin") -> { cal.set(Calendar.DAY_OF_MONTH, 1); cal.timeInMillis }
            p.contains("all") || p.contains("sab") -> 0L
            else -> cal.timeInMillis
        }
        val l = JList(ctx, "expenses").all().filter { it.getLong("t") >= from }
        if (l.isEmpty()) return "No expenses saved for that period."
        val total = l.sumOf { it.getDouble("a") }
        val by = l.groupBy { it.getString("c") }.mapValues { e -> e.value.sumOf { it.getDouble("a") } }
            .entries.sortedByDescending { it.value }
        return "Total Rs ${fmt(total)} in ${l.size} entries.\n" + by.joinToString("\n") { "- ${it.key}: Rs ${fmt(it.value)}" }
    }

    private fun fmt(v: Double): String = if (v == Math.floor(v)) v.toLong().toString() else String.format(Locale.US, "%.2f", v)

    // ---------------- habits ----------------
    private fun streak(ctx: Context, name: String): Int {
        val days = JList(ctx, "habits").all().filter { it.getString("h") == name.lowercase() }.map { it.getString("d") }.toSet()
        var d = LocalDate.now()
        if (!days.contains(d.toString())) d = d.minusDays(1)
        var n = 0
        while (days.contains(d.toString())) { n++; d = d.minusDays(1) }
        return n
    }

    private fun habitDone(ctx: Context, name: String): String {
        if (name.isBlank()) return "Which habit?"
        val today = LocalDate.now().toString()
        val l = JList(ctx, "habits")
        if (l.all().any { it.getString("h") == name.lowercase() && it.getString("d") == today }) {
            return "Already marked for today. Streak: ${streak(ctx, name)} day(s)."
        }
        l.add(JSONObject().put("h", name.lowercase()).put("d", today), 1500)
        return "Marked '$name' done today. Streak: ${streak(ctx, name)} day(s)."
    }

    private fun habitStatus(ctx: Context, name: String): String {
        val all = JList(ctx, "habits").all()
        if (name.isBlank()) {
            val names = all.map { it.getString("h") }.distinct()
            if (names.isEmpty()) return "No habits tracked yet."
            val today = LocalDate.now().toString()
            return names.joinToString("\n") { n ->
                val done = all.any { it.getString("h") == n && it.getString("d") == today }
                "- $n: streak ${streak(ctx, n)} day(s), " + if (done) "done today" else "not done today"
            }
        }
        val days = all.filter { it.getString("h") == name.lowercase() }.map { it.getString("d") }.toSet()
        val last7 = (6 downTo 0).joinToString(" ") { if (days.contains(LocalDate.now().minusDays(it.toLong()).toString())) "Y" else "-" }
        return "$name: streak ${streak(ctx, name)} day(s). Last 7 days (old to new): $last7"
    }

    // ---------------- birthdays ----------------
    private fun birthdayAdd(ctx: Context, name: String, day: Int, month: Int): String {
        if (name.isBlank() || day !in 1..31 || month !in 1..12) return "Need a name, a day (1-31) and a month (1-12)."
        val l = JList(ctx, "bdays")
        l.removeIf { it.getString("n").equals(name, ignoreCase = true) }
        l.add(JSONObject().put("n", name).put("d", day).put("m", month))
        return "Saved ${name}'s birthday: $day/$month."
    }

    private fun nextBirthday(day: Int, month: Int): LocalDate {
        val today = LocalDate.now()
        fun at(y: Int): LocalDate = try { LocalDate.of(y, month, day) } catch (e: Exception) { LocalDate.of(y, 3, 1) }
        val t = at(today.year)
        return if (t.isBefore(today)) at(today.year + 1) else t
    }

    private fun birthdaysUpcoming(ctx: Context, days: Int): String {
        val l = JList(ctx, "bdays").all()
        if (l.isEmpty()) return "No birthdays saved."
        val today = LocalDate.now()
        val rows = l.map { Triple(it.getString("n"), ChronoUnit.DAYS.between(today, nextBirthday(it.getInt("d"), it.getInt("m"))), "${it.getInt("d")}/${it.getInt("m")}") }
            .filter { it.second <= days.coerceIn(1, 366) }.sortedBy { it.second }
        if (rows.isEmpty()) return "No birthdays in the next $days days."
        return rows.joinToString("\n") {
            "- ${it.first}: " + when (it.second) { 0L -> "TODAY"; 1L -> "tomorrow"; else -> "in ${it.second} days" } + " (${it.third})"
        }
    }

    // ---------------- diary ----------------
    private fun journalAdd(ctx: Context, text: String, mood: String): String {
        if (text.isBlank()) return "Nothing to write."
        JList(ctx, "journal").add(JSONObject().put("t", System.currentTimeMillis()).put("x", text.take(800)).put("m", mood))
        return "Diary entry saved."
    }

    private fun journalRead(ctx: Context, days: Int): String {
        val from = System.currentTimeMillis() - days.coerceIn(1, 365) * 86_400_000L
        val l = JList(ctx, "journal").all().filter { it.getLong("t") >= from }.takeLast(15)
        if (l.isEmpty()) return "No diary entries in that time."
        return l.joinToString("\n") { "- ${when_(it.getLong("t"))}" + (if (it.optString("m").isNotBlank()) " [${it.getString("m")}]" else "") + ": ${it.getString("x")}" }
    }

    // ---------------- reminders ----------------
    private fun alarmFor(ctx: Context, id: Int, text: String, whenMs: Long, daily: Boolean, h: Int, m: Int) {
        val i = Intent(ctx, ReminderReceiver::class.java).putExtra("text", text).putExtra("id", id)
            .putExtra("daily", daily).putExtra("h", h).putExtra("m", m)
        val pi = PendingIntent.getBroadcast(ctx, id, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val exact = android.os.Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pi)
    }

    fun scheduleDaily(ctx: Context, id: Int, text: String, h: Int, m: Int) {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        if (cal.timeInMillis <= System.currentTimeMillis() + 1000) cal.add(Calendar.DAY_OF_YEAR, 1)
        alarmFor(ctx, id, text, cal.timeInMillis, true, h, m)
    }

    fun rescheduleAll(ctx: Context) {
        JList(ctx, "dailyrem").all().forEach { scheduleDaily(ctx, it.getInt("id"), it.getString("x"), it.getInt("h"), it.getInt("m")) }
    }

    private fun dailyReminder(ctx: Context, text: String, h: Int, m: Int): String {
        if (text.isBlank() || h !in 0..23) return "Need the reminder text and the hour (0-23)."
        val id = 20000 + (System.nanoTime() % 60000).toInt()
        JList(ctx, "dailyrem").add(JSONObject().put("id", id).put("x", text.take(120)).put("h", h).put("m", m.coerceIn(0, 59)))
        scheduleDaily(ctx, id, text, h, m.coerceIn(0, 59))
        return "Done. Every day at ${String.format(Locale.US, "%02d:%02d", h, m.coerceIn(0, 59))} I will remind: $text"
    }

    private fun remindersList(ctx: Context): String {
        val l = JList(ctx, "dailyrem").all()
        if (l.isEmpty()) return "No daily reminders are set."
        return l.joinToString("\n") { "- ${String.format(Locale.US, "%02d:%02d", it.getInt("h"), it.getInt("m"))}: ${it.getString("x")}" }
    }

    private fun reminderCancel(ctx: Context, kw: String): String {
        if (kw.isBlank()) return "Say a word from the reminder to cancel."
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val l = JList(ctx, "dailyrem")
        val victims = l.all().filter { it.getString("x").lowercase().contains(kw.lowercase()) }
        victims.forEach {
            val pi = PendingIntent.getBroadcast(
                ctx, it.getInt("id"), Intent(ctx, ReminderReceiver::class.java),
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pi != null) { am.cancel(pi); pi.cancel() }
        }
        l.removeIf { it.getString("x").lowercase().contains(kw.lowercase()) }
        return if (victims.isNotEmpty()) "Cancelled ${victims.size} reminder(s)." else "No reminder matched."
    }

    private fun pomodoro(ctx: Context, work: Int, brk: Int, rounds: Int): String {
        val w = work.coerceIn(5, 90)
        val b = brk.coerceIn(1, 30)
        val r = rounds.coerceIn(1, 8)
        var t = System.currentTimeMillis()
        var id = 50000 + (System.nanoTime() % 9000).toInt()
        for (n in 1..r) {
            t += w * 60_000L
            alarmFor(ctx, id++, "Round $n/$r poora! Ab $b minute ka break lo.", t, false, -1, 0)
            t += b * 60_000L
            if (n < r) alarmFor(ctx, id++, "Break khatam. Agla round shuru karo.", t, false, -1, 0)
        }
        return "Focus plan set: $r rounds of $w minutes with $b minute breaks. I will notify at every change."
    }

    private fun waterReminders(ctx: Context, every: Int, count: Int): String {
        val e = every.coerceIn(15, 240)
        val c = count.coerceIn(1, 12)
        var id = 60000 + (System.nanoTime() % 4000).toInt()
        for (n in 1..c) alarmFor(ctx, id++, "Paani peene ka time ho gaya!", System.currentTimeMillis() + n * e * 60_000L, false, -1, 0)
        return "Water reminders set: $c times, every $e minutes."
    }

    // ---------------- calculator ----------------
    private class Parser(val s: String) {
        var p = 0
        fun parse(): Double {
            val v = expr()
            skip()
            if (p < s.length) throw RuntimeException("unexpected '${s[p]}'")
            return v
        }
        private fun skip() { while (p < s.length && s[p] == ' ') p++ }
        private fun eat(c: Char): Boolean { skip(); if (p < s.length && s[p] == c) { p++; return true }; return false }
        private fun expr(): Double {
            var v = term()
            while (true) {
                v = if (eat('+')) v + term() else if (eat('-')) v - term() else return v
            }
        }
        private fun term(): Double {
            var v = power()
            while (true) {
                v = if (eat('*')) v * power()
                else if (eat('/')) { val d = power(); if (d == 0.0) throw RuntimeException("divide by zero"); v / d }
                else return v
            }
        }
        private fun power(): Double { val b = unary(); return if (eat('^')) Math.pow(b, power()) else b }
        private fun unary(): Double {
            if (eat('-')) return -unary()
            if (eat('+')) return unary()
            return primary()
        }
        private fun postfix(v: Double): Double { var r = v; while (eat('%')) r /= 100.0; return r }
        private fun primary(): Double {
            skip()
            if (eat('(')) {
                val v = expr()
                if (!eat(')')) throw RuntimeException("missing )")
                return postfix(v)
            }
            val st = p
            if (p < s.length && (s[p].isDigit() || s[p] == '.')) {
                while (p < s.length && (s[p].isDigit() || s[p] == '.')) p++
                return postfix(s.substring(st, p).toDouble())
            }
            if (p < s.length && s[p].isLetter()) {
                while (p < s.length && s[p].isLetter()) p++
                val n = s.substring(st, p).lowercase()
                if (n == "pi") return Math.PI
                if (n == "e") return Math.E
                if (!eat('(')) throw RuntimeException("unknown word '$n'")
                val a = expr()
                if (!eat(')')) throw RuntimeException("missing )")
                return when (n) {
                    "sqrt" -> Math.sqrt(a)
                    "sin" -> Math.sin(Math.toRadians(a))
                    "cos" -> Math.cos(Math.toRadians(a))
                    "tan" -> Math.tan(Math.toRadians(a))
                    "log" -> Math.log10(a)
                    "ln" -> Math.log(a)
                    "abs" -> Math.abs(a)
                    "round" -> Math.round(a).toDouble()
                    else -> throw RuntimeException("unknown function '$n'")
                }
            }
            throw RuntimeException("cannot read the expression")
        }
    }

    private fun calculate(expr: String): String {
        if (expr.isBlank()) return "No expression was given."
        val clean = expr.replace("×", "*").replace("÷", "/").replace(",", "")
            .replace(Regex("(?<=[0-9)])\\s*[xX]\\s*(?=[0-9(])"), "*")
        val v = Parser(clean).parse()
        return "$expr = " + if (Math.abs(v) < 1e15 && v == Math.floor(v)) v.toLong().toString() else String.format(Locale.US, "%.6f", v).trimEnd('0').trimEnd('.')
    }

    // ---------------- phone helpers ----------------
    private fun clipboardSet(ctx: Context, text: String): String {
        if (text.isBlank()) return "Nothing to copy."
        Handler(Looper.getMainLooper()).post {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("jarvis", text))
        }
        return "Copied to the clipboard."
    }

    private fun clipboardGet(ctx: Context): String {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString().orEmpty()
        return if (t.isNotBlank()) "Clipboard says: " + t.take(500)
        else "The clipboard is empty, or Android hides it while Jarvis is in the background. Open Jarvis and try again."
    }

    private fun shareText(ctx: Context, text: String): String {
        if (text.isBlank()) return "Nothing to share."
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        ctx.startActivity(Intent.createChooser(send, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "The share sheet is open."
    }

    private fun systemStatus(ctx: Context): String {
        val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val st = b?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        val sf = StatFs(Environment.getDataDirectory().path)
        val freeGb = sf.availableBytes / 1_073_741_824.0
        val totGb = sf.totalBytes / 1_073_741_824.0
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val net = when {
            caps == null -> "no internet"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobile data"
            else -> "connected"
        }
        return "Battery ${if (lvl >= 0) lvl * 100 / sc else 0}%" + (if (charging) " (charging)" else "") +
            ". Storage free ${String.format(Locale.US, "%.1f", freeGb)} GB of ${String.format(Locale.US, "%.0f", totGb)} GB" +
            ". Memory free ${mi.availMem / 1_048_576} MB of ${mi.totalMem / 1_048_576} MB. Network: $net. " +
            "Time: " + ZonedDateTime.now().format(DateTimeFormatter.ofPattern("EEE d MMM, h:mm a", Locale.ENGLISH))
    }

    private fun randomPick(kind: String, options: String, max: Int): String {
        val r = java.util.Random()
        return when (kind.lowercase()) {
            "coin" -> "The coin shows " + if (r.nextBoolean()) "HEADS." else "TAILS."
            "dice" -> "The dice shows ${r.nextInt(6) + 1}."
            "number" -> "Random number: ${r.nextInt(max.coerceIn(2, 1_000_000)) + 1} (from 1 to ${max.coerceIn(2, 1_000_000)})."
            else -> {
                val l = options.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                if (l.isEmpty()) "Give me the options, separated by commas." else "I pick: " + l[r.nextInt(l.size)]
            }
        }
    }

    private val zones = mapOf(
        "india" to "Asia/Kolkata", "delhi" to "Asia/Kolkata", "mumbai" to "Asia/Kolkata", "kolkata" to "Asia/Kolkata",
        "london" to "Europe/London", "uk" to "Europe/London", "new york" to "America/New_York", "usa" to "America/New_York",
        "america" to "America/New_York", "los angeles" to "America/Los_Angeles", "california" to "America/Los_Angeles",
        "toronto" to "America/Toronto", "dubai" to "Asia/Dubai", "uae" to "Asia/Dubai", "riyadh" to "Asia/Riyadh",
        "saudi" to "Asia/Riyadh", "tokyo" to "Asia/Tokyo", "japan" to "Asia/Tokyo", "beijing" to "Asia/Shanghai",
        "china" to "Asia/Shanghai", "singapore" to "Asia/Singapore", "sydney" to "Australia/Sydney",
        "australia" to "Australia/Sydney", "paris" to "Europe/Paris", "france" to "Europe/Paris", "berlin" to "Europe/Berlin",
        "germany" to "Europe/Berlin", "moscow" to "Europe/Moscow", "russia" to "Europe/Moscow", "karachi" to "Asia/Karachi",
        "pakistan" to "Asia/Karachi", "dhaka" to "Asia/Dhaka", "bangladesh" to "Asia/Dhaka", "kathmandu" to "Asia/Kathmandu",
        "nepal" to "Asia/Kathmandu", "colombo" to "Asia/Colombo", "sri lanka" to "Asia/Colombo"
    )

    private fun worldClock(place: String): String {
        val key = place.lowercase().trim()
        val zone = zones[key] ?: zones.entries.firstOrNull { key.contains(it.key) }?.value ?: key
        val z = try { ZoneId.of(zone) } catch (e: Exception) { return "I do not know the time zone for '$place'." }
        return "In $place it is " + ZonedDateTime.now(z).format(DateTimeFormatter.ofPattern("EEEE, d MMM, h:mm a", Locale.ENGLISH))
    }

    private fun daysUntil(date: String): String {
        val n = Regex("\\d+").findAll(date).map { it.value.toInt() }.toList()
        val today = LocalDate.now()
        val target: LocalDate = try {
            when {
                n.size >= 3 -> if (n[0] > 31) LocalDate.of(n[0], n[1], n[2]) else LocalDate.of(if (n[2] < 100) 2000 + n[2] else n[2], n[1], n[0])
                n.size == 2 -> nextBirthday(n[0], n[1])
                else -> return "Tell me the date, for example 25-12 or 2027-01-26."
            }
        } catch (e: Exception) { return "That date is not valid." }
        val d = ChronoUnit.DAYS.between(today, target)
        return when {
            d > 0 -> "$d day(s) to go until $target."
            d == 0L -> "That is today!"
            else -> "That date was ${-d} day(s) ago ($target)."
        }
    }

    private fun ringerMode(ctx: Context, mode: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return try {
            when (mode.lowercase()) {
                "normal", "ring", "loud" -> { am.ringerMode = AudioManager.RINGER_MODE_NORMAL; "Ringer is normal now." }
                "vibrate" -> { am.ringerMode = AudioManager.RINGER_MODE_VIBRATE; "Phone is on vibrate." }
                "silent", "mute" -> { am.ringerMode = AudioManager.RINGER_MODE_SILENT; "Phone is silent." }
                else -> "Mode must be normal, vibrate or silent."
            }
        } catch (e: SecurityException) {
            try { am.ringerMode = AudioManager.RINGER_MODE_VIBRATE } catch (x: Exception) { }
            "Android needs Do Not Disturb access for full silent, so I set vibrate instead."
        }
    }

    private fun sosDial(ctx: Context, number: String): String {
        val n = number.ifBlank { "112" }.replace(Regex("[^0-9+]"), "")
        ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$n")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "The dialer is open with $n. The user must press the call button."
    }

    // ---------------- briefing ----------------
    private fun dailyBriefing(ctx: Context): String {
        val sb = StringBuilder()
        sb.append("Today is ").append(ZonedDateTime.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM, h:mm a", Locale.ENGLISH))).append(".\n")
        sb.append(systemStatus(ctx).substringBefore(". Storage")).append(".\n")
        val tasks = TaskStore.pending(ctx).take(5)
        if (tasks.isNotEmpty()) sb.append("Pending tasks: ").append(tasks.joinToString("; ") { it.title + if (it.due.isNotBlank()) " (due ${it.due})" else "" }).append(".\n")
        val bd = birthdaysUpcoming(ctx, 3)
        if (!bd.startsWith("No ")) sb.append("Birthdays soon:\n").append(bd).append('\n')
        val rem = remindersList(ctx)
        if (!rem.startsWith("No ")) sb.append("Daily reminders:\n").append(rem).append('\n')
        val today = LocalDate.now().toString()
        val habits = JList(ctx, "habits").all()
        val notDone = habits.map { it.getString("h") }.distinct().filter { n -> habits.none { it.getString("h") == n && it.getString("d") == today } }
        if (notDone.isNotEmpty()) sb.append("Habits not done yet today: ").append(notDone.joinToString(", ")).append(".\n")
        val msgs = NotificationHub.recent("all", 50)
        if (msgs.isNotEmpty()) {
            val who = msgs.groupBy { it.sender }.entries.sortedByDescending { it.value.size }.take(3)
            sb.append("Recent messages: ").append(msgs.size).append(" (from ").append(who.joinToString(", ") { it.key }).append(").\n")
        }
        return sb.toString()
    }
}
