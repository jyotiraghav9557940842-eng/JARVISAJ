package com.jarvis.assistant.util

/** Home-screen UI styles. mode: reactor | sphere | plexus | image | quantum | radar | helix | hexgrid | aurora | matrix | orbit | spectrum | plasma | galaxy. */
object UiStyles {
    class S(
        val name: String,
        val hint: String,
        val mode: String,
        val img: String,          // centrepiece image in assets/orb/ui (image mode)
        val backdrop: String,     // full-screen wallpaper in assets/ui
        val backdropAlpha: Float,
        val spin: Float,
        val palette: String,      // palette applied when the style is chosen
        val btnPreset: Int = 0    // button look applied when the style is chosen
    )

    val all: List<S> = listOf(
        S("Arc Reactor Live", "Chalta hua arc reactor, aawaz par hilta hai", "reactor", "", "", 0f, 0f, "Arc Reactor", 0),
        S("Reactor Wall", "Neela arc reactor wallpaper", "image", "", "arc_wall.jpg", 0.95f, 0f, "Arc Reactor", 1),
        S("Iron Gold Core", "Sunehra Iron Man reactor, ghoomta hua", "image", "iron_gold.png", "", 0f, 1f, "Stark Gold", 2),
        S("War Machine Red", "Laal war-machine HUD", "reactor", "", "war_red.jpg", 0.9f, 0f, "Iron Man", 3),
        S("Fusion Ring", "Neela-narangi ghoomta HUD", "image", "fusion.png", "", 0f, 1f, "Fire & Ice", 5),
        S("JARVIS Compass", "Teal compass HUD", "image", "compass.png", "", 0f, -1f, "Midnight Teal", 1),
        S("Neural Network", "Neela network gola", "plexus", "", "", 0f, 0f, "Arc Reactor", 0),
        S("Particle Mind", "JARVIS soch raha hai: kano ka gola", "sphere", "", "", 0f, 0f, "Classic JARVIS", 0),
        S("Iron Diagnostics", "Iron Man system diagnostics", "image", "diag.png", "", 0f, 0f, "Iron Man", 3),
        S("Stark Desktop", "Stark Industries poora HUD", "image", "stark.png", "", 0f, 0f, "Arc Reactor", 1),
        S("Stealth Frame", "Kaala carbon frame", "reactor", "", "frame.jpg", 1f, 0f, "Titanium", 6),
        S("Hex Blueprint", "Neela blueprint keyboard", "reactor", "", "blueprint.jpg", 0.55f, 0f, "Arc Reactor", 4),
        S("Quantum Rings", "Ghoomte quantum chhalle aur kan", "quantum", "", "", 0f, 0f, "Hologram", 5),
        S("Radar Sweep", "Radar jo chaaron taraf scan karta hai", "radar", "", "", 0f, 0f, "Neon Hacker", 3),
        S("DNA Helix", "Ghoomta hua DNA", "helix", "", "", 0f, 0f, "Emerald Core", 4),
        S("Hex Pulse", "Hexagon ki dhadakti jaali", "hexgrid", "", "", 0f, 0f, "Cyber Steel", 3),
        S("Aurora Waves", "Behti hui aurora ki lehrein", "aurora", "", "", 0f, 0f, "Aurora", 7),
        S("Matrix Orb", "Matrix ke girte akshar", "matrix", "", "", 0f, 0f, "Matrix Green", 3),
        S("Solar Orbit", "Surya ke ird-gird grah", "orbit", "", "", 0f, 0f, "Solar Flare", 5),
        S("Spectrum Ring", "Aawaz ki gol spectrum patti", "spectrum", "", "", 0f, 0f, "Neon Tokyo", 7),
        S("Plasma Ball", "Bijli wala plasma gola", "plasma", "", "", 0f, 0f, "Violet Storm", 5),
        S("Galaxy Spiral", "Ghoomti hui aakashganga", "galaxy", "", "", 0f, 0f, "Nebula", 4)
    )

    fun paletteIndexFor(s: S): Int =
        Palettes.all.indexOfFirst { it.name == s.palette }.let { if (it >= 0) it else Palettes.DEFAULT_INDEX }
}
