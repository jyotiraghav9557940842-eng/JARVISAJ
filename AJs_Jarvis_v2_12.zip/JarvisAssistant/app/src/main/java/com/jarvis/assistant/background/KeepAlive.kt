package com.jarvis.assistant.background

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.audio.WakeTemplates
import com.jarvis.assistant.ui.home.MainViewModel
import com.jarvis.assistant.util.JarvisRuntime

/** Brings Jarvis back when Android restarts one of its always-bound services after the app was swiped away. */
object KeepAlive {

    /** Called when the accessibility, notification or assistant service reconnects. */
    fun restore(context: Context) {
        try {
            val p = JarvisApp.instance.preferences
            if (!p.alwaysOn || JarvisRuntime.sessionOn) return
            if (WakeTemplates.parse(p.wakeTemplates) == null) return
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) return
            Handler(Looper.getMainLooper()).post {
                try {
                    ViewModelProvider(
                        JarvisApp.instance,
                        ViewModelProvider.AndroidViewModelFactory.getInstance(JarvisApp.instance)
                    )[MainViewModel::class.java].startIfAlwaysOn()
                } catch (e: Exception) {
                }
            }
        } catch (e: Exception) {
        }
    }

    private val oemScreens = listOf(
        "com.miui.securitycenter" to "com.miui.permcenter.autostart.AutoStartManagementActivity",
        "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
        "com.coloros.safecenter" to "com.coloros.safecenter.startupapp.StartupAppListActivity",
        "com.oppo.safe" to "com.oppo.safe.permission.startup.StartupAppListActivity",
        "com.oplus.battery" to "com.oplus.battery.ui.BatteryActivity",
        "com.oneplus.security" to "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity",
        "com.iqoo.secure" to "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity",
        "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity",
        "com.samsung.android.lool" to "com.samsung.android.sm.battery.ui.BatteryActivity",
        "com.huawei.systemmanager" to "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"
    )

    /** Opens this phone maker's auto-start / background screen. Falls back to the battery and app info pages. */
    fun openOemSettings(context: Context) {
        for ((pkg, cls) in oemScreens) {
            try {
                context.startActivity(
                    Intent().setComponent(ComponentName(pkg, cls)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                return
            } catch (e: Exception) {
            }
        }
        try {
            context.startActivity(
                Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return
        } catch (e: Exception) {
        }
        try {
            context.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(Uri.parse("package:${context.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
        }
    }
}
