package com.jarvis.assistant.util

/** Tiny process-wide flags shared between screens. */
object JarvisRuntime {
    @Volatile
    var sessionOn: Boolean = false

    /** Set by the home view-model; called after a tool changes the voice so the live session reconnects. */
    /** Sends a JPEG (a screenshot) to the live session as a video frame. */
    @Volatile
    var frameSink: ((ByteArray) -> Unit)? = null

    @Volatile
    var voiceChangeHook: (() -> Unit)? = null
}
