package com.jarvis.assistant.ui.settings

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.data.model.GeminiConstants
import com.jarvis.assistant.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private val preferences by lazy { JarvisApp.instance.preferences }

    override fun onCreate(savedInstanceState: Bundle?) {
        com.jarvis.assistant.util.ThemeManager.apply(this)
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        populateDropdowns()
        loadCurrentSettings()
        setupListeners()
        setupVoiceControls()
        setupThemeControls()
        setupAutoHandle()
        setupSpeakerControls()
        setupAnnounceControls()
        setupVaultControls()
        setupLookButtons()
        try {
            com.jarvis.assistant.vault.SecretStore.remove(this, "api elevenlabs")
            com.jarvis.assistant.vault.SecretStore.remove(this, "api grok")
        } catch (e: Exception) { }
        setupPersonalControls()
    }

    private fun watch(et: android.widget.EditText, onChange: (String) -> Unit) {
        et.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) { onChange(s?.toString().orEmpty()) }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
    }

    private fun setupPersonalControls() {
        if (preferences.userAge > 0) binding.etAge.setText(preferences.userAge.toString())
        binding.etLikes.setText(preferences.likes)
        binding.etDislikes.setText(preferences.dislikes)
        watch(binding.etAge) { preferences.userAge = it.toIntOrNull()?.coerceIn(0, 120) ?: 0 }
        watch(binding.etLikes) { preferences.likes = it }
        watch(binding.etDislikes) { preferences.dislikes = it }
        binding.switchKidsMode.isChecked = preferences.kidsMode
        binding.switchKidsMode.setOnCheckedChangeListener { _, on -> preferences.kidsMode = on }
        when (preferences.voiceMood) {
            1 -> binding.rbMoodNormal.isChecked = true
            2 -> binding.rbMoodCalm.isChecked = true
            3 -> binding.rbMoodEnergy.isChecked = true
            else -> binding.rbMoodAuto.isChecked = true
        }
        binding.rgMood.setOnCheckedChangeListener { _, id ->
            preferences.voiceMood = when (id) {
                binding.rbMoodNormal.id -> 1
                binding.rbMoodCalm.id -> 2
                binding.rbMoodEnergy.id -> 3
                else -> 0
            }
        }
    }

    private fun setupLookButtons() {
        binding.btnLookButtons.setOnClickListener { com.jarvis.assistant.ui.look.LookDialogs.buttons(this) }
        binding.btnLookTexts.setOnClickListener { com.jarvis.assistant.ui.look.LookDialogs.texts(this) }
        binding.btnLookFeatures.setOnClickListener { com.jarvis.assistant.ui.look.LookDialogs.features(this) }
        binding.btnLookStats.setOnClickListener { com.jarvis.assistant.ui.look.LookDialogs.stats(this) }
    }

    private fun refreshVaultList() {
        val names = com.jarvis.assistant.vault.SecretStore.names(this)
        binding.tvVaultList.text = if (names.isEmpty()) "Tijori khaali hai."
        else "Save hai: " + names.joinToString(", ") + "  (values chhupi hui hain)"
    }

    private fun setupVaultControls() {
        refreshVaultList()
        binding.btnVaultSave.setOnClickListener {
            var saved = 0
            val pin = binding.etVaultScreen.text.toString()
            if (pin.isNotEmpty() &&
                com.jarvis.assistant.vault.SecretStore.put(this, com.jarvis.assistant.vault.SecretStore.SCREEN_LOCK, pin)) saved++
            val nm = binding.etVaultName.text.toString()
            val v = binding.etVaultValue.text.toString()
            if (nm.isNotBlank() && v.isNotEmpty() &&
                com.jarvis.assistant.vault.SecretStore.put(this, nm, v)) saved++
            binding.etVaultScreen.setText("")
            binding.etVaultValue.setText("")
            binding.etVaultName.setText("")
            android.widget.Toast.makeText(
                this, if (saved > 0) "Tijori me save ho gaya" else "Kuch bhara nahi", android.widget.Toast.LENGTH_SHORT
            ).show()
            refreshVaultList()
        }
        binding.btnVaultClear.setOnClickListener {
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Tijori khaali kar dein?")
                .setPositiveButton("Haan") { _, _ ->
                    com.jarvis.assistant.vault.SecretStore.clear(this)
                    refreshVaultList()
                }
                .setNegativeButton("Nahi", null)
                .show()
        }
        binding.btnKeepAlive.setOnClickListener {
            preferences.alwaysOn = true
            com.jarvis.assistant.background.KeepAlive.openOemSettings(this)
            android.widget.Toast.makeText(
                this,
                "AJ'S JARVIS ko Auto-start / Background activity ON karo, battery 'No restrictions', aur recents me lock lagao",
                android.widget.Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun setupAnnounceControls() {
        binding.switchAnnounceMsgs.isChecked = preferences.announceMsgs
        binding.switchAnnounceMsgs.setOnCheckedChangeListener { _, on -> preferences.announceMsgs = on }
        binding.switchAnnounceText.isChecked = preferences.announceText
        binding.switchAnnounceText.setOnCheckedChangeListener { _, on -> preferences.announceText = on }
        binding.switchAnnounceBattery.isChecked = preferences.announceBattery
        binding.switchAnnounceBattery.setOnCheckedChangeListener { _, on -> preferences.announceBattery = on }
        binding.switchHandControl.isChecked = preferences.handControl
        binding.switchHandControl.setOnCheckedChangeListener { _, on -> preferences.handControl = on }
        binding.btnDefaultAssistant.setOnClickListener {
            try {
                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    val rm = getSystemService(android.app.role.RoleManager::class.java)
                    if (rm != null && rm.isRoleAvailable(android.app.role.RoleManager.ROLE_ASSISTANT)) {
                        if (rm.isRoleHeld(android.app.role.RoleManager.ROLE_ASSISTANT)) {
                            android.widget.Toast.makeText(this, "Jarvis pehle se default assistant hai", android.widget.Toast.LENGTH_SHORT).show()
                        } else {
                            startActivityForResult(rm.createRequestRoleIntent(android.app.role.RoleManager.ROLE_ASSISTANT), 4711)
                        }
                        return@setOnClickListener
                    }
                }
            } catch (e: Exception) {
            }
            try {
                startActivity(Intent(android.provider.Settings.ACTION_VOICE_INPUT_SETTINGS))
            } catch (e: Exception) {
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
            }
            android.widget.Toast.makeText(this, "Yahan 'Digital assistant app' me AJ'S JARVIS chuno", android.widget.Toast.LENGTH_LONG).show()
        }
    }

    private fun setupSpeakerControls() {
        binding.switchNoiseFilter.isChecked = preferences.noiseFilter
        binding.switchNoiseFilter.setOnCheckedChangeListener { _, on -> preferences.noiseFilter = on }
        binding.switchSpeakerId.isChecked = preferences.speakerId
        binding.switchSpeakerId.setOnCheckedChangeListener { _, on ->
            preferences.speakerId = on
            if (on && preferences.ownerVoiceProfile.isBlank()) {
                android.widget.Toast.makeText(this, "Pehle Voice Setup karke apni awaaz save karo", android.widget.Toast.LENGTH_LONG).show()
            }
        }
        binding.btnSpeakerClear.setOnClickListener {
            com.jarvis.assistant.audio.SpeakerBook.clearAll(this)
            refreshSpeakerList()
        }
        refreshSpeakerList()
    }

    private fun refreshSpeakerList() {
        val names = com.jarvis.assistant.audio.SpeakerBook.names(this)
        binding.tvSpeakerPeople.text = if (names.isEmpty())
            "Abhi koi aur save nahi hai. Anjaan awaaz par Jarvis khud naam poochhega aur save karega."
        else "Save kiye hue log: " + names.joinToString(", ")
    }

    private fun notifAccessOn(): Boolean =
        androidx.core.app.NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)

    private fun setupAutoHandle() {
        binding.switchAutoHandle.isChecked = preferences.autoHandle
        binding.etAutoContacts.setText(preferences.autoHandleContacts)
        binding.switchAutoHandle.setOnCheckedChangeListener { _, on ->
            preferences.autoHandle = on
            if (on && !notifAccessOn()) {
                android.widget.Toast.makeText(this, "Pehle Notification access do", android.widget.Toast.LENGTH_LONG).show()
            }
        }
        binding.etAutoContacts.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) {
                preferences.autoHandleContacts = s?.toString().orEmpty()
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        binding.btnNotifAccess.setOnClickListener {
            startActivity(Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        refreshNotifStatus()
    }

    private fun refreshNotifStatus() {
        binding.tvNotifStatus.text = if (notifAccessOn())
            "Notification access: ON. Jarvis WhatsApp, Gmail aur SMS ke naye messages padh sakta hai."
        else
            "Notification access: OFF. Isko ON karoge tabhi Jarvis messages bata paayega."
    }

    override fun onResume() {
        super.onResume()
        refreshNotifStatus()
    }

    private fun setupThemeControls() {
        val d = resources.displayMetrics.density
        val tm = com.jarvis.assistant.util.ThemeManager
        val all = com.jarvis.assistant.util.Palettes.all
        val cur = tm.index()

        binding.themeRow.removeAllViews()
        val btn = android.widget.TextView(this).apply {
            text = "\uD83C\uDFA8  ${all[cur].name}   \u25B8  Sab ${all.size} themes dekho"
            textSize = 13f
            setTextColor(tm.color(this@SettingsActivity, com.jarvis.assistant.R.attr.primary_cyan))
            setPadding((16 * d).toInt(), (11 * d).toInt(), (16 * d).toInt(), (11 * d).toInt())
            setBackgroundResource(com.jarvis.assistant.R.drawable.bg_input_field)
            setOnClickListener { showPaletteDialog() }
        }
        binding.themeRow.addView(btn)

        val styles = com.jarvis.assistant.util.UiStyles.all
        val curStyle = styles[preferences.uiStyleIndex.coerceIn(0, styles.size - 1)]
        val btnUi = android.widget.TextView(this).apply {
            text = "\uD83D\uDDBC  UI: ${curStyle.name}   \u25B8  ${styles.size} styles"
            textSize = 13f
            setTextColor(tm.color(this@SettingsActivity, com.jarvis.assistant.R.attr.primary_cyan))
            setPadding((16 * d).toInt(), (11 * d).toInt(), (16 * d).toInt(), (11 * d).toInt())
            setBackgroundResource(com.jarvis.assistant.R.drawable.bg_input_field)
            val lp = android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.marginStart = (10 * d).toInt()
            layoutParams = lp
            setOnClickListener { showUiStyleDialog() }
        }
        binding.themeRow.addView(btnUi)

        binding.accentRow.removeAllViews()
        val quick = listOf(0, 1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 22, 27, 29, 33, 36, 60)
        quick.filter { it in all.indices }.forEach { i ->
            val dot = View(this).apply {
                val shape = android.graphics.drawable.GradientDrawable()
                shape.shape = android.graphics.drawable.GradientDrawable.OVAL
                shape.setColor(all[i].c1)
                shape.setStroke(
                    (if (i == cur) 3 else 1) * d.toInt(),
                    if (i == cur) tm.color(this@SettingsActivity, com.jarvis.assistant.R.attr.text_primary) else all[i].c2
                )
                background = shape
                val lp = android.widget.LinearLayout.LayoutParams((34 * d).toInt(), (34 * d).toInt())
                lp.marginEnd = (10 * d).toInt()
                layoutParams = lp
                setOnClickListener {
                    if (preferences.paletteIndex != i) {
                        preferences.paletteIndex = i
                        recreate()
                    }
                }
            }
            binding.accentRow.addView(dot)
        }
    }

    private fun loadThumb(path: String, dark: Boolean): android.graphics.Bitmap? {
        return try {
            val opts = android.graphics.BitmapFactory.Options().apply { inSampleSize = 4 }
            val bmp = assets.open(path).use { android.graphics.BitmapFactory.decodeStream(it, null, opts) } ?: return null
            if (!dark) return bmp
            val out = android.graphics.Bitmap.createBitmap(bmp.width, bmp.height, android.graphics.Bitmap.Config.ARGB_8888)
            val cv = android.graphics.Canvas(out)
            cv.drawColor(android.graphics.Color.rgb(6, 12, 28))
            cv.drawBitmap(bmp, 0f, 0f, null)
            out
        } catch (e: Exception) {
            null
        }
    }

    private fun showUiStyleDialog() {
        val d = resources.displayMetrics.density
        val tm = com.jarvis.assistant.util.ThemeManager
        val styles = com.jarvis.assistant.util.UiStyles.all
        val cur = preferences.uiStyleIndex.coerceIn(0, styles.size - 1)
        val list = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding((12 * d).toInt(), (8 * d).toInt(), (12 * d).toInt(), (8 * d).toInt())
        }
        lateinit var dialog: androidx.appcompat.app.AlertDialog
        styles.forEachIndexed { i, st ->
            val row = android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding((10 * d).toInt(), (10 * d).toInt(), (10 * d).toInt(), (10 * d).toInt())
                val bg = android.graphics.drawable.GradientDrawable()
                bg.cornerRadius = 14 * d
                bg.setColor(android.graphics.Color.rgb(8, 12, 24))
                bg.setStroke((if (i == cur) 3 else 1) * d.toInt(), tm.color(this@SettingsActivity, com.jarvis.assistant.R.attr.primary_cyan))
                background = bg
                val lp = android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.bottomMargin = (8 * d).toInt()
                layoutParams = lp
            }
            val thumb = android.widget.ImageView(this).apply {
                layoutParams = android.widget.LinearLayout.LayoutParams((72 * d).toInt(), (72 * d).toInt())
                scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
                val bmp = when {
                    st.backdrop.isNotBlank() -> loadThumb("ui/${st.backdrop}", false)
                    st.img.isNotBlank() -> loadThumb("orb/ui/${st.img}", true)
                    else -> null
                }
                if (bmp != null) setImageBitmap(bmp) else {
                    setImageResource(com.jarvis.assistant.R.drawable.ic_reactor_logo)
                    setColorFilter(tm.color(this@SettingsActivity, com.jarvis.assistant.R.attr.primary_cyan))
                    setPadding((14 * d).toInt(), (14 * d).toInt(), (14 * d).toInt(), (14 * d).toInt())
                }
            }
            row.addView(thumb)
            val col = android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.VERTICAL
                setPadding((12 * d).toInt(), 0, 0, 0)
            }
            col.addView(android.widget.TextView(this).apply {
                text = (if (i == cur) "\u2713 " else "") + st.name
                textSize = 15f
                setTextColor(android.graphics.Color.WHITE)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            })
            col.addView(android.widget.TextView(this).apply {
                text = st.hint
                textSize = 11f
                setTextColor(android.graphics.Color.rgb(160, 175, 200))
            })
            row.addView(col)
            row.setOnClickListener {
                dialog.dismiss()
                preferences.uiStyleIndex = i
                com.jarvis.assistant.ui.look.ButtonOptions.applyPreset(this, st.btnPreset)
                val pi = com.jarvis.assistant.util.UiStyles.paletteIndexFor(st)
                preferences.paletteIndex = pi
                recreate()
            }
            list.addView(row)
        }
        val scroll = android.widget.ScrollView(this).apply { addView(list) }
        dialog = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("UI style chuno (${styles.size})")
            .setView(scroll)
            .setNegativeButton("Band karo", null)
            .create()
        dialog.show()
    }

    private fun showPaletteDialog() {
        val d = resources.displayMetrics.density
        val all = com.jarvis.assistant.util.Palettes.all
        val cur = com.jarvis.assistant.util.ThemeManager.index()
        val list = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding((12 * d).toInt(), (8 * d).toInt(), (12 * d).toInt(), (8 * d).toInt())
        }
        lateinit var dialog: androidx.appcompat.app.AlertDialog
        all.forEachIndexed { i, p ->
            val row = android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding((12 * d).toInt(), (10 * d).toInt(), (12 * d).toInt(), (10 * d).toInt())
                val bg = android.graphics.drawable.GradientDrawable()
                bg.cornerRadius = 14 * d
                bg.setColor(p.bg)
                bg.setStroke((if (i == cur) 3 else 1) * d.toInt(), if (i == cur) p.c1 else p.surface)
                background = bg
                val lp = android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.bottomMargin = (8 * d).toInt()
                layoutParams = lp
            }
            listOf(p.surface, p.c1, p.c2, p.text).forEach { col ->
                val sw = View(this).apply {
                    val sh = android.graphics.drawable.GradientDrawable()
                    sh.shape = android.graphics.drawable.GradientDrawable.OVAL
                    sh.setColor(col)
                    sh.setStroke(d.toInt(), 0x55FFFFFF)
                    background = sh
                    val l = android.widget.LinearLayout.LayoutParams((20 * d).toInt(), (20 * d).toInt())
                    l.marginEnd = (6 * d).toInt()
                    layoutParams = l
                }
                row.addView(sw)
            }
            val label = android.widget.TextView(this).apply {
                text = (if (i == cur) "\u2713 " else "") + p.name
                textSize = 14f
                setTextColor(p.text)
                setPadding((8 * d).toInt(), 0, 0, 0)
            }
            row.addView(label)
            row.setOnClickListener {
                dialog.dismiss()
                if (preferences.paletteIndex != i) {
                    preferences.paletteIndex = i
                    recreate()
                }
            }
            list.addView(row)
        }
        val scroll = android.widget.ScrollView(this).apply { addView(list) }
        dialog = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Colour theme chuno (${all.size})")
            .setView(scroll)
            .setNegativeButton("Band karo", null)
            .create()
        dialog.show()
    }

    private fun voiceReady(): Boolean =
        com.jarvis.assistant.audio.VoiceProfile.parse(preferences.ownerVoiceProfile) != null &&
            com.jarvis.assistant.audio.WakeTemplates.parse(preferences.wakeTemplates) != null

    private fun refreshVoiceUi() {
        val ready = voiceReady()
        binding.tvVoiceStatus.text = if (ready) {
            "Awaaz aur 'Jarvis' wake word save hai"
        } else {
            "Abhi set nahi hai. Neeche VOICE SETUP dabao"
        }
        binding.switchOwnerLock.setOnCheckedChangeListener(null)
        binding.switchOwnerLock.isChecked = preferences.ownerVoiceLock && ready
        binding.switchAlwaysOn.setOnCheckedChangeListener(null)
        binding.switchAlwaysOn.isChecked = preferences.alwaysOn
        attachVoiceSwitchListeners()
    }

    private fun attachVoiceSwitchListeners() {
        binding.switchOwnerLock.setOnCheckedChangeListener { btn, checked ->
            if (checked && !voiceReady()) {
                btn.isChecked = false
                Toast.makeText(this, "Pehle Voice Setup karo", Toast.LENGTH_SHORT).show()
                openVoiceSetup()
            } else {
                preferences.ownerVoiceLock = checked
            }
        }
        binding.switchAlwaysOn.setOnCheckedChangeListener { btn, checked ->
            if (checked && !voiceReady()) {
                btn.isChecked = false
                Toast.makeText(this, "Wake word ke liye pehle Voice Setup karo", Toast.LENGTH_SHORT).show()
                openVoiceSetup()
            } else {
                preferences.alwaysOn = checked
                if (checked) {
                    Toast.makeText(
                        this,
                        "Battery settings me AJ'S JARVIS ko 'Unrestricted' kar do",
                        Toast.LENGTH_LONG
                    ).show()
                    try {
                        startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    } catch (e: Exception) {
                    }
                }
            }
        }
    }

    private fun setupMemoryControls() {
        val store = com.jarvis.assistant.data.repository.MemoryStore(this)
        fun refresh() {
            binding.tvMemoryCount.text =
                "Jarvis ko ${store.facts().size} baatein hamesha yaad hain. App band karne par bhi yaad rahengi."
        }
        refresh()
        binding.btnMemoryView.setOnClickListener {
            val facts = store.facts()
            val msg = if (facts.isEmpty()) "Abhi kuch save nahi hai. Jarvis se bolo: 'yaad rakhna ...'"
            else facts.joinToString("\n\n") { "• $it" }
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Jarvis ki memory")
                .setMessage(msg)
                .setPositiveButton("OK", null)
                .show()
        }
        binding.btnMemoryClear.setOnClickListener {
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Sab yaadein mita dein?")
                .setPositiveButton("Haan, mitao") { _, _ -> store.clear(); refresh() }
                .setNegativeButton("Nahi", null)
                .show()
        }
    }

    private fun openVoiceSetup() {
        VoiceEnrollDialog(this) { refreshVoiceUi() }.show()
    }

    private fun setupVoiceControls() {
        setupMemoryControls()
        refreshVoiceUi()
        binding.btnVoiceSetup.setOnClickListener { openVoiceSetup() }
        when (preferences.ownerVoiceSensitivity) {
            0 -> binding.rbSensRelaxed.isChecked = true
            2 -> binding.rbSensStrict.isChecked = true
            else -> binding.rbSensNormal.isChecked = true
        }
        binding.rgVoiceSens.setOnCheckedChangeListener { _, id ->
            preferences.ownerVoiceSensitivity = when (id) {
                binding.rbSensRelaxed.id -> 0
                binding.rbSensStrict.id -> 2
                else -> 1
            }
        }
    }

    private fun setupToolbar() {
        binding.btnBack.setOnClickListener {
            finish()
        }

        binding.btnSave.setOnClickListener {
            saveSettings()
        }
    }

    private fun populateDropdowns() {
        // 1. AI Models
        val modelAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            GeminiConstants.SUPPORTED_MODELS
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        binding.spinnerModel.adapter = modelAdapter

        // 2. Voices
        val voiceAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            GeminiConstants.SUPPORTED_VOICES.map { GeminiConstants.VOICE_LABELS[it] ?: it }
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        binding.spinnerVoice.adapter = voiceAdapter

        // 3. Personalities
        val personalityAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            GeminiConstants.SUPPORTED_PERSONALITIES
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        binding.spinnerPersonality.adapter = personalityAdapter

        // 4. Orb themes
        val themeAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            GeminiConstants.SUPPORTED_ORB_THEMES
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        binding.spinnerTheme.adapter = themeAdapter

        binding.spinnerPersonality.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selected = GeminiConstants.SUPPORTED_PERSONALITIES[position]
                binding.tvPersonalityDesc.text = when (selected) {
                    GeminiConstants.PERSONALITY_GIRLFRIEND ->
                        "Warm Hinglish • Emotional but natural • Short spoken replies"
                    GeminiConstants.PERSONALITY_PROFESSIONAL ->
                        "Formal English • Precise • No emojis"
                    GeminiConstants.PERSONALITY_TEACHER ->
                        "Patient • Step by step • Simple examples"
                    GeminiConstants.PERSONALITY_CODER ->
                        "Tech buddy • Debugging help • Plain spoken"
                    GeminiConstants.PERSONALITY_MOTIVATOR ->
                        "Positive coach • Focus & confidence • Action steps"
                    else ->
                        "Friendly • Helpful • Hinglish or English"
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun loadCurrentSettings() {
        binding.etApiKey.setText(preferences.apiKey)
        binding.etUserName.setText(preferences.userName)

        val currentModel = preferences.aiModel
        val modelIndex = GeminiConstants.SUPPORTED_MODELS.indexOf(currentModel)
        if (modelIndex >= 0) {
            binding.spinnerModel.setSelection(modelIndex)
        }

        val currentVoice = preferences.voice
        val voiceIndex = GeminiConstants.SUPPORTED_VOICES.indexOf(currentVoice)
        if (voiceIndex >= 0) {
            binding.spinnerVoice.setSelection(voiceIndex)
        }

        val themeIndex = GeminiConstants.SUPPORTED_ORB_THEMES.indexOf(preferences.orbTheme)
        if (themeIndex >= 0) {
            binding.spinnerTheme.setSelection(themeIndex)
        }

        val currentPersonality = preferences.personality
        val personalityIndex = GeminiConstants.SUPPORTED_PERSONALITIES.indexOf(currentPersonality)
        if (personalityIndex >= 0) {
            binding.spinnerPersonality.setSelection(personalityIndex)
        }
    }

    private fun setupListeners() {
        binding.btnPasteApiKey.setOnClickListener {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = clipboard.primaryClip
            if (clip != null && clip.itemCount > 0) {
                val pasteData = clip.getItemAt(0).text?.toString()?.trim() ?: ""
                if (pasteData.isNotEmpty()) {
                    binding.etApiKey.setText(pasteData)
                    Toast.makeText(this, "API Key pasted from clipboard", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Clipboard is empty", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun saveSettings() {
        val apiKey = binding.etApiKey.text?.toString()?.trim() ?: ""
        val userName = binding.etUserName.text?.toString()?.trim() ?: ""

        val selectedModel = binding.spinnerModel.selectedItem as? String
            ?: GeminiConstants.DEFAULT_MODEL
        val selectedVoice = GeminiConstants.SUPPORTED_VOICES.getOrNull(binding.spinnerVoice.selectedItemPosition)
            ?: "Aoede"
        val selectedPersonality = binding.spinnerPersonality.selectedItem as? String
            ?: GeminiConstants.PERSONALITY_ASSISTANT

        val selectedTheme = binding.spinnerTheme.selectedItem as? String
            ?: GeminiConstants.DEFAULT_ORB_THEME

        preferences.orbTheme = selectedTheme
        preferences.apiKey = apiKey
        preferences.userName = userName
        preferences.aiModel = selectedModel
        preferences.voice = selectedVoice
        preferences.personality = selectedPersonality

        Toast.makeText(this, "Settings saved successfully", Toast.LENGTH_SHORT).show()
        finish()
    }
}
