package com.jarvis.assistant.reminders

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Puts the daily reminders back after the phone restarts. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            try { com.jarvis.assistant.life.LifeTools.rescheduleAll(context) } catch (e: Exception) { }
        }
    }
}
