package com.jarvis.assistant.ui.look

import android.content.Context
import com.jarvis.assistant.R

/** Small store for the "look" settings (button style and custom texts). */
object LookPrefs {
    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences("jarvis_look", Context.MODE_PRIVATE)

    fun int(ctx: Context, key: String, def: Int): Int = sp(ctx).getInt("i_$key", def)
    fun setInt(ctx: Context, key: String, value: Int) { sp(ctx).edit().putInt("i_$key", value).apply(); bump(ctx) }

    fun str(ctx: Context, key: String): String = sp(ctx).getString("s_$key", "") ?: ""
    fun setStr(ctx: Context, key: String, value: String) {
        sp(ctx).edit().apply { if (value.isBlank()) remove("s_$key") else putString("s_$key", value) }.apply()
    }

    fun version(ctx: Context): Int = sp(ctx).getInt("version", 0)
    fun bump(ctx: Context) { sp(ctx).edit().putInt("version", version(ctx) + 1).apply() }

    fun clearTexts(ctx: Context) {
        val e = sp(ctx).edit()
        sp(ctx).all.keys.filter { it.startsWith("s_") }.forEach { e.remove(it) }
        e.apply()
        bump(ctx)
    }
}

object ButtonOptions {
    class Icon(val name: String, val res: Int)
    class Opt(val key: String, val title: String, val group: String, val choices: List<String>, val def: Int)
    class Preset(val name: String, val values: Map<String, Int>)

    val icons: List<Icon> = listOf(
        Icon("Moon", R.drawable.ic_moon), Icon("Power", R.drawable.ic_power), Icon("Pause", R.drawable.ic_ui_pause),
        Icon("Star", R.drawable.ic_ui_star), Icon("Bolt", R.drawable.ic_ui_bolt), Icon("Bell", R.drawable.ic_ui_bell),
        Icon("Lock", R.drawable.ic_ui_lock), Icon("Heart", R.drawable.ic_ui_heart), Icon("Eye", R.drawable.ic_eye),
        Icon("Eye off", R.drawable.ic_ui_eye_off), Icon("Camera", R.drawable.ic_camera), Icon("Video", R.drawable.ic_ui_videocam),
        Icon("Search", R.drawable.ic_ui_search), Icon("History", R.drawable.ic_history), Icon("List", R.drawable.ic_ui_list),
        Icon("Settings", R.drawable.ic_settings), Icon("Tune", R.drawable.ic_ui_tune), Icon("Menu", R.drawable.ic_ui_menu),
        Icon("Shield", R.drawable.ic_ui_shield), Icon("Home", R.drawable.ic_ui_home), Icon("Apps", R.drawable.ic_ui_apps),
        Icon("Mic", R.drawable.ic_mic), Icon("Reactor", R.drawable.ic_reactor_logo)
    )

    /** First entry (0) means "follow the theme". */
    val colours: List<Pair<String, Int>> = listOf(
        "Theme" to 0, "Cyan" to 0xFF00E5FF.toInt(), "Blue" to 0xFF3D8BFF.toInt(), "Purple" to 0xFFA06BFF.toInt(),
        "Pink" to 0xFFFF4ECD.toInt(), "Red" to 0xFFFF3B3B.toInt(), "Orange" to 0xFFFF8A00.toInt(),
        "Gold" to 0xFFFFC53D.toInt(), "Green" to 0xFF2DFF8A.toInt(), "White" to 0xFFFFFFFF.toInt()
    )

    private val iconNames = icons.map { it.name }
    private val colourNames = colours.map { it.first }
    private const val G_ALL = "Sab buttons"

    val all: List<Opt> = buildList {
        add(Opt("shape", "Button ka aakaar", G_ALL, listOf("Gol", "Chauras, gol kone", "Bahut gol kone", "Tez kone", "Patta (leaf)"), 0))
        add(Opt("size", "Button ka size", G_ALL, listOf("Chhota", "Madhyam", "Bada", "Bahut bada"), 1))
        add(Opt("fill", "Button ka bharav", G_ALL, listOf("Glass", "Thos rang", "Sirf kinara", "Kaala thos", "Do-rang gradient"), 0))
        add(Opt("border", "Kinare ki motai", G_ALL, listOf("Nahi", "Patla", "Madhyam", "Mota", "Bahut mota"), 1))
        add(Opt("glow", "Chamak (glow)", G_ALL, listOf("Band", "Halki", "Madhyam", "Tez"), 0))
        add(Opt("iconsize", "Icon ka size", G_ALL, listOf("Chhota", "Madhyam", "Bada"), 1))
        add(Opt("press", "Dabane par animation", G_ALL, listOf("Koi nahi", "Dabna (bounce)", "Dhadkan (pulse)"), 1))
        add(Opt("haptic", "Dabane par kampan", G_ALL, listOf("Band", "Chalu"), 1))
        add(Opt("colour", "Sab buttons ka rang", G_ALL, colourNames, 0))
        val per = listOf(Triple("sleep", "Sleep", 0), Triple("vision", "Vision", 8), Triple("history", "History", 13), Triple("config", "Config", 15))
        for ((k, n, di) in per) {
            add(Opt("icon_$k", "$n ka icon", "$n button", iconNames, di))
            add(Opt("col_$k", "$n ka rang", "$n button", colourNames, 0))
        }
        add(Opt("lbl_show", "Button ke neeche naam", "Naam (label)", listOf("Chhupao", "Dikhao"), 1))
        add(Opt("lbl_size", "Naam ka size", "Naam (label)", listOf("Chhota", "Madhyam", "Bada"), 1))
        add(Opt("lbl_col", "Naam ka rang", "Naam (label)", listOf("Theme", "Safed", "Rang wala", "Sunehra"), 0))
        add(Opt("icon_power", "Power button ka icon", "Power button", iconNames, 1))
        add(Opt("power_size", "Power button ka size", "Power button", listOf("Chhota", "Madhyam", "Bada"), 1))
        add(Opt("power_glow", "Power button ki chamak", "Power button", listOf("Band", "Halki", "Tez"), 0))
        add(Opt("bar_corner", "Neeche ki patti ke kone", "Neeche ki patti", listOf("Seedhe", "Halke gol", "Gol", "Bahut gol"), 2))
        add(Opt("bar_alpha", "Patti ki dhundhlaahat", "Neeche ki patti", listOf("Pakki", "Halki", "Bahut halki", "Lagbhag gayab"), 0))
        add(Opt("bar_pad", "Patti ki unchai", "Neeche ki patti", listOf("Patli", "Madhyam", "Moti"), 1))
        add(Opt("bar_border", "Patti ka kinara", "Neeche ki patti", listOf("Nahi", "Haan"), 0))
        add(Opt("menu_size", "Baayen menu ke akshar", "Baaki", listOf("Chhote", "Madhyam", "Bade"), 1))
        add(Opt("banner_style", "WAKE UP patti ka rang-dhang", "Baaki", listOf("Glass", "Thos", "Sirf kinara"), 0))
        add(Opt("mic_shape", "Mic button ka aakaar", "Baaki", listOf("Gol", "Chauras, gol kone", "Tez kone"), 0))
        add(Opt("flip_shape", "Camera palatne wale button ka aakaar", "Baaki", listOf("Gol", "Chauras, gol kone", "Tez kone"), 0))
        add(Opt("cam_size", "Camera screen ka size", "Baaki", listOf("Chhota", "Madhyam", "Bada"), 1))
    }

    val presets: List<Preset> = listOf(
        Preset("Glass Gol", mapOf("shape" to 0, "fill" to 0, "border" to 1, "glow" to 0, "press" to 1)),
        Preset("Neon Chauras", mapOf("shape" to 1, "fill" to 2, "border" to 2, "glow" to 2, "press" to 1)),
        Preset("Sunehra Thos", mapOf("shape" to 2, "fill" to 1, "border" to 0, "glow" to 1, "colour" to 7)),
        Preset("Tez Tech", mapOf("shape" to 3, "fill" to 2, "border" to 1, "glow" to 1, "press" to 2)),
        Preset("Patta Glass", mapOf("shape" to 4, "fill" to 0, "border" to 1, "glow" to 1)),
        Preset("Squircle Glow", mapOf("shape" to 2, "fill" to 4, "border" to 2, "glow" to 3, "press" to 2)),
        Preset("Kaala Chip", mapOf("shape" to 1, "fill" to 3, "border" to 1, "glow" to 0)),
        Preset("Gradient Pill", mapOf("shape" to 2, "fill" to 4, "border" to 0, "glow" to 1))
    )

    fun get(ctx: Context, key: String): Int =
        LookPrefs.int(ctx, key, all.firstOrNull { it.key == key }?.def ?: 0)

    fun applyPreset(ctx: Context, index: Int) {
        val p = presets.getOrNull(index) ?: return
        for ((k, v) in p.values) LookPrefs.setInt(ctx, k, v)
    }
}

object UiTexts {
    class T(val key: String, val label: String, val def: String)

    val all: List<T> = listOf(
        T("title", "Upar ka bada naam", "JARVIS AJ"),
        T("subtitle", "Naam ke neeche ki line", "AI VOICE ASSISTANT"),
        T("madeby", "Banane wale ka naam", "MADE BY AJ SIR"),
        T("wish", "Baayen box ki line", "YOUR WISH\nIS MY COMMAND"),
        T("lbl_core", "AI CORE ka naam", "AI CORE :"),
        T("val_core", "AI CORE ki value", "ACTIVE"),
        T("lbl_net", "NETWORK ka naam", "NETWORK :"),
        T("lbl_bat", "BATTERY ka naam", "BATTERY :"),
        T("lbl_loc", "LOCATION ka naam", "LOCATION :"),
        T("val_loc", "Jagah ka naam (khaali = apne-aap)", ""),
        T("menu_voice", "Menu 1", "VOICE"),
        T("menu_apps", "Menu 2", "APPS"),
        T("menu_internet", "Menu 3", "INTERNET"),
        T("menu_knowledge", "Menu 4", "KNOWLEDGE"),
        T("menu_settings", "Menu 5", "SETTINGS"),
        T("menu_more", "Menu 6", "MORE..."),
        T("banner_title", "Bade banner ka sheershak", "\" WAKE UP JARVIS \""),
        T("banner_hint", "Banner ke neeche ki line", "SAY THE WAKE WORD OR TAP POWER"),
        T("nav_sleep", "Sleep button ka naam", "SLEEP"),
        T("nav_vision", "Vision button ka naam", "VISION"),
        T("nav_history", "History button ka naam", "HISTORY"),
        T("nav_config", "Config button ka naam", "CONFIG"),
        T("power_on", "Power chalu hone par", "ON"),
        T("power_off", "Power band hone par", "OFF"),
        T("state_idle", "Haalat: aaram", "IDLE"),
        T("state_listening", "Haalat: sun raha hai", "LISTENING"),
        T("state_thinking", "Haalat: soch raha hai", "THINKING"),
        T("state_speaking", "Haalat: bol raha hai", "SPEAKING"),
        T("status_ready", "Status: taiyaar", "READY"),
        T("status_live", "Status: chalu", "LIVE"),
        T("status_connecting", "Status: jud raha hai", "CONNECTING"),
        T("status_retry", "Status: dobara koshish", "RETRYING"),
        T("status_offline", "Status: band", "OFFLINE"),
        T("greet_morning", "Subah ka salaam", "Good morning"),
        T("greet_afternoon", "Dopahar ka salaam", "Good afternoon"),
        T("greet_evening", "Shaam ka salaam", "Good evening"),
        T("greet_night", "Raat ka salaam", "Good night"),
        T("toast_apps", "APPS dabane par sandesh", "Bolo: 'WhatsApp kholo' ya 'YouTube chalao'"),
        T("toast_internet", "INTERNET dabane par sandesh", "Bolo: 'Google par search karo ...'"),
        T("toast_knowledge", "KNOWLEDGE dabane par sandesh", "Kuch bhi poochho, Jarvis jawab dega"),
        T("toast_sleep_off", "Sleep par (pehle se so raha ho)", "Jarvis pehle se sleep mode me hai"),
        T("toast_camera_on", "Camera chalu hone ka sandesh", "Camera ON - Jarvis ab dekh sakta hai")
    )

    private val defaults: Map<String, String> = all.associate { it.key to it.def }

    fun get(ctx: Context, key: String): String {
        val custom = LookPrefs.str(ctx, key)
        return if (custom.isNotBlank()) custom.replace("\\n", "\n") else (defaults[key] ?: "")
    }
}
