package com.jarvis.assistant.ui.home

import android.Manifest
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.LinearGradient
import android.graphics.Shader
import android.app.ActivityManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableString
import android.text.style.RelativeSizeSpan
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.snackbar.Snackbar
import com.jarvis.assistant.R
import com.jarvis.assistant.util.ThemeManager
import com.jarvis.assistant.data.model.ConversationState
import com.jarvis.assistant.databinding.ActivityMainBinding
import com.jarvis.assistant.ui.chat.ChatHistoryBottomSheet
import com.jarvis.assistant.ui.orb.OrbHelper
import com.jarvis.assistant.ui.settings.SettingsActivity
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import com.jarvis.assistant.JarvisApp
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    // Stored on the Application so the voice session survives when the screen is closed (Always-on mode).
    private val viewModel: MainViewModel by lazy {
        androidx.lifecycle.ViewModelProvider(
            JarvisApp.instance,
            androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.getInstance(application)
        )[MainViewModel::class.java]
    }
    private lateinit var orbHelper: OrbHelper

    private val requestAudioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        val micGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (micGranted) {
            viewModel.toggleSession()
        } else {
            Toast.makeText(
                this,
                "Microphone permission is required for voice conversation.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.apply(this)
        appliedThemeKey = ThemeManager.key()
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        startAmbientAnimations()
        applyTexts()
        applyLook()
        handleAssistIntent(intent)
        viewModel.startIfAlwaysOn()

        setupOrb()
        setupListeners()
        observeViewModel()
        styleTexts()
        playEntranceAnimation()
    }

    private var appliedThemeKey = ""

    private var cameraStreamer: com.jarvis.assistant.camera.CameraStreamer? = null
    private var handController: com.jarvis.assistant.camera.HandGestureController? = null

    private val requestCameraPermissionLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            startCamera()
        } else {
            android.widget.Toast.makeText(this, "Camera permission chahiye", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    private fun startCamera() {
        if (cameraStreamer == null) {
            cameraStreamer = com.jarvis.assistant.camera.CameraStreamer(
                this, binding.previewCamera
            ) { jpeg -> viewModel.sendVideoFrame(jpeg) }
        }
        binding.cardCamera.visibility = android.view.View.VISIBLE
        if (JarvisApp.instance.preferences.handControl) {
            if (handController == null) {
                handController = com.jarvis.assistant.camera.HandGestureController(applicationContext) { a, z, ang, x, y ->
                    runOnUiThread { orbHelper.setHand(a, z, ang, x, y) }
                }
            }
            handController?.prepare { msg ->
                runOnUiThread { android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_LONG).show() }
            }
            cameraStreamer?.gestureListener = { bmp, mirror -> handController?.process(bmp, mirror) }
        } else {
            cameraStreamer?.gestureListener = null
        }
        cameraStreamer?.start()
        val msg = if (viewModel.isSessionOn.value) tx("toast_camera_on")
        else "Camera ON - Jarvis ko power ON karo, tab wo dekhega"
        android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_SHORT).show()
    }

    private fun stopCamera() {
        cameraStreamer?.gestureListener = null
        orbHelper.setHand(false, 1f, 0f, 0.5f, 0.5f)
        cameraStreamer?.stop()
        binding.cardCamera.visibility = android.view.View.GONE
    }

    /** Gentle always-on motion so the HUD feels alive: breathing logo, blinking status dot, glowing banner. */
    private fun startAmbientAnimations() {
        fun loop(v: View, prop: String, from: Float, to: Float, ms: Long) {
            android.animation.ObjectAnimator.ofFloat(v, prop, from, to).apply {
                duration = ms
                repeatCount = android.animation.ValueAnimator.INFINITE
                repeatMode = android.animation.ValueAnimator.REVERSE
                interpolator = android.view.animation.AccelerateDecelerateInterpolator()
                start()
            }
        }
        loop(binding.viewStatusDot, "alpha", 1f, 0.3f, 900)
        loop(binding.ivHeaderLogo, "scaleX", 1f, 1.1f, 1600)
        loop(binding.ivHeaderLogo, "scaleY", 1f, 1.1f, 1600)
    }

    private fun handleAssistIntent(i: Intent?) {
        if (i == null) return
        if (i.action == Intent.ACTION_ASSIST || i.getBooleanExtra(EXTRA_ASSIST_START, false)) {
            i.removeExtra(EXTRA_ASSIST_START)
            binding.root.postDelayed({
                if (!viewModel.isSessionOn.value) binding.btnPowerSession.performClick()
            }, 400)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleAssistIntent(intent)
    }

    companion object {
        const val EXTRA_ASSIST_START = "assist_start"
    }

    private fun tx(key: String): String = com.jarvis.assistant.ui.look.UiTexts.get(this, key)

    private fun customGreeting(g: String): String {
        val map = listOf(
            "Good morning" to "greet_morning", "Good afternoon" to "greet_afternoon",
            "Good evening" to "greet_evening", "Hello" to "greet_night"
        )
        for ((d, k) in map) if (g.startsWith(d)) return tx(k) + g.removePrefix(d)
        return g
    }

    private fun applyTexts() {
        binding.tvJarvisTitle.text = tx("title")
        binding.tvSubtitle.text = tx("subtitle")
        binding.tvMadeBy.text = tx("madeby")
        binding.tvWish.text = tx("wish")
        binding.lblCore.text = tx("lbl_core")
        binding.tvStatCore.text = tx("val_core")
        binding.lblNet.text = tx("lbl_net")
        binding.lblBat.text = tx("lbl_bat")
        binding.lblLoc.text = tx("lbl_loc")
        val loc = tx("val_loc")
        if (loc.isNotBlank()) binding.tvStatLoc.text = loc
        binding.menuVoice.text = tx("menu_voice")
        binding.menuApps.text = tx("menu_apps")
        binding.menuInternet.text = tx("menu_internet")
        binding.menuKnowledge.text = tx("menu_knowledge")
        binding.menuSettings.text = tx("menu_settings")
        binding.menuMore.text = tx("menu_more")
        binding.tvBannerTitle.text = tx("banner_title")
        binding.lblSleep.text = tx("nav_sleep")
        binding.lblVision.text = tx("nav_vision")
        binding.lblHistory.text = tx("nav_history")
        binding.lblConfig.text = tx("nav_config")
        styleTexts()
    }

    /** Applies the button style options chosen in Settings. */
    private fun applyLook() {
        val opts = com.jarvis.assistant.ui.look.ButtonOptions
        val d = resources.displayMetrics.density
        fun gi(k: String) = opts.get(this, k)
        val themeAccent = ThemeManager.color(this, R.attr.primary_cyan)
        fun colorOf(idx: Int, fallback: Int) =
            if (idx <= 0 || idx >= opts.colours.size) fallback else opts.colours[idx].second
        val globalCol = colorOf(gi("colour"), themeAccent)
        val shape = gi("shape")
        val fill = gi("fill")
        val borderDp = gi("border")
        val glow = gi("glow")
        val sizeDp = listOf(38, 44, 52, 58)[gi("size").coerceIn(0, 3)]
        val iconPad = listOf(0.30f, 0.25f, 0.20f)[gi("iconsize").coerceIn(0, 2)]
        val dark = 0xFF050B18.toInt()
        fun withAlpha(col: Int, a: Int) = (col and 0x00FFFFFF) or (a shl 24)

        fun shapeDrawable(shapeIdx: Int, fillIdx: Int, col: Int, bw: Int): android.graphics.drawable.GradientDrawable {
            val gd = android.graphics.drawable.GradientDrawable()
            when (shapeIdx) {
                0 -> gd.shape = android.graphics.drawable.GradientDrawable.OVAL
                4 -> {
                    gd.shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                    gd.cornerRadii = floatArrayOf(28 * d, 28 * d, 4 * d, 4 * d, 28 * d, 28 * d, 4 * d, 4 * d)
                }
                else -> {
                    gd.shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                    gd.cornerRadius = (if (shapeIdx == 1) 14f else if (shapeIdx == 2) 22f else 3f) * d
                }
            }
            when (fillIdx) {
                1 -> gd.setColor(col)
                2 -> gd.setColor(android.graphics.Color.TRANSPARENT)
                3 -> gd.setColor(dark)
                4 -> {
                    gd.orientation = android.graphics.drawable.GradientDrawable.Orientation.TL_BR
                    gd.colors = intArrayOf(withAlpha(col, 0x66), withAlpha(col, 0x14))
                }
                else -> gd.setColor(withAlpha(col, 0x26))
            }
            if (bw > 0) gd.setStroke((bw * d).toInt().coerceAtLeast(1), col)
            return gd
        }

        fun style(btn: android.widget.ImageButton, iconKey: String?, colKey: String?) {
            val col = if (colKey != null) colorOf(gi(colKey), globalCol) else globalCol
            val sz = (sizeDp * d).toInt()
            btn.background = shapeDrawable(shape, fill, col, borderDp)
            val lp = btn.layoutParams
            lp.width = sz
            lp.height = sz
            btn.layoutParams = lp
            val pad = (sz * iconPad).toInt()
            btn.setPadding(pad, pad, pad, pad)
            if (iconKey != null) {
                btn.setImageResource(opts.icons[gi(iconKey).coerceIn(0, opts.icons.size - 1)].res)
            }
            btn.imageTintList = ColorStateList.valueOf(if (fill == 1) dark else col)
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                btn.elevation = glow * 3f * d
                btn.outlineSpotShadowColor = col
                btn.outlineAmbientShadowColor = col
            }
        }
        style(binding.btnSleep, "icon_sleep", "col_sleep")
        style(binding.btnCamera, "icon_vision", "col_vision")
        style(binding.btnHistory, "icon_history", "col_history")
        style(binding.btnSettings, "icon_config", "col_config")

        // Labels under the buttons
        val show = gi("lbl_show") == 1
        val lblSize = listOf(9f, 10f, 12f)[gi("lbl_size").coerceIn(0, 2)]
        val lblCol = when (gi("lbl_col")) {
            1 -> android.graphics.Color.WHITE
            2 -> globalCol
            3 -> 0xFFFFC53D.toInt()
            else -> ThemeManager.color(this, R.attr.text_secondary)
        }
        listOf(binding.lblSleep, binding.lblVision, binding.lblHistory, binding.lblConfig).forEach {
            it.visibility = if (show) View.VISIBLE else View.GONE
            it.textSize = lblSize
            it.setTextColor(lblCol)
        }

        // Centre power button
        val pSize = (listOf(70, 84, 98)[gi("power_size").coerceIn(0, 2)] * d).toInt()
        val plp = binding.btnPowerSession.layoutParams
        plp.width = pSize
        plp.height = pSize
        binding.btnPowerSession.layoutParams = plp
        binding.ivPowerIcon.setImageResource(opts.icons[gi("icon_power").coerceIn(0, opts.icons.size - 1)].res)
        if (android.os.Build.VERSION.SDK_INT >= 28) {
            binding.btnPowerSession.elevation = listOf(0f, 6f, 14f)[gi("power_glow").coerceIn(0, 2)] * d
            binding.btnPowerSession.outlineSpotShadowColor = themeAccent
            binding.btnPowerSession.outlineAmbientShadowColor = themeAccent
        }

        // Bottom bar
        val radii = listOf(0f, 12f, 24f, 36f)[gi("bar_corner").coerceIn(0, 3)] * d
        val bar = android.graphics.drawable.GradientDrawable(
            android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(ThemeManager.color(this, R.attr.bar_a), ThemeManager.color(this, R.attr.bar_b))
        )
        bar.cornerRadius = radii
        bar.alpha = listOf(255, 200, 140, 70)[gi("bar_alpha").coerceIn(0, 3)]
        if (gi("bar_border") == 1) bar.setStroke((1.5f * d).toInt(), themeAccent)
        binding.controlsLayout.background = bar
        val padV = (listOf(6, 12, 18)[gi("bar_pad").coerceIn(0, 2)] * d).toInt()
        val padH = (6 * d).toInt()
        binding.controlsLayout.setPadding(padH, padV, padH, padV)

        // Left menu and banner
        val ms = listOf(10f, 11f, 13f)[gi("menu_size").coerceIn(0, 2)]
        listOf(binding.menuVoice, binding.menuApps, binding.menuInternet, binding.menuKnowledge, binding.menuSettings, binding.menuMore)
            .forEach { it.textSize = ms }
        val bs = gi("banner_style")
        binding.boxState.background = when (bs) {
            1 -> android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = 18 * d
                setColor(ThemeManager.color(this@MainActivity, R.attr.bg_card))
                setStroke((2 * d).toInt(), themeAccent)
            }
            2 -> android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = 18 * d
                setColor(android.graphics.Color.TRANSPARENT)
                setStroke((2 * d).toInt(), themeAccent)
            }
            else -> ContextCompat.getDrawable(this, R.drawable.bg_banner)
        }

        // Small round buttons and the camera screen
        val smallShape = listOf(0, 1, 3)
        binding.btnMicMute.background = shapeDrawable(smallShape[gi("mic_shape").coerceIn(0, 2)], 0, themeAccent, 1)
        binding.btnFlipCamera.background = shapeDrawable(smallShape[gi("flip_shape").coerceIn(0, 2)], 0, themeAccent, 1)
        val cam = listOf(96 to 130, 112 to 150, 140 to 190)[gi("cam_size").coerceIn(0, 2)]
        val clp = binding.cardCamera.layoutParams
        clp.width = (cam.first * d).toInt()
        clp.height = (cam.second * d).toInt()
        binding.cardCamera.layoutParams = clp

        // Press animation and vibration
        val press = gi("press")
        val haptic = gi("haptic") == 1
        listOf(binding.btnSleep, binding.btnCamera, binding.btnHistory, binding.btnSettings, binding.btnPowerSession)
            .forEach { v ->
                v.isHapticFeedbackEnabled = haptic
                v.setOnTouchListener { view, ev ->
                    when (ev.action) {
                        android.view.MotionEvent.ACTION_DOWN -> {
                            if (press == 1) view.animate().scaleX(0.86f).scaleY(0.86f).setDuration(80).start()
                        }
                        android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                            if (press == 1) {
                                view.animate().scaleX(1f).scaleY(1f).setDuration(120)
                                    .setInterpolator(android.view.animation.OvershootInterpolator()).start()
                            } else if (press == 2) {
                                view.animate().scaleX(1.18f).scaleY(1.18f).setDuration(90).withEndAction {
                                    view.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                                }.start()
                            }
                        }
                    }
                    false
                }
            }
    }

    private fun applyUiStyle() {
        val styles = com.jarvis.assistant.util.UiStyles.all
        val st = styles[JarvisApp.instance.preferences.uiStyleIndex.coerceIn(0, styles.size - 1)]
        orbHelper.setUiStyle(st.mode, st.img, st.spin)
        if (st.backdrop.isBlank()) {
            binding.ivBackdrop.visibility = View.GONE
            binding.ivBackdrop.setImageDrawable(null)
        } else {
            try {
                assets.open("ui/${st.backdrop}").use { input ->
                    val bmp = android.graphics.BitmapFactory.decodeStream(input)
                    binding.ivBackdrop.setImageBitmap(bmp)
                }
                binding.ivBackdrop.alpha = st.backdropAlpha
                binding.ivBackdrop.visibility = View.VISIBLE
            } catch (e: Exception) {
                binding.ivBackdrop.visibility = View.GONE
            }
        }
    }

    private fun applyOrbAccent() {
        applyUiStyle()
        val c = ThemeManager.color(this, R.attr.primary_cyan)
        val c2 = ThemeManager.color(this, R.attr.purple_glow)
        orbHelper.setAccent(
            android.graphics.Color.red(c), android.graphics.Color.green(c), android.graphics.Color.blue(c),
            android.graphics.Color.red(c2), android.graphics.Color.green(c2), android.graphics.Color.blue(c2),
            ThemeManager.isLight()
        )
    }

    override fun onResume() {
        super.onResume()
        if (appliedThemeKey != ThemeManager.key()) {
            recreate()
            return
        }
        viewModel.refreshSettings()
        applyTexts()
        applyLook()
    }

    // Gradient text for the "MADE BY AJ SIR" credit and the app title.
    private fun styleTexts() {
        applyGradientText(
            binding.tvMadeBy,
            ContextCompat.getColor(this, R.color.aj_gold_soft),
            ContextCompat.getColor(this, R.color.aj_gold)
        )
        applyGradientText(
            binding.tvJarvisTitle,
            ThemeManager.color(this, R.attr.primary_cyan),
            ThemeManager.color(this, R.attr.purple_glow)
        )
    }

    private fun applyGradientText(tv: TextView, startColor: Int, endColor: Int) {
        tv.post {
            val textWidth = tv.paint.measureText(tv.text.toString())
            tv.paint.shader = LinearGradient(
                0f, 0f, textWidth, 0f,
                intArrayOf(startColor, endColor),
                null,
                Shader.TileMode.CLAMP
            )
            tv.invalidate()
        }
    }

    // "07:32 PM" with a smaller AM/PM, like the HUD reference.
    private fun showClock(time: String) {
        val sp = SpannableString(time)
        val idx = time.indexOf(' ')
        if (idx > 0) {
            sp.setSpan(RelativeSizeSpan(0.7f), idx, time.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        binding.tvLiveTime.text = sp
    }

    private fun updateStats() {
        try {
            val country = java.util.Locale.getDefault().displayCountry.uppercase()
            binding.tvStatLoc.text = tx("val_loc").ifBlank { if (country.isBlank()) "INDIA" else country }
        } catch (e: Exception) { }
        try {
            val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            binding.tvStatBattery.text = if (level >= 0 && scale > 0) "${level * 100 / scale}%" else "--"

            val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            val used = 100 - (mi.availMem * 100 / mi.totalMem).toInt()
            binding.tvStatRam.text = "$used%"

            val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            binding.tvStatNet.text = when {
                caps == null -> "OFFLINE"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WI-FI"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "MOBILE"
                else -> "ONLINE"
            }
        } catch (e: Exception) {
            // Stats are only decoration; ignore any failure.
        }
    }

    private fun updateDateUi() {
        val now = Date()
        binding.tvDateNum.text = SimpleDateFormat("dd", Locale.ENGLISH).format(now)
        binding.tvDateMonth.text = SimpleDateFormat("MMM", Locale.ENGLISH).format(now).uppercase()
        binding.tvDateDay.text = SimpleDateFormat("EEEE", Locale.ENGLISH).format(now).uppercase()
    }

    private fun playEntranceAnimation() {
        val views: List<View> = listOf(
            binding.boxMadeBy,
            binding.topBar,
            binding.subInfoBar,
            binding.hudClockRow,
            binding.orbContainer,
            binding.boxState,
            binding.controlsLayout
        )
        views.forEachIndexed { index, view ->
            view.alpha = 0f
            view.translationY = 24f
            view.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(index * 90L)
                .setDuration(550)
                .start()
        }
    }

    private fun setupOrb() {
        orbHelper = OrbHelper(binding.webViewOrb)
        orbHelper.setup()
    }

    private fun setupListeners() {
        binding.btnSettings.setOnClickListener {
            val intent = Intent(this, SettingsActivity::class.java)
            startActivity(intent)
        }

        binding.btnPowerSession.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            val wanted = mutableListOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE
            )
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                wanted.add(Manifest.permission.POST_NOTIFICATIONS)
            }
            val missing = wanted.filter {
                ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
            }
            if (missing.isEmpty() || viewModel.isSessionOn.value) {
                viewModel.toggleSession()
            } else {
                requestAudioPermissionLauncher.launch(missing.toTypedArray())
            }
        }

        binding.btnCamera.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            if (cameraStreamer?.isRunning == true) {
                stopCamera()
            } else if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
                startCamera()
            } else {
                requestCameraPermissionLauncher.launch(Manifest.permission.CAMERA)
            }
        }

        binding.btnFlipCamera.setOnClickListener {
            val front = cameraStreamer?.flip() ?: true
            android.widget.Toast.makeText(
                this, if (front) "Front camera" else "Back camera", android.widget.Toast.LENGTH_SHORT
            ).show()
        }

        binding.btnSleep.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            if (viewModel.isSessionOn.value) {
                viewModel.toggleSession()
            } else {
                android.widget.Toast.makeText(this, tx("toast_sleep_off"), android.widget.Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnHistory.setOnClickListener { showChatHistory() }

        val openSettings = View.OnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        binding.menuSettings.setOnClickListener(openSettings)
        binding.menuMore.setOnClickListener(openSettings)
        binding.menuVoice.setOnClickListener(openSettings)
        binding.menuApps.setOnClickListener {
            android.widget.Toast.makeText(this, tx("toast_apps"), android.widget.Toast.LENGTH_LONG).show()
        }
        binding.menuInternet.setOnClickListener {
            android.widget.Toast.makeText(this, tx("toast_internet"), android.widget.Toast.LENGTH_LONG).show()
        }
        binding.menuKnowledge.setOnClickListener {
            android.widget.Toast.makeText(this, tx("toast_knowledge"), android.widget.Toast.LENGTH_LONG).show()
        }

        binding.btnMicMute.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            viewModel.toggleMicMute()
        }

        binding.tvViewHistory.setOnClickListener {
            showChatHistory()
        }

        binding.boxJarvisTitle.setOnClickListener {
            showChatHistory()
        }
    }

    private fun showChatHistory() {
        ChatHistoryBottomSheet.newInstance().show(
            supportFragmentManager,
            ChatHistoryBottomSheet.TAG
        )
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.liveTime.collect { time ->
                        showClock(time)
                        updateDateUi()
                        updateStats()
                    }
                }

                launch {
                    viewModel.greeting.collect { greeting ->
                        binding.tvGreeting.text = customGreeting(greeting)
                    }
                }

                launch {
                    viewModel.orbTheme.collect { theme ->
                        orbHelper.setTheme(theme)
                        applyOrbAccent()
                    }
                }

                launch {
                    viewModel.sessionSeconds.collect {
                        updateTimerUi()
                    }
                }

                launch {
                    viewModel.personalityName.collect { personality ->
                        binding.tvPersonalityMode.text = personality
                    }
                }

                launch {
                    viewModel.isSessionOn.collect { isOn ->
                        updatePowerButtonUi(isOn)
                    }
                }

                launch {
                    viewModel.isMicMuted.collect { isMuted ->
                        updateMicMuteUi(isMuted)
                    }
                }

                launch {
                    viewModel.conversationState.collect { state ->
                        updateConversationStateUi(state)
                    }
                }

                launch {
                    viewModel.audioLevel.collect { level ->
                        orbHelper.updateAudioLevel(level)
                        binding.ivWave.scaleY = 0.5f + level.coerceIn(0f, 1f) * 1.6f
                    }
                }

                launch {
                    viewModel.connectionStatus.collect { status ->
                        updateConnectionStatusUi(status)
                    }
                }

                launch {
                    viewModel.eventFlow.collect { message ->
                        Snackbar.make(binding.root, message, Snackbar.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    private fun updateTimerUi() {
        if (viewModel.isSessionOn.value) {
            val total = viewModel.sessionSeconds.value
            binding.tvSessionTimer.text = String.format("%02d:%02d", total / 60, total % 60)
            binding.tvSessionTimer.setTextColor(ThemeManager.color(this, R.attr.text_secondary))
        } else {
            binding.tvSessionTimer.text = tx("banner_hint")
            binding.tvSessionTimer.setTextColor(ThemeManager.color(this, R.attr.text_muted))
        }
    }

    private fun updatePowerButtonUi(isOn: Boolean) {
        // Keep the screen awake while a voice session is running.
        if (isOn) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        updateTimerUi()

        if (isOn) {
            binding.btnPowerSession.setBackgroundResource(R.drawable.bg_power_button)
            binding.ivPowerIcon.imageTintList = ColorStateList.valueOf(
                ThemeManager.color(this, R.attr.primary_cyan)
            )
            binding.tvPowerText.text = tx("power_on")
            binding.tvPowerText.setTextColor(
                ThemeManager.color(this, R.attr.primary_cyan)
            )
        } else {
            binding.btnPowerSession.setBackgroundResource(R.drawable.bg_power_button_off)
            binding.ivPowerIcon.imageTintList = ColorStateList.valueOf(
                ThemeManager.color(this, R.attr.text_muted)
            )
            binding.tvPowerText.text = tx("power_off")
            binding.tvPowerText.setTextColor(
                ThemeManager.color(this, R.attr.text_muted)
            )
        }
    }

    private fun updateMicMuteUi(isMuted: Boolean) {
        if (isMuted) {
            binding.btnMicMute.setImageResource(R.drawable.ic_mic_off)
            binding.btnMicMute.imageTintList = ColorStateList.valueOf(
                ContextCompat.getColor(this, R.color.status_red)
            )
        } else {
            binding.btnMicMute.setImageResource(R.drawable.ic_mic)
            binding.btnMicMute.imageTintList = ColorStateList.valueOf(
                ThemeManager.color(this, R.attr.primary_cyan)
            )
        }
    }

    private fun updateConversationStateUi(state: ConversationState) {
        binding.tvConversationState.text = when (state) {
            ConversationState.IDLE -> tx("state_idle")
            ConversationState.LISTENING -> tx("state_listening")
            ConversationState.THINKING -> tx("state_thinking")
            ConversationState.SPEAKING -> tx("state_speaking")
        }
        val colorRes = when (state) {
            ConversationState.IDLE -> R.attr.text_secondary
            ConversationState.LISTENING -> R.attr.primary_cyan
            ConversationState.THINKING -> R.attr.purple_glow
            ConversationState.SPEAKING -> R.attr.neon_blue
        }
        binding.tvConversationState.setTextColor(ThemeManager.color(this, colorRes))
        orbHelper.updateState(state)
    }

    private fun updateConnectionStatusUi(status: String) {
        // Short labels so the pill never collides with the power button.
        binding.tvConnectionStatus.text = when (status) {
            "CONNECTING..." -> tx("status_connecting")
            "RECONNECTING..." -> tx("status_retry")
            "LIVE" -> tx("status_live")
            "READY" -> tx("status_ready")
            "OFFLINE" -> tx("status_offline")
            else -> status
        }
        val dotColor = when (status) {
            "LIVE" -> ContextCompat.getColor(this, R.color.status_green)
            "CONNECTING...", "RECONNECTING..." -> ContextCompat.getColor(this, R.color.status_amber)
            else -> ThemeManager.color(this, R.attr.text_muted)
        }
        binding.viewStatusDot.backgroundTintList = ColorStateList.valueOf(dotColor)
    }

    override fun onDestroy() {
        cameraStreamer?.stop()
        super.onDestroy()
        if (isFinishing && !JarvisApp.instance.preferences.alwaysOn) {
            viewModel.shutdownSession()
        }
    }
}
