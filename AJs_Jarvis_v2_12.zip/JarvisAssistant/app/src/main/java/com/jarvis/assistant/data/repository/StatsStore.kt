package com.jarvis.assistant.data.repository

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Command analytics: how often each command ran, how often it worked, how long it took, and the latest errors. */
object StatsStore {
    private const val PREFS = "jarvis_stats"

    private fun sp(context: Context) = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun record(context: Context, tool: String, ok: Boolean, ms: Long, result: String) {
        val p = sp(context)
        val all = try { JSONObject(p.getString("tools", "{}")) } catch (e: Exception) { JSONObject() }
        val o = all.optJSONObject(tool) ?: JSONObject().put("c", 0).put("f", 0).put("ms", 0L)
        o.put("c", o.optInt("c") + 1)
        if (!ok) o.put("f", o.optInt("f") + 1)
        o.put("ms", o.optLong("ms") + ms)
        all.put(tool, o)
        val ed = p.edit().putString("tools", all.toString())
        if (!ok) {
            val errs = try { JSONArray(p.getString("errors", "[]")) } catch (e: Exception) { JSONArray() }
            errs.put(JSONObject().put("t", System.currentTimeMillis()).put("tool", tool).put("msg", result.take(90)))
            val keep = JSONArray()
            for (i in maxOf(0, errs.length() - 8) until errs.length()) keep.put(errs.get(i))
            ed.putString("errors", keep.toString())
        }
        ed.apply()
    }

    @Synchronized
    fun summary(context: Context): String {
        val p = sp(context)
        val all = try { JSONObject(p.getString("tools", "{}")) } catch (e: Exception) { JSONObject() }
        if (all.length() == 0) return "Abhi tak koi command record nahi hua."
        data class Row(val name: String, val c: Int, val f: Int, val avg: Long)
        val rows = ArrayList<Row>()
        for (k in all.keys()) {
            val o = all.getJSONObject(k)
            val c = o.optInt("c")
            rows.add(Row(k, c, o.optInt("f"), if (c > 0) o.optLong("ms") / c else 0L))
        }
        val total = rows.sumOf { it.c }
        val fails = rows.sumOf { it.f }
        val sb = StringBuilder()
        sb.append("Kul commands: $total  |  Safal: ${total - fails}  |  Fail: $fails\n")
        if (total > 0) sb.append("Safalta: ${(total - fails) * 100 / total}%\n")
        sb.append("\nSabse zyada chale:\n")
        rows.sortedByDescending { it.c }.take(8).forEach {
            sb.append("- ${it.name}: ${it.c} baar, aaushat ${it.avg} ms" + if (it.f > 0) ", ${it.f} fail" else "").append('\n')
        }
        val errs = try { JSONArray(p.getString("errors", "[]")) } catch (e: Exception) { JSONArray() }
        if (errs.length() > 0) {
            sb.append("\nHaal ke errors:\n")
            for (i in errs.length() - 1 downTo maxOf(0, errs.length() - 5)) {
                val e = errs.getJSONObject(i)
                sb.append("- ${e.optString("tool")}: ${e.optString("msg")}\n")
            }
        }
        return sb.toString()
    }

    fun reset(context: Context) {
        sp(context).edit().clear().apply()
    }
}
