package com.jarvis.assistant.announce

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.speech.tts.TextToSpeech
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.util.JarvisRuntime
import java.util.ArrayDeque
import java.util.Locale

/** Speaks short announcements (new message, incoming call, charging) with the phone's own voice. */
object Announcer {
    private var tts: TextToSpeech? = null
    private var ready = false
    private val pending = ArrayDeque<String>()
    private val lastSpoken = HashMap<String, Long>()

    private fun ownerName(): String {
        val n = JarvisApp.instance.preferences.userName.trim()
        if (n.isBlank()) return "Boss"
        return if (n.length <= 14) n else n.split(" ").first()
    }

    fun speak(context: Context, text: String, key: String = text, minGapMs: Long = 4000) {
        // While a live conversation is running Jarvis is already talking; stay quiet then.
        if (JarvisRuntime.sessionOn) return
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (am.ringerMode != AudioManager.RINGER_MODE_NORMAL) return
        val now = System.currentTimeMillis()
        synchronized(lastSpoken) {
            if (now - (lastSpoken[key] ?: 0L) < minGapMs) return
            lastSpoken[key] = now
        }
        val app = context.applicationContext
        Thread {
            // Natural Gemini voice first; the phone's own robotic voice only as a fallback.
            if (!NaturalVoice.speak(app, text)) speakLocal(app, text)
        }.start()
    }

    @Synchronized
    private fun speakLocal(app: Context, text: String) {
        if (tts != null && ready) {
            doSpeak(text)
            return
        }
        pending.add(text)
        if (tts == null) {
            tts = TextToSpeech(app) { status ->
                synchronized(this) {
                    if (status == TextToSpeech.SUCCESS) {
                        val t = tts
                        val r = t?.setLanguage(Locale("hi", "IN"))
                        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                            t?.setLanguage(Locale.getDefault())
                        }
                        t?.setAudioAttributes(
                            AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                .build()
                        )
                        ready = true
                        while (pending.isNotEmpty()) doSpeak(pending.poll())
                    }
                }
            }
        }
    }

    private fun doSpeak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_ADD, null, "ann_" + System.nanoTime())
    }

    fun newMessage(context: Context, sender: String, app: String, group: String?, body: String) {
        val p = JarvisApp.instance.preferences
        if (!p.announceMsgs) return
        var line = if (group != null) "$group ग्रुप में $sender का $app मैसेज आया है"
        else "$sender का $app मैसेज आया है"
        if (p.announceText && body.isNotBlank()) line += ". " + body.take(160)
        speak(context, line, key = "msg_$sender", minGapMs = 3000)
    }

    fun incomingCall(context: Context, caller: String) {
        if (!JarvisApp.instance.preferences.announceMsgs) return
        speak(context, "$caller का कॉल आ रहा है", key = "call_$caller", minGapMs = 15000)
    }

    fun charging(context: Context, percent: Int) {
        if (!JarvisApp.instance.preferences.announceBattery) return
        speak(context, "फ़ोन चार्ज हो रहा है ${ownerName()}. अभी $percent प्रतिशत चार्ज है", key = "charging", minGapMs = 20000)
    }

    fun full(context: Context) {
        if (!JarvisApp.instance.preferences.announceBattery) return
        speak(context, "फ़ोन पूरा चार्ज हो गया है ${ownerName()}, अब चार्जर हटा सकते हैं", key = "full", minGapMs = 60000)
    }

    fun low(context: Context, percent: Int) {
        if (!JarvisApp.instance.preferences.announceBattery) return
        speak(context, "${ownerName()}, बैटरी कम है, सिर्फ़ $percent प्रतिशत बची है. चार्जर लगा दीजिए", key = "low", minGapMs = 120000)
    }
}
