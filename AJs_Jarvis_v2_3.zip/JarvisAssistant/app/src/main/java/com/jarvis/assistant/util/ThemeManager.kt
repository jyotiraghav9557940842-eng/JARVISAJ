package com.jarvis.assistant.util

import android.app.Activity
import android.content.Context
import android.util.TypedValue
import com.jarvis.assistant.JarvisApp

/** 66 colour palettes (see Palettes). Chosen in Settings, applied to every screen. */
object ThemeManager {

    fun index(): Int {
        val i = JarvisApp.instance.preferences.paletteIndex
        return if (i in Palettes.all.indices) i else Palettes.DEFAULT_INDEX
    }

    fun isLight(): Boolean = Palettes.all[index()].isLight

    fun key(): String = "p${index()}"

    fun apply(activity: Activity) {
        val id = activity.resources.getIdentifier("Theme_Jarvis_P${index()}", "style", activity.packageName)
        if (id != 0) activity.setTheme(id)
    }

    fun color(context: Context, attr: Int): Int {
        val tv = TypedValue()
        context.theme.resolveAttribute(attr, tv, true)
        return tv.data
    }
}
