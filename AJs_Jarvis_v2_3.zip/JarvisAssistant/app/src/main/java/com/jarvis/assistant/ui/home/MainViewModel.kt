package com.jarvis.assistant.ui.home

import android.Manifest
import android.content.pm.PackageManager
import com.jarvis.assistant.audio.OwnerVoiceGate
import com.jarvis.assistant.audio.VoiceProfile
import com.jarvis.assistant.audio.WakeTemplates
import com.jarvis.assistant.audio.WakeWordDetector
import com.jarvis.assistant.util.JarvisRuntime
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import android.content.Intent
import androidx.core.content.ContextCompat
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.actions.DeviceActionExecutor
import com.jarvis.assistant.background.JarvisConversationService
import com.jarvis.assistant.audio.AudioPlayer
import com.jarvis.assistant.audio.AudioRecorder
import com.jarvis.assistant.data.model.ConversationState
import com.jarvis.assistant.data.preferences.AppPreferences
import com.jarvis.assistant.data.repository.ChatRepository
import com.jarvis.assistant.network.GeminiLiveWebSocket
import com.jarvis.assistant.util.PromptGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private const val ACTIVE_WINDOW_MS = 30000L

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val preferences: AppPreferences = (application as JarvisApp).preferences
    private val chatRepository: ChatRepository = (application as JarvisApp).chatRepository

    private val _isSessionOn = MutableStateFlow(false)
    val isSessionOn: StateFlow<Boolean> = _isSessionOn.asStateFlow()

    private val _conversationState = MutableStateFlow(ConversationState.IDLE)
    val conversationState: StateFlow<ConversationState> = _conversationState.asStateFlow()

    private val _isMicMuted = MutableStateFlow(preferences.isMicMuted)
    val isMicMuted: StateFlow<Boolean> = _isMicMuted.asStateFlow()

    private val _connectionStatus = MutableStateFlow("READY")
    val connectionStatus: StateFlow<String> = _connectionStatus.asStateFlow()

    private val _audioLevel = MutableStateFlow(0f)
    val audioLevel: StateFlow<Float> = _audioLevel.asStateFlow()

    private val _liveTime = MutableStateFlow("")
    val liveTime: StateFlow<String> = _liveTime.asStateFlow()

    private val _personalityName = MutableStateFlow(preferences.personality)
    val personalityName: StateFlow<String> = _personalityName.asStateFlow()

    private val _greeting = MutableStateFlow(buildGreeting())
    val greeting: StateFlow<String> = _greeting.asStateFlow()

    private val _sessionSeconds = MutableStateFlow(0)
    val sessionSeconds: StateFlow<Int> = _sessionSeconds.asStateFlow()

    private val _orbTheme = MutableStateFlow(preferences.orbTheme)
    val orbTheme: StateFlow<String> = _orbTheme.asStateFlow()

    private val _eventFlow = MutableSharedFlow<String>()
    val eventFlow: SharedFlow<String> = _eventFlow.asSharedFlow()

    private var audioRecorder: AudioRecorder? = null
    private var audioPlayer: AudioPlayer? = null
    private var liveWebSocket: GeminiLiveWebSocket? = null

    private var timeClockJob: Job? = null
    private var sessionTimerJob: Job? = null
    private val currentTurnAssistantText = StringBuilder()
    private val currentTurnUserText = StringBuilder()
    private var lastUserSpeechDetectedTime = 0L

    init {
        startTimeClock()
    }

    private fun startTimeClock() {
        timeClockJob = viewModelScope.launch(Dispatchers.Default) {
            val sdf = SimpleDateFormat("hh:mm a", Locale.ENGLISH)
            while (isActive) {
                _liveTime.value = sdf.format(Date())
                delay(1000)
            }
        }
    }

    private fun buildGreeting(): String {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val part = when (hour) {
            in 5..11 -> "Good morning"
            in 12..16 -> "Good afternoon"
            in 17..20 -> "Good evening"
            else -> "Hello"
        }
        val name = preferences.userName.ifBlank { "Boss" }
        return "$part, $name"
    }

    fun refreshSettings() {
        _greeting.value = buildGreeting()
        _orbTheme.value = preferences.orbTheme
        _personalityName.value = preferences.personality
        _isMicMuted.value = preferences.isMicMuted
        audioRecorder?.setMuted(preferences.isMicMuted)
    }

    @Volatile private var liveActive = false
    @Volatile private var standbyMode = false
    @Volatile private var wakePending = false
    @Volatile private var lastActivityTime = 0L
    private var ownerGate: OwnerVoiceGate? = null
    private var wakeDetector: WakeWordDetector? = null
    private val pendingWakeAudio = ArrayList<ByteArray>()
    private var idleJob: Job? = null

    init {
        JarvisRuntime.voiceChangeHook = {
            viewModelScope.launch {
                kotlinx.coroutines.delay(2500)
                var waited = 0
                while (_conversationState.value == ConversationState.SPEAKING && waited < 40) {
                    kotlinx.coroutines.delay(300)
                    waited++
                }
                if (liveActive) {
                    releaseLive()
                    kotlinx.coroutines.delay(400)
                    connectLive()
                }
            }
        }
    }

    fun toggleSession() {
        if (_isSessionOn.value) {
            stopSession()
        } else {
            startSession()
        }
    }

    /** Called when the app is closed by the user while Always-on is off. */
    fun shutdownSession() {
        if (_isSessionOn.value) stopSession()
    }

    /** Always-on: start by itself as soon as the app process starts (if mic permission is already given). */
    fun startIfAlwaysOn() {
        if (!preferences.alwaysOn || _isSessionOn.value) return
        val granted = ContextCompat.checkSelfPermission(
            getApplication<Application>(), Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) startSession()
    }

    private fun sensFactor(): Float = when (preferences.ownerVoiceSensitivity) {
        0 -> 1.15f
        2 -> 0.88f
        else -> 1f
    }

    private fun startSession() {
        val apiKey = preferences.apiKey.trim()
        if (apiKey.isBlank()) {
            viewModelScope.launch {
                _eventFlow.emit("Please configure your Gemini API Key in Settings first.")
            }
            return
        }

        _isSessionOn.value = true
        JarvisRuntime.sessionOn = true
        _conversationState.value = ConversationState.IDLE
        currentTurnAssistantText.clear()
        currentTurnUserText.clear()

        sessionTimerJob?.cancel()
        _sessionSeconds.value = 0
        sessionTimerJob = viewModelScope.launch(Dispatchers.Default) {
            var seconds = 0
            while (isActive) {
                delay(1000)
                seconds++
                _sessionSeconds.value = seconds
            }
        }

        // Keeps the microphone and connection alive while another app is in front.
        try {
            ContextCompat.startForegroundService(
                getApplication<Application>(),
                Intent(getApplication<Application>(), JarvisConversationService::class.java)
            )
        } catch (e: Exception) {
            // Session still works while the app is open.
        }

        val profile = if (preferences.ownerVoiceLock) VoiceProfile.parse(preferences.ownerVoiceProfile) else null
        if (preferences.ownerVoiceLock && profile == null) {
            viewModelScope.launch {
                _eventFlow.emit("Owner Voice set nahi hai. Settings me Voice Setup karo.")
            }
        }
        ownerGate = profile?.let { OwnerVoiceGate(it, sensFactor()) }

        val wake = if (preferences.alwaysOn) WakeTemplates.parse(preferences.wakeTemplates) else null
        if (preferences.alwaysOn && wake == null) {
            viewModelScope.launch {
                _eventFlow.emit("Wake word set nahi hai. Settings me Voice Setup karo.")
            }
        }
        wakeDetector = wake?.let { WakeWordDetector(it, profile, sensFactor()) }
        standbyMode = wakeDetector != null

        startRecorder()
        if (standbyMode) {
            _connectionStatus.value = "STANDBY - SAY JARVIS"
        } else {
            connectLive()
        }
    }

    private fun connectLive() {
        if (liveActive) return
        val apiKey = preferences.apiKey.trim()
        if (apiKey.isBlank()) return
        liveActive = true
        lastActivityTime = System.currentTimeMillis()
        currentTurnAssistantText.clear()
        currentTurnUserText.clear()

        // 1. Output Player (24kHz Mono Output)
        audioPlayer = AudioPlayer(
            onPlaybackStateChanged = { isPlaying ->
                if (isPlaying) {
                    _conversationState.value = ConversationState.SPEAKING
                } else {
                    finalizeTurn()
                    if (_isSessionOn.value) {
                        _conversationState.value = ConversationState.IDLE
                    }
                }
            },
            onPlaybackAmplitude = { amp ->
                if (_conversationState.value == ConversationState.SPEAKING) {
                    _audioLevel.value = amp
                }
            }
        ).apply { start() }

        // 2. Gemini Live WebSocket Connection
        val systemPrompt = PromptGenerator.generateSystemPrompt(
            personality = preferences.personality,
            userName = preferences.userName,
            memory = try {
                com.jarvis.assistant.data.repository.MemoryStore(getApplication<Application>().applicationContext)
                    .promptBlock(chatRepository.turns.value)
            } catch (e: Exception) { "" }
        )

        liveWebSocket = GeminiLiveWebSocket(
            apiKey = apiKey,
            model = preferences.aiModel,
            voiceName = preferences.voice,
            systemPrompt = systemPrompt,
            actionExecutor = DeviceActionExecutor(getApplication<Application>().applicationContext),
            listener = object : GeminiLiveWebSocket.Listener {
                override fun onConnectionStateChanged(status: String) {
                    _connectionStatus.value = status
                    if (status == "LIVE") {
                        // Send what was heard together with the wake word, so the first command isn't lost.
                        synchronized(pendingWakeAudio) {
                            for (c in pendingWakeAudio) liveWebSocket?.sendAudioChunk(c)
                            pendingWakeAudio.clear()
                            wakePending = false
                        }
                        if (_conversationState.value == ConversationState.IDLE) {
                            _conversationState.value = ConversationState.LISTENING
                        }
                    }
                }

                override fun onAudioDataReceived(pcmData: ByteArray) {
                    lastActivityTime = System.currentTimeMillis()
                    _conversationState.value = ConversationState.SPEAKING
                    audioPlayer?.enqueueAudio(pcmData)
                }

                override fun onAssistantTextReceived(textChunk: String) {
                    currentTurnAssistantText.append(textChunk)
                }

                override fun onUserTextReceived(textChunk: String) {
                    currentTurnUserText.append(textChunk)
                }

                override fun onInterrupted() {
                    audioPlayer?.flush()
                    currentTurnAssistantText.clear()
                    _conversationState.value = ConversationState.LISTENING
                }

                override fun onTurnCompleted() {
                    // Handled when audio finishes draining in audioPlayer
                }

                override fun onError(message: String) {
                    viewModelScope.launch {
                        _eventFlow.emit(message)
                    }
                }
            }
        ).apply {
            connect(viewModelScope)
        }

        if (standbyMode) startIdleWatcher()
    }

    /** In wake-word mode, goes back to standby after about 30 seconds without conversation. */
    private fun startIdleWatcher() {
        idleJob?.cancel()
        idleJob = viewModelScope.launch {
            while (isActive) {
                delay(2000)
                val st = _conversationState.value
                if (st == ConversationState.SPEAKING || st == ConversationState.THINKING) {
                    lastActivityTime = System.currentTimeMillis()
                }
                if (System.currentTimeMillis() - lastActivityTime > ACTIVE_WINDOW_MS) {
                    releaseLive()
                    _connectionStatus.value = "STANDBY - SAY JARVIS"
                    break
                }
            }
        }
    }

    private fun releaseLive() {
        liveActive = false
        idleJob?.cancel()
        idleJob = null
        synchronized(pendingWakeAudio) {
            pendingWakeAudio.clear()
            wakePending = false
        }
        finalizeTurn()
        audioPlayer?.flush()
        audioPlayer?.release()
        audioPlayer = null
        liveWebSocket?.disconnect()
        liveWebSocket = null
        _conversationState.value = ConversationState.IDLE
        _audioLevel.value = 0f
    }

    private fun startRecorder() {
        audioRecorder = AudioRecorder { chunk, amplitude ->
            if (_isSessionOn.value) handleAudio(chunk, amplitude)
        }.apply {
            setMuted(preferences.isMicMuted)
            start(viewModelScope)
        }
    }

    private fun handleAudio(chunk: ByteArray, amplitude: Float) {
        // Audio heard together with the wake word, while the connection is still opening.
        var queued = false
        synchronized(pendingWakeAudio) {
            if (wakePending) {
                if (chunk.isNotEmpty()) pendingWakeAudio.add(chunk)
                queued = true
            }
        }
        if (queued) return

        if (!liveActive) {
            // Standby: only listening for the owner's "Jarvis" / "Wake up Jarvis".
            val heard = wakeDetector?.process(chunk, amplitude)
            if (heard != null) {
                synchronized(pendingWakeAudio) {
                    pendingWakeAudio.clear()
                    pendingWakeAudio.addAll(heard)
                    wakePending = true
                }
                viewModelScope.launch {
                    _eventFlow.emit("Jarvis active")
                    connectLive()
                }
            }
            return
        }

        val gate = ownerGate
        val passing: Boolean
        if (gate != null) {
            passing = gate.process(chunk, amplitude) { liveWebSocket?.sendAudioChunk(it) }
        } else {
            liveWebSocket?.sendAudioChunk(chunk)
            passing = true
        }

        if (passing && amplitude > 0.08f) {
            lastUserSpeechDetectedTime = System.currentTimeMillis()
            lastActivityTime = lastUserSpeechDetectedTime
            if (_conversationState.value != ConversationState.SPEAKING) {
                _conversationState.value = ConversationState.LISTENING
                _audioLevel.value = amplitude
            }
        } else if (_conversationState.value == ConversationState.LISTENING) {
            _audioLevel.value = amplitude
            val silentDuration = System.currentTimeMillis() - lastUserSpeechDetectedTime
            if (silentDuration > 700 && lastUserSpeechDetectedTime > 0) {
                // Tell the server we're done talking now, rather than waiting
                // for its own (slower) silence detector to reach the same
                // conclusion - this is what makes replies feel snappy.
                liveWebSocket?.sendAudioStreamEnd()
                _conversationState.value = ConversationState.THINKING
                lastUserSpeechDetectedTime = 0L
            }
        }
    }

    private fun finalizeTurn() {
        val reply = currentTurnAssistantText.toString().trim()
        if (reply.isNotEmpty()) {
            chatRepository.addTurn(
                userText = currentTurnUserText.toString().trim(),
                jarvisText = reply
            )
            currentTurnAssistantText.clear()
            currentTurnUserText.clear()
        }
    }

    private fun stopSession() {
        _isSessionOn.value = false
        JarvisRuntime.sessionOn = false

        sessionTimerJob?.cancel()
        sessionTimerJob = null
        _sessionSeconds.value = 0

        audioRecorder?.stop()
        audioRecorder = null

        releaseLive()
        ownerGate = null
        wakeDetector = null
        standbyMode = false

        try {
            getApplication<Application>().stopService(
                Intent(getApplication<Application>(), JarvisConversationService::class.java)
            )
        } catch (e: Exception) {
        }

        _conversationState.value = ConversationState.IDLE
        _connectionStatus.value = "READY"
        _audioLevel.value = 0f
    }

    /** Called by the camera streamer ~1 frame/sec; ignored unless a live session is open. */
    fun sendVideoFrame(jpeg: ByteArray) {
        liveWebSocket?.sendVideoFrame(jpeg)
    }

    fun toggleMicMute() {
        val newMuted = !_isMicMuted.value
        _isMicMuted.value = newMuted
        preferences.isMicMuted = newMuted
        audioRecorder?.setMuted(newMuted)
        viewModelScope.launch {
            _eventFlow.emit(if (newMuted) "Microphone Muted" else "Microphone Unmuted")
        }
    }

    override fun onCleared() {
        super.onCleared()
        timeClockJob?.cancel()
        stopSession()
    }
}
